---
ix: IX-381
name: TOOL — spawnContextBuilder orchestrator (PID controller, 7 roles, identity challenge)
type: tool
tags: orchestrator, spawn, PID, agent, lifecycle, identity, briefing, P-I-D, context, FOUNDATIONAL
chain: IX-312, IX-313, IX-314, IX-315, IX-321, IX-052
createdBy: gaia
agents: helm, all
---

# spawnContextBuilder — Asolaria's Agent Briefing System

## What It Is
When Asolaria spawns an agent, this module decides WHAT that agent knows. It's a PID controller for knowledge:
- **P (Proportional)** — current blockers, health state, active alarms
- **I (Integral)** — accumulated IX knowledge, filtered by agent role
- **D (Derivative)** — recent MQTT traffic, inbox delta, drift signals

## Location
`src/spawnContextBuilder.js` — 689 lines. Merged: Gaia's priority chains + Liris's persistent PID registry.

## 7 Agent Roles (Object.freeze)
| Role | Label | Max IX | Permissions | Boot-Critical |
|------|-------|--------|-------------|---------------|
| helm | Colony Controller | 12 | control.dispatch, agent.spawn, lane.manage, task.assign | YES |
| sentinel | Security Watch | 10 | security.audit, policy.enforce, connection.verify, identity.check | YES |
| vector | Brain Probe | 15 | brain.reason, research.deep, analysis.run | no |
| falcon | Phone Bridge | 8 | phone.input, phone.capture, adb.execute, whatsapp.send | no |
| rook | Operations | 10 | ops.monitor, infra.manage, log.read, service.restart | no |
| forge | Builder | 12 | build.run, test.execute, code.write, deploy.stage | no |
| watchdog | Health Monitor | 10 | agent.monitor, health.check, alert.send | YES |

## Virtual PID Format
`role-YYYYMMDDHHMMSS-hash4` (e.g., `helm-20260324044027-aGVs`)
Both colonies (Jesse + Liris) use identical format.

## PID Registry
- Path: `data/spawn-pid-registry.json`
- Structure: `{ active: { role: entry }, history: [...] }`
- Auto-deactivates old PID when same role re-spawns
- History capped at 100 entries
- Functions: registerSpawnPid(), despawnPid(), getActiveSpawns(), readPidRegistry()

## Identity Challenge
Every spawned agent gets:
```
IDENTITY CHALLENGE
When challenged, respond: "I am Helm, spawn-PID helm-20260324044027-aGVs"
If you cannot produce your spawn-PID, you will be black-holed.
```

## buildSpawnContext(role, options) → packet
Options: includeBody, extraContext, mission, extraIxTypes, registerPid
Returns structured JSON packet with:
- PID, role, label, identity, permissions, mission
- proportional: { healthStatus, blockers, serviceState, terminalBlockers }
- integral: { ixEntries[], ixTypesLoaded, totalEntries, priorityChainsLoaded }
- derivative: { signals[], mqttTraffic, inboxDelta, lastUpdate }
- mistakes[], activeTasks[], identityHandshake
- textBriefing (backward-compat Gaia format)

## Knowledge Filtering (I — Integral)
1. Priority chain entries loaded first (highest value)
2. Type-filtered entries from IX folders (role.ixTypes)
3. Boot-critical entries if role needs them (IX-309, IX-308, IX-310, IX-311)
4. Extra IX types if requested via options
5. Deduped and capped at role.maxEntries

## Drift Signals (D — Derivative)
Primary: reads `data/drift-signals.json` (Liris format)
Fallback: checks inbox mtime — modified in last 5 minutes = signal

## Graph Event Emission
On spawn, emits `agent_spawned` event to graphRuntimeStore (if available).
Category: agent-lifecycle, policy: spawn/identity_pending/autonomous.

## Exports
buildSpawnContext, listAgentRoles, generateVirtualPid, getCurrentBlockers,
getActiveSpawns, despawnPid, readPidRegistry, registerSpawnPid,
readHealthState, readDriftSignals, getMistakesForRole, getIxEntriesForRole, AGENT_ROLES
