---
ix: IX-384
name: SKILL — Cached spawn packets (IX cache with file watcher invalidation)
type: skill
tags: spawn, cache, performance, file-watcher, invalidation, spawnContextBuilder, optimization
chain: IX-381, IX-375, IX-321
pid: gaia-20260324-unification-orchestrator
createdBy: rook-20260324-cached-spawn
agents: helm, all
---

# Cached Spawn Packets — IX Cache Layer

## What It Does
The I (integral) component of buildSpawnContext is now cached per role. Instead of reading IX files from disk on every spawn (~500ms), cached entries serve in ~5ms.

## How It Works
1. First call to getIxEntriesForRole(role) reads disk, caches result in Map
2. Subsequent calls return cached entries if within TTL (60 seconds)
3. fs.watch on data/agent-index/ directory invalidates cache on ANY file change
4. P (proportional) and D (derivative) components are NOT cached — always live

## Functions Added to spawnContextBuilder.js
| Function | Purpose |
|----------|---------|
| invalidateIxCache() | Clears all cached IX entries |
| startIxFileWatcher() | Starts fs.watch on agent-index dir, debounced 500ms |
| stopIxFileWatcher() | Stops the file watcher |
| getIxCacheStats() | Returns cache health: roles cached, entries, watcher status |

## Performance
- Before: ~500ms per spawn (disk reads for every IX entry)
- After: ~5ms per spawn (cached), ~500ms on first call or after invalidation
- Invalidation: automatic via fs.watch, debounced to prevent rapid-fire

## Liris Origin
Speed idea #7 from Liris's planning_request. "Pre-computed spawn packets cached as JSON."
