# Patterns — Runtime
18 entries. Brain, swarm, workers, graph, data layer, Symphony, gateway server, security.

| LX | Name | Chain |
|----|------|-------|
| 022 | Symphony Integration — Linear + Codex | → 020, 021, 019 |
| 025 | Helm Controller — relay, dispatch, Symphony | → 021, 022, 020 |
| 029 | Symphony WORKFLOW — helpers config | → 022, 025, 021 |
| 049 | Omnispindle — Dan Edens' MCP, 3 lanes | → 019, 044, 022 |
| 051 | brainOrchestrator.js — 7-provider fallback chain | → 020, 044, 019 |
| 055 | workerRouter.js — 4 workers, 7 task types, dispatch | → 025, 051, 044 |
| 058 | gateway/server.js — the REAL core, 1531 lines | → 031, 023, 038 |
| 059 | Gateway internals — toolAuthority, authorityMode, routes | → 058, 031, 023 |
| 060 | Data layer — memory, semantic KB, tasks, personas | → 058, 048, 044 |
| 061 | Graph runtime + SwarmDesk + edge risk — nervous system | → 060, 047, 044 |
| 062 | Risk engine + intent router + connection policy — decisions | → 061, 051, 023 |
| 065 | Security core — vault, guardian, brain safety, ClawBot warning | → 039, 023, 059 |
| 066 | Data stores — notebook, projects (QDD/Healthcare), mistake ledger | → 060, 052, 005 |
| 067 | Mobile push + guardian alerts + workspace knowledge | → 050, 065, 060 |
| 098 | OpenClaw Remediation — legacy removed, MCP/skill mesh replaces | → 024, 064, 062 |
| 100 | Graph-Native Control Plane — stealth=telemetry, domain separation | → 061, 058, 062, 099 |
| 119 | Gaia MASSIVE — Auggie, Abacus, Cursor MCP, Symphony, MongoDB, Codex on Jesse's | → 118, 115, 030, 022, 049 |
| 149 | Permanent Mongo rule — Compass and colony Mongo must be activated as process surfaces | → 119, 118, 147, 148 |
