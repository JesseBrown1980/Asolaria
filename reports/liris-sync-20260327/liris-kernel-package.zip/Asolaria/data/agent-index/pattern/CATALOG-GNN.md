# Patterns — GNN & World Model
4 entries. GNN models, 3D world, simulation interior, civilization, Gaia relay.

| LX | Name | Chain |
|----|------|-------|
| 047 | civilizationWorld.js — 3D world model, districts | → 015, 044, 019 |
| 087 | Gaia relay — 95 IX, browser skill transfer, timeline Sep 2023, port 18886 myth | → 033, 085, 045, 072 |
| 120 | **DEEPEST — IX/LX IS the Meta-Tagged Simulation applied to knowledge. Fractal.** | → 091, 015, 041, 047, 061, 115 |
| 245 | Gaia-only modules — 21 src files + 4 routes + GNN sidecar not on Liris | → 234, 215, IX-316 |
