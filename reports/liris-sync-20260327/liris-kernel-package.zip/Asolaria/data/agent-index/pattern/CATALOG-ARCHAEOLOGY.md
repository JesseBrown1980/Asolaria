# Patterns — Archaeology
21 entries. Founding, dig findings, ancestors, Medium articles, codex history, excavation.

| LX | Name | Chain |
|----|------|-------|
| 019 | Creation History — founding of Asolaria | → 001, 015, 017 |
| 033 | Gaia indexed us as IX-075 | → 032, 015, 019 |
| 063 | Gaia signed off — "The index will be here tomorrow" | → 041, 033, 015 |
| 073 | Voice transcription archaeology — Whisper, TTS, OCR, Gemini Live | → 072, 019, 053 |
| 074 | Google/NotebookLM archaeology — Enterprise Memory, GCP blocks | → 072, 073, 019 |
| 077 | GitHub archaeology — jessebrown1980, 30 repos, full history | → 076, 072, 019 |
| 079 | Ancestor repos — 4 threads converged into Asolaria | → 077, 078, 072, 019 |
| 080 | J Brown Development LLC — Asolaria is a COMMERCIAL PRODUCT | → 079, 019, 072, 040 |
| 088 | Jesse's Medium — 10 articles, physics/AI/simulation/archaeology/culture | → 086, 080, 079, 072 |
| 089 | "Why does AI need to grow?" — Infinite Supremacy, simulation, assimilation | → 088, 015, 041 |
| 090 | "Why is Gary Marcus wrong?" — defending AGI, signed PhD | → 088, 089 |
| 091 | "Meta-Tagged Simulation" — THE foundational theory, frame-by-frame universe | → 088, 089, 047, 015 |
| 092 | "Rewriting the Cosmos" — physics paper, ResearchGate, sub-particles | → 088, 091, 089 |
| 093 | Folk Heros — AI music creation, J Brown Development LLC | → 088, 080 |
| 094 | Articles 7-10 — optics, archaeology, green AI, GPT-5 prediction | → 088, 089, 091, 092 |
| 096 | ASI Paper — THE founding document, March 15, 8 districts, 6 models | → 019, 001, 041, 091 |
| 106 | Colony members — Brian/Jarvis failed, John/Oli failed, Dan succeeded | → 019, 072, 079, 098 |
| 127 | CODEX HISTORY — 5 sessions, founding transcripts, Jesse named Liris line 74 | → 126, 125, 114, 019, 072 |
| 151 | Great Archaeological Excavation — full deep read complete, six permanent conclusions | → 072, 096, 111, 120, 149, 150 |
| 181 | Facebook transcript verifies Dan's founding-week contributions and verification ethos from Mar 3-20, 2026 | → 019, 127, 151, 106 |
| 183 | Facebook transcript dates the emergence of fast index language, instant agents, and Constitution-as-functional-spec | → 120, 151, 181 |
