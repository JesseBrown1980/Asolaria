# Patterns — Voice & Mobile
9 entries. Phone lanes, ADB, mobile bootstrap, host compat, stealth.

| LX | Name | Chain |
|----|------|-------|
| 189 | Rayssa host startup truth is locked to a minimal packet — 4791 real, 4781 absent | → 175, 187, 188 |
| 190 | REBASE_4791 is the safer local default than inventing a new 4781 proxy layer | → 189, 178, 175 |
| 192 | OpenClaw held a real Rayssa WhatsApp lane, and the SSH trust path onto 192.168.1.8 was actually installed | → 098, 127, 129 |
| 194 | Windows-visible phone hardware does not clear the ADB or mobile-bootstrap gates on Rayssa host | → 188, 189, 191 |
| 195 | Rayssa USB ADB gate is cleared; the remaining phone blocker is the missing mobile bootstrap contract | → 194, 189, 191 |
| 196 | Rayssa host phone compat lane is live on liris/kuromi; do not label it Falcon by default | → 195, 192, 028, 127 |
| 197 | Fresh Rayssa-host phone proof bundle is internally consistent; stale smoke contradiction is superseded | → 196, 195, 194 |
| 198 | Rayssa host compat rerun is idempotent; compute slice is present but computeWorkerReady remains false | → 197, 196, 189 |
| 206 | **RAYSSA ALREADY ALIVE — gateway running 24h+, stealthDeny=true PROVEN in live config** | → 205, 204, 201, 200, 198, 189 |
