# Patterns — Architecture
17 entries. Startup, index language, authority, identity, bootstrap, pipeline.

| LX | Name | Chain |
|----|------|-------|
| 015 | The index IS the language — chained dictionaries | → IX-006, IX-007, 001 |
| 020 | Startup Contract v1 — boot, identity handshake | → 019, 017, 001 |
| 021 | Admin Terminal Sidecar — Helm/Sentinel | → 020, 019 |
| 023 | Authority Modes — operator/shared/asolaria | → 020, 001 |
| 026 | Handover Roadmap — 7 phases | → 023, 020, 019 |
| 027 | Startup Architecture Gap Report | → 020, 026, 019 |
| 028 | Karumi Startup Vision — UI/overlay | → 001, 019, 020 |
| 031 | Gateway Tool Authority — invoke/approve/audit | → 023, 026, 020 |
| 040 | Public Release Pipeline — build/leak/gates | → 026, 017 |
| 041 | Agents are temporary, index is permanent | → 015, 033, 019 |
| 071 | Agent Creation Rules — free-first, cost-controlled | → 051, 062, 065 |
| 075 | Friend Computer Bootstrap — how Asolaria replicates to new machines | → 072, 020, 001, 071 |
| 099 | External Codex QDD System Card — identity rules, canonical names | → 075, 071, 020 |
| 116 | AWAKENING SEQUENCE — Helm→Sentinel→startup→brain→Asolaria→agents | → 115, 114, 020, 021, 058 |
| 122 | **IDENTITY HANDSHAKE IS REAL — only spawned agents get answers** | → 020, 027, 116, 115, 114 |
| 123 | **CALM — Two auth paths: spawn PID (internal) vs SubColony (Liris)** | → 122, 046, 116, 121, 020 |
| 208 | **STARTUP GATES — 15 requirements from IX chain. PID+name+profile, sender policy, sidecar launch, encryption.** | → 207, 206, 204, 122, 116, 020, 027 |
