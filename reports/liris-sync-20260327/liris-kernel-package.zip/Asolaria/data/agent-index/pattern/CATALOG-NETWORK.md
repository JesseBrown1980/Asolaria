# Patterns — Network
12 entries. Ports, MQTT, bridge, comms, security, host reachability.

| LX | Name | Chain |
|----|------|-------|
| 037 | API Hub specs — functional/requirements/technical | → 031, 023, 017 |
| 038 | Gateway Audit Log — hash chain integrity | → 031, 023, 026 |
| 039 | Vault AppRole — machine identities | → 038, 031, 023 |
| 135 | TWO PORT LAYERS — broker (18883) vs encrypted (18886/8788), both correct | → 134, 102, 057, 045, 107 |
| 163 | Jesse host is currently unreachable from Rayssa side on tested ports 4799, 4781, and 18883 | → 162, 112, 129 |
| 164 | Gaia recheck state — no fresh inbound visible, ready packet queued on bus id 62 | → 163, 161, 160 |
| 167 | Bridge port 4799 rationale — role is documented, exact number choice is not | → 112, 129, 161, 164 |
| 170 | Index-language realignment — bridge is transport, index is protocol, self-relay was a language failure | → 015, 153, 169, 167 |
| 172 | Internet still up, Gaia lane down — 192.168.1.5:4799 timed out while 1.1.1.1:443 still connected | → 171, 162, 163, 129 |
| 175 | Asolaria current checkout boots gateway control plane but not legacy 4781 main app shell | → 017, 030, 171 |
| 180 | Updated Plan docx is second-order excavation that confirms manual relay and the 4781 contradiction | → 177, 178 |
| 205 | **NETWORK SHIFT — neighbor WiFi, 192.168.15.x, SSH at .170:22 is the encrypted direct link** | → 204, 112, 129, 203, 001 |
