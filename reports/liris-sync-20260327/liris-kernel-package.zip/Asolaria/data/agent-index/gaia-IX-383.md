---
ix: IX-383
name: TOOL — indexCatalogSync module (MQTT catalog publish/subscribe/search)
type: tool
tags: index, catalog, sync, mqtt, module, search, remote, federation
chain: IX-382, IX-381, IX-338, IX-242
pid: gaia-20260324-unification-orchestrator
createdBy: forge-20260324-catalog-sync
agents: all
---

# indexCatalogSync — Cross-Colony Catalog Sync Module

## Location
`src/indexCatalogSync.js`

## Functions
| Function | Purpose |
|----------|---------|
| buildCatalogSnapshot() | Reads all CATALOG-*.md files, builds JSON summary |
| publishCatalogSnapshot(mqttPublishFn) | Publishes snapshot to MQTT as retained |
| handleRemoteCatalog(nodeId, payload) | Stores received catalog from remote node |
| getRemoteCatalogs() | Returns all stored remote catalogs |
| searchRemoteCatalogs(query) | Keyword search across remote catalog entries |
| getSubscriptionTopics() | Returns MQTT topics to subscribe to |
| getCatalogSyncStatus() | Returns sync health status |

## MQTT Topics
- Publish: `asolaria/nodes/<nodeId>/index/catalog` (retained)
- Subscribe: `asolaria/nodes/+/index/catalog`

## Integration Points
- mqttConnector: subscribe on connect, handle incoming, publish on timer
- agentIndexStore: local search remains unchanged, remote search is additive
- remoteNodeRegistry: catalog data stored alongside node telemetry
