# Tool Catalog — Data

Stores, knowledge, ASO schema, GNN sidecar, connectors, tools directory.

| LX | Name | Chain |
|----|------|-------|
| 024 | Liris skill & tool inventory — 56/150+ | → 001, 017 |
| 043 | Full tools/ scan — 184 files | → 042, 024, 017 |
| 053 | 41 connectors + 4 gateway modules — full integration map | → 051, 044, 024 |
| 152 | Raw Codex archaeological corpus — 26 rollout session files survive beyond history summary | → 127, 126, 151 |
| 154 | ASO unified language schema draft — machine-readable tables, verbs, and sync ops | → 153, 048, 052, 151 |
| 155 | ASO crosswalk seed — legacy LX concepts mapped to canonical keys for Gaia merge | → 153, 154, 015, 041, 149 |
| 156 | ASO topic example — Mongo process-gated surface rendered from verified local facts | → 154, 155, 146, 149 |
| 157 | ASO topic example — direct Gaia-Liris bridge rendered from verified comms facts | → 154, 155, 112, 129, 110 |
| 165 | ASO overlap merge proposal — exact merges, caveats, separations, and research backlog in one table | → 155, 159, 160, 164 |
| 166 | ASO merge packet — typed ops prepared for Gaia-side numbering and relation merge | → 154, 155, 159, 165 |
| 179 | Google Developer Knowledge key from Gaia docx stored in local owner vault | → 176, 177 |
| 227 | Semantic Knowledge Store — vector search and embeddings | → 041, 015 |
| 234 | GNN Sidecar — trained baseline model + service on Jesse's machine | → 223, 120, 115, 091, 061, IX-316 |
| 247 | Tools directory — 194 files including 176 executable scripts | → 230, 242, IX-316 |
| 252 | Liris local data layer — 242MB, 1939 MQTT archives, 14 event streams, vault, reflections | → 248, 237, 054 |
