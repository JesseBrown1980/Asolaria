# Tool Catalog — Voice

Voice pipeline, meeting toolkit, interview copilot.

| LX | Name | Chain |
|----|------|-------|
| 221 | Voice Pipeline — STT/TTS multi-provider with Gemini Live | → 073, 079, 019 |
| 222 | Meeting Intelligence — Symphony + NotebookLM + recording pipeline | → 221, 073, 079, 074 |
| 240 | Interview Copilot — 15619-line stealth meeting assistant with voice injection | → 239, 232, 221, 222, IX-317 |
| 241 | Interview Copilot LOCAL — 1292-line browser UI for meeting assistance | → 240, 232, 221 |
| 242 | Voice/Meeting PowerShell toolkit — 12 scripts for recording and transcription | → 221, 222, 232 |
