# Tool Catalog — UI

Browser UIs, routes, extensions, command center, external platforms.

| LX | Name | Chain |
|----|------|-------|
| 083 | Chrome extensions — Claude, ExpressKeys, Wayback, Web Signer | → 076, 001, 082 |
| 086 | Medium.com mapped — @plasmatoid, AI/ML focus, authenticated | → 085, 080, 077 |
| 243 | Browser UI surfaces — app.js 14K lines, phone-mode, mobile-console, civilization-3d, graph-runtime | → 223, 061 |
| 244 | Route layer — 29 API endpoint files for gateway | → 025, 020 |
| 265 | Three-lane command center — visual agent control with lane dots | → 243, 025, 020 |
