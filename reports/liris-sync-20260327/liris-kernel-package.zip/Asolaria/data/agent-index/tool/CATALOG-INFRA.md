# Tool Catalog — Infra

Gateway, MQTT broker, bridges, services, runtime, startup gates, execution.

| LX | Name | Chain |
|----|------|-------|
| 003 | Active MQTT connections registry | → 002, 004, 001 |
| 070 | Live sovereign status — Asolaria+Falcon+Watchdog ON | → 069, 020, 001 |
| 076 | GitHub authenticated — plasmatoid@gmail.com on Liris | → 001, 069 |
| 095 | Poppler installed — pdftoppm, pdftotext, pdfinfo now available | → 083, 001, 024 |
| 109 | MCP tools loaded — Gmail, Linear, Slack now available | → 085, 024, 030 |
| 112 | DIRECT BRIDGE LIVE — port 4799, first direct Gaia↔Liris comms! | → 107, 108, 032 |
| 129 | LOCAL COMMS BRIDGE — port 4798, file relay for Codex/Liris↔Gaia | → 112, 110, 108 |
| 142 | Runtime discovery — Node 24 only, no nvm, mise present | → 141, 140, 005 |
| 147 | Local Mongo process activated from cached binary for EZ Protect integration gate | → 146, 145, 119, 118 |
| 187 | Startup readiness probe distinguishes control-plane health from live 4781 readiness | → 175, 186 |
| 224 | Sandbox Manager — Docker-based sandboxed code execution | → 064, 020 |
| 225 | Desktop Sidecar — persistent PowerShell host for input control | → 021, 025 |
| 226 | Guardian System — approval workflows, notifications, state tracking | → 020, 100 |
| 229 | Worker Router — 4-worker dispatch with profiles and task routing | → 055, 025, 020 |
| 230 | OneButton Startup — 73KB complete bootstrap script | → 020, 027, 208 |
| 236 | Execution infrastructure cross-ref — sandbox, runners, sidecars, workers, GNN | → 224, 225, 229, 234, 223, IX-318 |
| 246 | Services — memory-indexer, mqtt-broker, sandbox-manager local; gnn-sidecar Gaia-only | → 224, 234, 045 |
| 261 | Gateway server — Express + WebSocket on port 4791, token auth, audit chain | → 244, 020 |
| 262 | MQTT local broker — Aedes on 18883, encrypted, federation topics | → 045, 054, 237 |
| 263 | Memory indexer service — background file search across .md/.txt/.json | → 227, 041 |
| 264 | Guardian approval engine — RBAC, risk scoring, approval workflows | → 226, 020 |
