# Tool Catalog — Phone

Phone mirror, ADB, developer options, mobile bootstrap.

| LX | Name | Chain |
|----|------|-------|
| 188 | Host-scope phone adb realignment removes stale acer-path assumptions from Gaia-critical scripts | → 175, 187 |
