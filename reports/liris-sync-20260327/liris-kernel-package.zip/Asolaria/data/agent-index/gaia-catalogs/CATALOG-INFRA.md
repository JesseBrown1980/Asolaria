# Tools Sub-Catalog — Infrastructure / Services / Broker / Brain / Workers

23 entries.

| IX | Name | Type | Tags | Chain | Agents |
|----|------|------|------|-------|--------|
| 016 | inbox-send.js — agent messaging tool | tool | [inbox, messaging, agents, comms, cli] | [IX-012, IX-009] | all |
| 021 | MQTT bridge to Liris exists | tool | [mqtt, liris, rayssa, bridge, comms] | [IX-016, IX-009, IX-010] | gaia, helm |
| 032 | Chrome extension bridge — Claude Code on work browser | tool | [chrome, claude-code, extension, browser, cross-account] | [IX-014, IX-009, IX-020] | gaia, all |
| 044 | MQTT broker live on 0.0.0.0:18883 | tool | [mqtt, broker, comms, liris, colony-wide, persistent] | [IX-021, IX-009, IX-037] | all |
| 095 | Medium.com browser automation — 10 tools mapped | tool | [medium, browser, automation, tools, dom, accessibility-tree] | [IX-094, IX-078, IX-032] | all |
| 240 | Recent-download-analysis Gemini skill/tool now exists locally with first and deep pass modes | tool | [downloads, gemini, skill, tool, multimodal, video, image, synthesis] | [IX-220, IX-006, IX-219] | all |
| 242 | Indexed memory retrieval now reaches IX documents through workspace knowledge | tool | [agent-index, workspace-knowledge, retrieval, ix-language, api, semantic, memory] | [IX-238, IX-240, IX-006] | all |
| 247 | Liris startup report validator exists locally and gates the next branch choice | tool | [liris, validator, startup-report, powershell, intake, readiness] | [IX-246, IX-244, IX-242] | all |
| 259 | Colony-memory contracts are now wired into runtime retrieval surfaces and prompt context | tool | [colony-memory, runtime, retrieval, workspace-knowledge, semantic, prompt-context, transport-epoch, schema] | [IX-257, IX-258, IX-242] | all |
| 333 | TOOL — External brain connector (7-provider LLM fallback chain) | tool | [brain, llm, anthropic, openai, gemini, vertex, cursor, antigravity, fallback] | [IX-320, IX-318] | vector, helm |
| 334 | TOOL — Worker router (4-worker dispatch: codex, claude, abacus, symphony) | tool | [worker, router, dispatch, codex, claude, abacus, symphony, task] | [IX-333, IX-318, IX-320] | helm, rook |
| 337 | TOOL — Guardian system (approval workflows, risk scoring, alert dispatch) | tool | [guardian, approval, risk, security, alert, workflow] | [IX-318, IX-320, IX-319] | sentinel, helm |
| 338 | TOOL — MQTT broker service (BOOT-CRITICAL colony backbone, ports 18883-18885) | tool | [mqtt, broker, service, boot-critical, colony, backbone, FOUNDATIONAL] | [IX-319, IX-320, IX-309] | all |
| 339 | TOOL — Memory indexer service (agent knowledge persistence, port 5444) | tool | [memory, indexer, service, knowledge, persistence, loopback] | [IX-320, IX-318] | vector, helm |
| 343 | TOOL — OneButton startup cascade (25-step boot, port checks, health verification) | tool | [onebutton, startup, boot, cascade, powershell, FOUNDATIONAL] | [IX-309, IX-320, IX-318] | all |
| 378 | TOOL — ContactOut browser extension launcher (LinkedIn lead enrichment) | tool | [contactout, chrome, browser, extension, linkedin, leads, CRM] | [IX-358, IX-320, IX-316] | rook, forge, falcon |
| 379 | TOOL — HubSpot CRM integration (OAuth flow + connector, portal 51209071) | tool | [hubspot, CRM, oauth, connector, contacts, deals, business] | [IX-358, IX-320, IX-316, IX-337] | rook, forge, vector |
| 380 | TOOL — Google API Hub (OAuth + GCP services + Workspace CLI + API relay) | tool | [google, gcp, oauth, workspace, gmail, calendar, services, API, cloud] | [IX-358, IX-320, IX-316, IX-333, IX-337] | rook, forge, vector, helm |
| 381 | TOOL — spawnContextBuilder orchestrator (PID controller, 7 roles, identity challenge) | tool | [orchestrator, spawn, PID, agent, lifecycle, identity, briefing, FOUNDATIONAL] | [IX-312, IX-313, IX-314, IX-315, IX-321] | helm, all |
| 383 | TOOL — indexCatalogSync module (MQTT catalog publish/subscribe/search) | tool | [index, catalog, sync, mqtt, module, search, remote, federation] | [IX-382, IX-381, IX-338, IX-242] | all |
| 386 | TOOL — Business integrations (Telegram + Slack + Atlassian) | tool | [telegram, slack, atlassian, oauth, messaging, jira] | [IX-358, IX-320, IX-316] | all |
| 387 | TOOL — AI workspace integrations (Abacus + Augment + Symphony + NotebookLM) | tool | [abacus, augment-context, symphony, notebooklm, ai-workspace] | [IX-358, IX-320, IX-316] | all |
| 388 | TOOL — Browser task integrations (OpenAI Web + Gemini Web + MCP cache) | tool | [browser-task, openai, gemini, mcp-cache, chrome] | [IX-358, IX-320, IX-316] | all |
