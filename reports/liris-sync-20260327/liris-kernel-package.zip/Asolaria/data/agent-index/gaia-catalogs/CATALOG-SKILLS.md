# Skills Catalog — Router

37 entries across 2 sub-catalogs.

| Sub-Catalog | Entries | Focus |
|-------------|---------|-------|
| [CATALOG-VOICE.md](CATALOG-VOICE.md) | 5 | Voice, audio, meeting, transcription, TTS, Gemini Live |
| [CATALOG-OPERATIONS.md](CATALOG-OPERATIONS.md) | 30 | Admin, git, testing, security, phone, tools, networking, MQTT |
