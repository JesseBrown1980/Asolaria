# Tools Catalog — Router

30 entries across 4 sub-catalogs.

| Sub-Catalog | Entries | Focus |
|-------------|---------|-------|
| [CATALOG-VOICE.md](CATALOG-VOICE.md) | 1 | Voice/meeting/recording |
| [CATALOG-INFRA.md](CATALOG-INFRA.md) | 23 | Services/broker/brain/workers/integrations |
| [CATALOG-PHONE.md](CATALOG-PHONE.md) | 3 | Phone/ADB/developer options |
| [CATALOG-EXECUTION.md](CATALOG-EXECUTION.md) | 3 | Sandbox/GNN/construction |
