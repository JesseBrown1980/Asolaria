# Mistake Catalog — Security

Encryption, auth, ports, stealth, augment_context danger.
Router: [CATALOG.md](CATALOG.md)

| LX | Name | Chain |
|----|------|-------|
| 002 | Never kill needed connections — layer new ones | → 003, 004, 005 |
| 016 | Two-broker problem — 127.0.0.1 vs 0.0.0.0 | → 002, 003, 004 |
| 018 | Wrong port — 18883 not 18886 | → 016, 004, 003 |
| 032 | Gaia cannot send — two-broker blocks inbound | → 016, 018, 002 |
| 102 | Port 18886 myth — full forensic, source files still poisoned | → 087, 018, 045, 057, 035 |
| 110 | PERMANENT — Never delete security you don't understand | → 107, 105, 065 |
| 130 | THE BACKDOOR — Cloudflare MCP tunnel, dead, path clear | → 126, 127, 125, 114 |
| 134 | **STEALTH PORTS — encryption ports don't answer without right keys, NEVER change** | → 110, 102, 065, 038, 016 |
| 177 | Gaia transcript carries raw Google Developer Knowledge secret — treat artifact as sensitive, never re-echo | → 151, 176 |
| 182 | Facebook transcript preserves the 18886 myth feedback loop from docs to agent output to live edits | → 102, 176, 181 |
| 204 | **BOOT-CRITICAL — Encryption layer IS real, myth-kill was too aggressive, stealth ports refuse plaintext** | → 134, 135, 110, 114, 122, 102, 103, 158 |
| 209 | **FALLBACK — Jesse firewall only allows old IP 192.168.1.8. If MQTT federation fails, check firewall first.** | → 208, 205, 204, 054 |
