# Mistake Catalog — Orchestrator

Planning, dispatch, PID, coverage estimation.
Router: [CATALOG.md](CATALOG.md)

| LX | Name | Chain |
|----|------|-------|
| 035 | Always read founding docs before debugging | → 018, 019, 015 |
| 078 | bank-account-transcrtions = transactions not voice — Java banking | → 077, 072, 035 |
| 081 | Medium/YouTube @plasmatoid — YouTube is different user, Medium blocked | → 080, 077, 035 |
| 082 | Do NOT guess external content — verify before indexing | → 081, 035, 078 |
| 117 | GARBAGE CODEX WARNING — Mar 18 files may be poisoned by Codex 5.1 mini | → 115, 114, 102, 035 |
