# Mistake Catalog — Broken

Broken paths, wrong ports, stale IPs, missing deps.
Router: [CATALOG.md](CATALOG.md)

| LX | Name | Chain |
|----|------|-------|
| 006 | Port collision near-miss — unique status ports | → 002, 003, 004 |
| 008 | Jest ESM import in .js setup — FIXED | → 005, 007 |
| 009 | No Python on Liris — use Node | → 001, 007 |
| 011 | Node 24 breaks @shelf/jest-mongodb | → 005, 008, 010 |
| 014 | No Visual Studio Build Tools — native fail | → 007, 009, 001 |
| 139 | EZ Protect test configs are branch-scoped — not on pnpm10 branch | → 138, 010, 005, 008 |
| 140 | Current pnpm10 install is blocked by native modules on Node 24 | → 014, 138, 139 |
| 146 | EZ Protect integration bypasses jest-mongodb and requires real localhost Mongo | → 145, 144, 143, 138 |
| 158 | Legacy catalog/file mismatch — LX-134 and LX-135 are referenced but missing on disk | → 155, 157, 110 |
| 162 | Gaia direct bridge is timing out from Rayssa side — local 4798 bridge remains healthy | → 161, 160, 157 |
| 173 | eBacMap live auth 500s were missing local app env, not EZ Protect defects | → 148, 145, 140 |
