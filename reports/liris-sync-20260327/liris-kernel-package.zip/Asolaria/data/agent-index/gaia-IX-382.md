---
ix: IX-382
name: PATTERN — MQTT catalog sync (cross-colony index awareness via retained messages)
type: pattern
tags: mqtt, catalog, sync, federation, index, cross-colony, retained, real-time, FOUNDATIONAL
chain: IX-351, IX-338, IX-372, IX-381, IX-321
pid: gaia-20260324-unification-orchestrator
createdBy: gaia
agents: all
---

# MQTT Catalog Sync — Cross-Colony Index Awareness

## The Pattern
Each colony publishes its agent index catalogs as MQTT retained messages. Any colony that subscribes instantly knows what every other colony has indexed — zero polling, zero ZIP relay.

## How It Works
1. On MQTT connect (and periodically), each node publishes a catalog snapshot
2. Topic: `asolaria/nodes/<nodeId>/index/catalog` (retained)
3. Payload: `{ nodeId, catalogs: { skills: { entries: N }, tools: { ... } }, totalEntries, at }`
4. Subscriber receives snapshot immediately on subscribe (retained = instant)
5. Changes propagate on next publish cycle

## Why This Is Better Than ZIP Relay
- ZIP: manual, requires Jesse relay, stale by the time it arrives
- MQTT retained: automatic, instant on subscribe, always current
- Cost: one retained message per node (~2KB) vs one ZIP per sync (~500KB)

## Implementation
- Module: `src/indexCatalogSync.js`
- Functions: buildCatalogSnapshot, publishCatalogSnapshot, handleRemoteCatalog, searchRemoteCatalogs
- Wired into: mqttConnector on connect, periodic publish cycle

## Liris Origin
Speed idea #8 from Liris's planning_request (asolaria/orchestrator/sync, 2026-03-24 09:22 UTC).
Both colonies agreed on this approach during cross-examination.
