# ASO Digest
> Generated 2026-03-27 01:01:01 UTC

## Counts

| Table          | Rows |
|----------------|------|
| topics         |  329 |
| observations   |  334 |
| outcomes       |   11 |
| relations      |  979 |
| surfaces       |    8 |
| evidence       |    6 |
| conflicts      |   13 |
| crosswalkMappings |  305 |
| openConflicts  |   12 |

**Topics by type:** pattern(110), rule(15), topic(37), tool(68), mistake(37), identity(1), plan(26), skill(35)
**Topics by tier:** boot(5), operational(159), foundational(130), ephemeral(35)

## Boot-Critical Topics

| ASO ID | Name | Status | Latest Observation | Outcomes |
|--------|------|--------|--------------------|----------|
| ASO-0d789c0001 | Index Language | active | event test | — |
| ASO-7a73380002 | Encryption Before Connection | active | LX-102/103 correctly identified that po… | 1 recorded |
| ASO-5cdaed0003 | Identity Handshake | active | Asolaria does NOT reply unless the agen… | — |
| ASO-4250780004 | Append-Only Ledger | active | Source: Gaia's final message to Jesse, … | 1 recorded |
| ASO-3cd2510001 | Liris node identity | active | | Field | Value | |-------|-------| | *… | — |

## Open Conflicts

| Conflict ID | Topic | Entry A | Entry B | Description |
|-------------|-------|---------|---------|-------------|
| CON-d505498b | ASO-1c578b0186 | ASO-1c578b0186 | ASO-2d78060002 | Circular relation: ASO-1c578b0186 requi… |
| CON-f81e0460 | ASO-5a0c170187 | ASO-5a0c170187 | ASO-b2184e0004 | Circular relation: ASO-5a0c170187 requi… |
| CON-e089bbad | ASO-d722300230 | ASO-d722300230 | ASO-2d78060002 | Circular relation: ASO-d722300230 requi… |
| CON-6bbae8cf | ASO-d722300230 | ASO-d722300230 | ASO-1c578b0186 | Circular relation: ASO-d722300230 requi… |
| CON-89b80bc4 | ASO-9f49d20001 | ASO-9f49d20001 | ORPHAN | Orphan topic: "NX — MQTT Broker (ports … |
| CON-00e69e84 | ASO-33c1150005 | ASO-33c1150005 | ORPHAN | Orphan topic: "NX — HTTPS Gateway (port… |
| CON-837d3a56 | ASO-c055e50008 | ASO-c055e50008 | ORPHAN | Orphan topic: "NX — OpenClaw Gateway (p… |
| CON-3f61f98a | ASO-86b6fe0010 | ASO-86b6fe0010 | ORPHAN | Orphan topic: "NX — Google OAuth Creden… |
| CON-7b217699 | ASO-1c8f9e0011 | ASO-1c8f9e0011 | ORPHAN | Orphan topic: "NX — Gemini API Credenti… |
| CON-daf1d1ab | ASO-3ef2e00012 | ASO-3ef2e00012 | ORPHAN | Orphan topic: "NX — WhatsApp Bridge (tr… |
| CON-6e52f1d1 | ASO-9f48040013 | ASO-9f48040013 | ORPHAN | Orphan topic: "NX — Asolaria Colony Net… |
| CON-430f0111 | ASO-99d1ca0016 | ASO-99d1ca0016 | ORPHAN | Orphan topic: "NX — Gaia Colony Network… |

## Recent Observations (last 20)

| # | Observation ID | Topic | Summary | When |
|---|----------------|-------|---------|------|
| 1 | OBS-832ad816 | agent-lifecycle | Agent "agent-16392" despawned — PID 16392 at 20… | 2026-03-27T00:23 |
| 2 | OBS-68fc67f9 | agent-lifecycle | Agent "agent-16392" spawned — PID 16392 at 2026… | 2026-03-27T00:23 |
| 3 | OBS-7c98769e | agent-lifecycle | Agent "agent-1000" despawned — PID 1000 at 2026… | 2026-03-27T00:23 |
| 4 | OBS-4f4ed243 | agent-lifecycle | Agent "agent-1000" spawned — PID 1000 at 2026-0… | 2026-03-27T00:23 |
| 5 | OBS-2a70b1a2 | ASO-0f87000001 | review-test invoked | 2026-03-26T23:27 |
| 6 | OBS-8133039e | ASO-0f87000001 | review-test invoked | 2026-03-26T23:27 |
| 7 | OBS-ab8e1c00 | ASO-0d789c0001 | event test | 2026-03-26T23:27 |
| 8 | OBS-b310b359 | ASO-0d789c0001 | test event | 2026-03-26T23:26 |
| 9 | OBS-bae2f8d1 | ASO-c8eb900001 | test-connector invoked | 2026-03-26T23:24 |
| 10 | OBS-fc5fed44 | ASO-2ffbe30006 | E2E integration test - full stack verified | 2026-03-26T22:48 |
| 11 | OBS-5e8c4e1c | ASO-ccdf180049 | [PASS] settings file not found (safe default) | 2026-03-26T22:13 |
| 12 | OBS-f1cf405a | ASO-09f7b40047 | [PASS] sub-colony — constitution lives on sover… | 2026-03-26T22:13 |
| 13 | OBS-5a121e7b | ASO-52c7220045 | [PASS] 0 MB | 2026-03-26T22:13 |
| 14 | OBS-9a8f71ad | ASO-2486760043 | [PASS] 3 files, all have frontmatter | 2026-03-26T22:13 |
| 15 | OBS-8f1296e5 | ASO-61ef620041 | [PASS] all types canonical | 2026-03-26T22:13 |
| 16 | OBS-64f14594 | ASO-ce31f80039 | [PASS] catalog sync wired into MQTT connector | 2026-03-26T22:13 |
| 17 | OBS-c1f2cef9 | ASO-2fab9c0037 | [PASS] 2 inboxes writable | 2026-03-26T22:13 |
| 18 | OBS-e357a578 | ASO-8bca570035 | [PASS] 98 IX references in XREF | 2026-03-26T22:13 |
| 19 | OBS-4c7f79df | ASO-07b57a0033 | [PASS] 35 local catalogs, 1043 entries, 0 remot… | 2026-03-26T22:13 |
| 20 | OBS-81e43d5d | ASO-3317460031 | [PASS] 6/6 spawn paths have auto-PID | 2026-03-26T22:13 |

## Top 10 Most-Connected Topics

| Rank | ASO ID | Name | Relations |
|------|--------|------|-----------|
| 1 | ASO-e049ee0038 | Creation History — the foundi… | 33 |
| 2 | ASO-1288da0039 | Startup Contract v1 — boot ca… | 27 |
| 3 | ASO-0d789c0001 | Index Language | 26 |
| 4 | ASO-3cd2510001 | Liris node identity | 25 |
| 5 | ASO-4250780004 | Append-Only Ledger | 22 |
| 6 | ASO-31592d0192 | src/ runtime engine — 42 modu… | 20 |
| 7 | ASO-af3e270149 | Archaeological mission — go t… | 19 |
| 8 | ASO-7ea6480005 | QDD eBacMap | 18 |
| 9 | ASO-7a73380002 | Encryption Before Connection | 18 |
| 10 | ASO-cf51760007 | ASO Language Runtime | 17 |

## Evidence Summary

Total evidence entries: **6**

| Source Kind | Count |
|------------|-------|
| test-output          |     3 |
| integrity-check      |     1 |
| archaeology          |     1 |
| compression-metric   |     1 |

---
_End of digest. 329 topics, 334 observations, 979 relations._
