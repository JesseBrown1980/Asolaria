---
gmail_message_id: 1890788a7795ccb2
account: plasmatoid@gmail.com
date_header: Thu, 29 Jun 2023 11:22:23 -0300
from: plasma toid <plasmatoid@gmail.com>
to: english@mail.gov.cn
subject: 主题：关于与OneMt合作的询问 Luo Wen, head of the State Administration for Market Regulation
body_sha256: 741dc5ca19c95345c4769f6de65acf8bb8e99a2c11620903d039b7388aa06c9a
snippet: 主题：关于与OneMt合作的询问 亲爱的 Luo Wen， 祝您一切顺利。我是Jesse Brown博士，我以D&amp;J Idiomas的教育总监的身份写信给您。我们目前正在研究中国科技领域，尤其是区块链技术和OneMt平台。 我们的研究旨在更好地了解OneMt与中国各个机构之间的合作范围和深度。因此，我们正在联系中国的不同机构以收集相关信息。我们相信，来自贵机构的洞察将会对我们的研究广度和深度
---

# 主题：关于与OneMt合作的询问 Luo Wen, head of the State Administration for Market Regulation

**From:** plasma toid <plasmatoid@gmail.com>
**To:** english@mail.gov.cn
**Date:** Thu, 29 Jun 2023 11:22:23 -0300
**SHA256:** `741dc5ca19c95345c4769f6de65acf8bb8e99a2c11620903d039b7388aa06c9a`

## Body (extracted text)

主题：关于与OneMt合作的询问 亲爱的 Luo Wen， 祝您一切顺利。我是Jesse Brown博士，我以D&J Idiomas的教育总监的身份写信给您。我们目前正在研究中国科技领域，尤其是区块链技术和OneMt平台。 我们的研究旨在更好地了解OneMt与中国各个机构之间的合作范围和深度。因此，我们正在联系中国的不同机构以收集相关信息。我们相信，来自贵机构的洞察将会对我们的研究广度和深度产生重要贡献。 请您告知贵机构是否与OneMt有任何正在进行的合作或伙伴关系？对于合作的性质、正在进行的项目以及这些合作的影响，我们将非常感激您提供的任何详细信息。 我们了解您非常忙碌，对您提供的任何时间和信息，我们都非常感激。如果对您更方便的话，我们很乐意安排一个适合您的时间进行电话或会面，以进一步讨论此事。 感谢您考虑我们的请求。我们期待您的积极回复。 此致 Jesse Brown +55 19 999 4636 75 plasmatoid@gmail.com === HTML PART === 主题：关于与OneMt合作的询问 亲爱的 Luo Wen， 祝您一切顺利。我是Jesse Brown博士，我以D&J Idiomas的教育总监的身份写信给您。我们目前正在研究中国科技领域，尤其是区块链技术和OneMt平台。 我们的研究旨在更好地了解OneMt与中国各个机构之间的合作范围和深度。因此，我们正在联系中国的不同机构以收集相关信息。我们相信，来自贵机构的洞察将会对我们的研究广度和深度产生重要贡献。 请您告知贵机构是否与OneMt有任何正在进行的合作或伙伴关系？对于合作的性质、正在进行的项目以及这些合作的影响，我们将非常感激您提供的任何详细信息。 我们了解您非常忙碌，对您提供的任何时间和信息，我们都非常感激。如果对您更方便的话，我们很乐意安排一个适合您的时间进行电话或会面，以进一步讨论此事。 感谢您考虑我们的请求。我们期待您的积极回复。 此致 Jesse Brown +55 19 999 4636 75 plasmatoid@gmail.com

## Raw body (tamper-evident)

```
主题：关于与OneMt合作的询问

亲爱的 Luo Wen，

祝您一切顺利。我是Jesse Brown博士，我以D&J
Idiomas的教育总监的身份写信给您。我们目前正在研究中国科技领域，尤其是区块链技术和OneMt平台。

我们的研究旨在更好地了解OneMt与中国各个机构之间的合作范围和深度。因此，我们正在联系中国的不同机构以收集相关信息。我们相信，来自贵机构的洞察将会对我们的研究广度和深度产生重要贡献。

请您告知贵机构是否与OneMt有任何正在进行的合作或伙伴关系？对于合作的性质、正在进行的项目以及这些合作的影响，我们将非常感激您提供的任何详细信息。

我们了解您非常忙碌，对您提供的任何时间和信息，我们都非常感激。如果对您更方便的话，我们很乐意安排一个适合您的时间进行电话或会面，以进一步讨论此事。

感谢您考虑我们的请求。我们期待您的积极回复。

此致

Jesse Brown
+55 19 999 4636 75
plasmatoid@gmail.com


=== HTML PART ===
<div dir="auto">主题：关于与OneMt合作的询问<div dir="auto"><br></div><div dir="auto">亲爱的 Luo Wen，</div><div dir="auto"><br></div><div dir="auto">祝您一切顺利。我是Jesse Brown博士，我以D&amp;J Idiomas的教育总监的身份写信给您。我们目前正在研究中国科技领域，尤其是区块链技术和OneMt平台。</div><div dir="auto"><br></div><div dir="auto">我们的研究旨在更好地了解OneMt与中国各个机构之间的合作范围和深度。因此，我们正在联系中国的不同机构以收集相关信息。我们相信，来自贵机构的洞察将会对我们的研究广度和深度产生重要贡献。</div><div dir="auto"><br></div><div dir="auto">请您告知贵机构是否与OneMt有任何正在进行的合作或伙伴关系？对于合作的性质、正在进行的项目以及这些合作的影响，我们将非常感激您提供的任何详细信息。</div><div dir="auto"><br></div><div dir="auto">我们了解您非常忙碌，对您提供的任何时间和信息，我们都非常感激。如果对您更方便的话，我们很乐意安排一个适合您的时间进行电话或会面，以进一步讨论此事。</div><div dir="auto"><br></div><div dir="auto">感谢您考虑我们的请求。我们期待您的积极回复。</div><div dir="auto"><br></div><div dir="auto">此致</div><div dir="auto"><br></div><div dir="auto">Jesse Brown</div><div dir="auto">+55 19 999 4636 75</div><div dir="auto"><a href="mailto:plasmatoid@gmail.com">plasmatoid@gmail.com</a></div></div>


```
