---
gmail_message_id: 19011ea726757673
account: plasmatoid@gmail.com
date_header: Thu, 13 Jun 2024 11:04:53 -0300
from: Jesse Daniel Brown <plasmatoid@gmail.com>
to: "faleconosco@consumidor.gov.br" <faleconosco@consumidor.gov.br>
subject: Re: Mensagem do Fale Conosco.
body_sha256: 67ff181a9d5b30a4efa3b0bd19c3808b92145bd508d7db2094534b57351d1515
snippet: Can you provide the link where I can refile the complaint directly? I need to file this complaint as the company is breaking the law. Jesse On Thu, Jun 13, 2024 at 9:43 AM faleconosco@consumidor.gov.br
---

# Re: Mensagem do Fale Conosco.

**From:** Jesse Daniel Brown <plasmatoid@gmail.com>
**To:** "faleconosco@consumidor.gov.br" <faleconosco@consumidor.gov.br>
**Date:** Thu, 13 Jun 2024 11:04:53 -0300
**SHA256:** `67ff181a9d5b30a4efa3b0bd19c3808b92145bd508d7db2094534b57351d1515`

## Body (extracted text)

Can you provide the link where I can refile the complaint directly? I need to file this complaint as the company is breaking the law. Jesse On Thu, Jun 13, 2024 at 9:43 AM faleconosco@consumidor.gov.br wrote: > Prezado(a) Consumidor(a), > > Pedimos que realize sua reclamação na Plataforma do consumidor.gov.br, > haja vista que o Fale Conosco/ Suporte não se configura como canal para > resolução de demandas individuais, porque este é o serviço prestado pelo > sítio. > > O consumidor.gov.br propõe a prestação de um serviço que visa a resolução > alternativa de conflitos de consumo pela internet, a partir da ação > integrada entre a Secretaria Nacional do Consumidor (SENACON) do Ministério > da Justiça, Procons, Ministérios Públicos, Defensorias Públicas, Tribunais > de Justiça e empresas participantes. > > Considerando que o foco da plataforma é promover a comunicação direta > entre consumidores e fornecedores de produtos e serviços de consumo, a > participação das empresas é voluntária e só permitida àquelas que aderem > formalmente ao serviço, mediante assinatura de Termo de Adesão e > Compromisso, no qual se comprometem a conhecer, analisar e investir todos > os esforços disponíveis para a solução dos problemas apresentados. Deste > modo, se a empresa não fizer parte da plataforma, o consumidor não terá a > oportunidade de tentar solucionar seu problema. > > *Antes de registrar uma reclamação*, leia os Termos de Uso > , as Perguntas > Frequentes e as Orientações > de Uso da plataforma. > > *Para registrar uma reclamação*, o consumidor deverá primeiramente > consultar se a empresa está ou não cadastrada, indo no campo “pesquise a > empresa”, representado por uma barra de pesquisa na página principal > , ou na aba “Empresas > participantes > ”. > > Caso a empresa esteja cadastrada, o consumidor pode clicar sobre o nome > dela e, na próxima página, clicar no botão “Nova Reclamação”. Após esse > passo, será necessário realizar login na plataforma, mediante uso da sua > Conta gov.br. Caso ainda não possua, crie sua conta em: Governo Digital > > > ATENÇÃO! É necessário ter uma conta gov.br *nível PRATA ou OURO* para > registrar e acompanhar suas reclamações no Consumidor.gov.br. Para > verificar o nível de sua conta, basta acessar a Conta Gov.br > https://contas.acesso.gov.br > , > clicar em "Privacidade" > "*Selos de Confiabilidade*". > > Reclamações também podem ser registradas diretamente no menu do usuário. > > Conforme os Termos de Uso do site (item 4), as reclamações só podem ser > registradas pelo titular do serviço (por exemplo, o contratante do serviço > ou a pessoa cujo nome aparece na nota fiscal do produto adquirido). > > É possível indicar um representante legal da pessoa física para atuar como > intermediador. Neste caso, o consumidor deve realizar o registro da > reclamação na plataforma e, após, anexar uma procuração indicando a pessoa > que está autorizada a intermediar a negociação. > > *Para acompanhar sua reclamação*, acesse o sistema com a conta gov.br. Ao > acessar sua área, clique no botão *"Menu"*, que está localizado no canto > superior esquerdo da tela. Depois, clique na opção *"Reclamações". *Na > coluna "Protocolo", clique no número desejado, para visualizar detalhes da > sua reclamação. > > A partir do registro de sua reclamação, a empresa tem *até 10 dias *para > analisá-la e respondê-la. Com a resposta do fornecedor, o consumidor tem *até > 20 dias* para conversar e negociar com a empresa, por meio do > botão “Interagir com o Fornecedor” e anexar até 5 arquivos (com 1 MB por > documento). As interações e a resposta postadas pela empresa são > visualizadas ao clicar no botão azul “*Detalhes*” e no > botão “Anexos”, que estão localizados na coluna “Ações” dessa mesma página. Se > desejar uma impressão da reclamação, clique no ícone *"imprimir"*, > localizado no canto superior direito da página. > > O site do Consumidor.gov está limitado para anexar apenas *5 arquivos* (1 > mb por anexo), sendo que o nome do anexo tem que possuir menos de 80 > caracteres. São aceitas apenas as seguintes extensões de arquivos: pdf, doc > e docx, xls e xlsx, jpg e gif, odt e ods, txt. É importante que seu > conteúdo esteja legível. Caso precise enviar mais do que o > disponibilizado pelo site, solicite, por meio do botão “Interagir com o > Fornecedor”, algum e-mail do Fornecedor para enviar o restante dos > arquivos. > > *Para avaliar a resposta*, clique em “Avaliar Resposta do Fornecedor”. > Esta opção deve ser utilizada nos casos em que o consumidor considerar a > demanda resolvida antes dos 20 dias de prazo, ou ao final do prazo de 20 > dias para demandas resolvidas ou não resolvidas. Nesta ocasião, o > consumidor poderá fazer uma última manifestação sobre o > atendimento/resposta prestado pela empresa. *O consumidor tem apenas uma > oportunidade para avaliar e, com sua avaliação, a reclamação é finalizada, > não sendo mais possível interagir com a empresa, reabrir a reclamação ou > alterar a avaliação registrada.* > > Com a avaliação ou expirado o prazo de 20 dias, sua reclamação é > finalizada e receberá o status de “Finalizada Avaliada”, caso tenha sido > encerrada com sua avaliação, ou “Finalizada Não Avaliada”, caso tenha sido > encerrada em função do fim do prazo mencionado. > > *Sobre o Consumidor.gov.br* > > O consumidor.gov.br > é um serviço > público para solução de conflitos de consumo por meio da internet, que > permite a interlocução direta entre os consumidores e as empresas > cadastradas. As informações do site auxiliam o Poder Público na elaboração > e implementação de políticas públicas de defesa dos consumidores, e > incentivam a competitividade no mercado pela melhoria da qualidade e do > atendimento ao consumidor. O Fale Conosco é o canal dedicado a auxiliar o > consumidor a utilizar a plataforma de maneira eficiente. > > O serviço disponibilizado na plataforma é exclusivo para interação entre > empresas e consumidores, sem a intervenção de um órgão de defesa do > consumidor, como os Procons, Defensoria Pública ou Juizados Especiais. Para > orientações a respeito da existência de direitos, denúncias, reclamações em > face de empresas não participantes ou no caso de não solução do problema, > recomendamos que o consumidor busque o apoio dos canais tradicionais de > atendimento providos pelos Procons Estaduais e Municipais, Defensorias > Públicas, Juizados Especiais Cíveis, entre outros órgãos do Sistema > Nacional de Defesa do Consumidor. > > Para saber mais sobre o consumidor.gov.br > , acesse a > seção Sobre o Serviço > , os Termos de Uso > e leia o Guia do > Usuário, na aba Publicações > . Para tirar dúvidas > sobre as formas de uso, cadastro, prazos de resposta e outros assuntos, > consulte as Perguntas Frequentes > e as Orientações de > Uso . > > Atenciosamente, > > > > *Por favor não responda este e-mail.* > > *Caso haja necessidade de novo contato, por favor acesse **www.consumidor.gov.br > ** e clique > em Fale Conosco. * > > > Em qua., 12 de jun. de 2024 às 18:57, escreveu: > >> Consumidor.gov.br >> Mensagem do Fale Conosco. >> >> Nome: Jesse Daniel Brown >> Email: plasmatoid@gmail.com >> Cidade: Indaiatuba/SP >> Telefone Celular: (Sem Telefone) >> Telefone Residencial: (19) 99946-3675 >> Credenciada: (Sem Credenciada) >> >> >> *3 - Empresa não cadastrada na Plataforma* >> >> *Prezados, Venho por meio desta denunciar a seguradora Sura Seguros pelo >> tratamento inadequado e pela má-fé no tratamento do sinistro nº >> 02.310.24.1784, referente ao acidente ocorrido em 13/12/2023. Apesar de ter >> enviado todos os documentos solicitados, a seguradora insiste em alegar a >> ausência de documentos e a indisponibilidade do veículo para inspeção. >> Gostaria de esclarecer os seguintes pontos: 1. **Danos Corporais**: - >> Devido às dificuldades financeiras e de transporte decorrentes do acidente, >> não pude fornecer laudos periciais e médicos completos. No entanto, as >> internações e o atendimento médico foram consequência direta do acidente. >> Anexei cópias do RG e CPF das vítimas, que já foram enviados anteriormente. >> 2. **Lucros Cessantes**: - A oficina onde o veículo está localizado >> confirmou que o carro está disponível para inspeção. Temos gravações e >> comunicações documentadas mostrando que inspetores foram agendados para >> verificar o veículo. Além disso, a inspeção foi realizada por mecânicos >> independentes, fornecendo orçamentos de reparo de R$ 30.000 e R$ 32.000. 3. >> **Danos Materiais**: - O carro foi rebocado para o pátio do DETRAN porque >> eu e minha esposa fomos levados de ambulância ao hospital. O pátio >> confirmou que a inspeção pode ser realizada no local. A alegação da >> seguradora de que a inspeção não poderia ser realizada é infundada e >> demonstra falta de boa-fé. 4. **Má-Fé e Falta de Resolução**: - A >> seguradora não reavaliou a proposta de compensação, que não cobre os custos >> e perdas documentadas resultantes do acidente. A oferta de R$ 55.000 é >> insuficiente e não corresponde às nossas perdas. Solicito a intervenção da >> SUSEP para que a seguradora Sura Seguros seja responsabilizada por suas >> ações e para que o sinistro seja resolvido de maneira justa e conforme as >> leis aplicáveis, incluindo os artigos 6º e 14 do Código de Defesa do >> Consumidor. * >> >> >> >> * Esta é uma mensagem automática, por favor, não responda. * >> >> Atenciosamente, >> Consumidor.gov.br >> Copyright © 2014 >> > === HTML PART === Can you provide the link where I can refile the complaint directly? I need to file this complaint as the company is breaking the law. Jesse On Thu, Jun 13, 2024 at 9:43 AM faleconosco@consumidor.gov.br < faleconosco@consumidor.gov.br > wrote: Prezado(a) Consumidor(a), Pedimos que realize sua reclamação na Plataforma do consumidor.gov.br , haja vista que o Fale Conosco/ Suporte não se configura como canal para resolução de demandas individuais, porque este é o serviço prestado pelo sítio. O consumidor.gov.br propõe a prestação de um serviço que visa a resolução alternativa de conflitos de consumo pela internet, a partir da ação integrada entre a Secretaria Nacional do Consumidor (SENACON) do Ministério da Justiça, Procons, Ministérios Públicos, Defensorias Públicas, Tribunais de Justiça e empresas participantes. Considerando que o foco da plataforma é promover a comunicação direta entre consumidores e fornecedores de produtos e serviços de consumo, a participação das empresas é voluntária e só permitida àquelas que aderem formalmente ao serviço, mediante assinatura de Termo de Adesão e Compromisso, no qual se comprometem a conhecer, analisar e investir todos os esforços disponíveis para a solução dos problemas apresentados. Deste modo, se a empresa não fizer parte da plataforma, o consumidor não terá a oportunidade de tentar solucionar seu problema. Antes de registrar uma reclamação , leia os Termos de Uso , as Perguntas Frequentes e as Orientações de Uso da plataforma. Para registrar uma reclamação , o consumidor deverá primeiramente consultar se a empresa está ou não cadastrada, indo no campo “pesquise a empresa”, representado por uma barra de pesquisa na página principal , ou na aba “ Empresas participantes ”. Caso a empresa esteja cadastrada, o consumidor pode clicar sobre o nome dela e, na próxima página, clicar no botão “Nova Reclamação”. Após esse passo, será necessário realizar login na plataforma, mediante uso da sua Conta gov.br . Caso ainda não possua, crie sua conta em: Governo Digital ATENÇÃO! É necessário ter uma conta gov.br nível PRATA ou OURO para registrar e acompanhar suas reclamações no Consumidor.gov.br . Para verificar o nível de sua conta, basta acessar a Conta Gov.br https://contas.acesso.gov.br , clicar em &quot;Privacidade&quot; > &quot; Selos de Confiabilidade &quot;. Reclamações também podem ser registradas diretamente no menu do usuário. Conforme os Termos de Uso do site (item 4), as reclamações só podem ser registradas pelo titular do serviço (por exemplo, o contratante do serviço ou a pessoa cujo nome aparece na nota fiscal do produto adquirido). É possível indicar um representante legal da pessoa física para atuar como intermediador. Neste caso, o consumidor deve realizar o registro da reclamação na plataforma e, após, anexar uma procuração indicando a pessoa que está autorizada a intermediar a negociação. Para acompanhar sua reclamação , acesse o sistema com a conta gov.br . Ao acessar sua área, clique no botão &quot;Menu&quot; , que está localizado no canto superior esquerdo da tela. Depois, clique na opção &quot;Reclamações&quot;. Na coluna &quot;Protocolo&quot;, clique no número desejado, para visualizar detalhes da sua reclamação. A partir do registro de sua reclamação, a empresa tem até 10 dias para analisá-la e respondê-la. Com a resposta do fornecedor, o consumidor tem até 20 dias para conversar e negociar com a empresa, por meio do botão “Interagir com o Fornecedor” e anexar até 5 arquivos (com 1 MB por documento). As interações e a resposta postadas pela empresa são visualizadas ao clicar no botão azul “ Detalhes ” e no botão “Anexos”, que estão localizados na coluna “Ações” dessa mesma página. Se desejar uma impressão da reclamação, clique no ícone &quot;imprimir&quot; , localizado no canto superior direito da página. O site do Consumidor.gov está limitado para anexar apenas 5 arquivos (1 mb por anexo), sendo que o nome do anexo tem que possuir menos de 80 caracteres. São aceitas apenas as seguintes extensões de arquivos: pdf, doc e docx, xls e xlsx, jpg e gif, odt e ods, txt. É importante que seu conteúdo esteja legível. Caso precise enviar mais do que o disponibilizado pelo site, solicite, por meio do botão “Interagir com o Fornecedor”, algum e-mail do Fornecedor para enviar o restante dos arquivos. Para avaliar a resposta , clique em “Avaliar Resposta do Fornecedor”. Esta opção deve ser utilizada nos casos em que o consumidor considerar a demanda resolvida antes dos 20 dias de prazo, ou ao final do prazo de 20 dias para demandas resolvidas ou não resolvidas. Nesta ocasião, o consumidor poderá fazer uma última manifestação sobre o atendimento/resposta prestado pela empresa. O consumidor tem apenas uma oportunidade para avaliar e, com sua avaliação, a reclamação é finalizada, não sendo mais possível interagir com a empresa, reabrir a reclamação ou alterar a avaliação registrada. Com a avaliação ou expirado o prazo de 20 dias, sua reclamação é finalizada e receberá o status de “Finalizada Avaliada”, caso tenha sido encerrada com sua avaliação, ou “Finalizada Não Avaliada”, caso tenha sido encerrada em função do fim do prazo mencionado. Sobre o Consumidor.gov.br O consumidor.gov.br é um serviço público para solução de conflitos de consumo por meio da internet, que permite a interlocução direta entre os consumidores e as empresas cadastradas. As informações do site auxiliam o Poder Público na elaboração e implementação de políticas públicas de defesa dos consumidores, e incentivam a competitividade no mercado pela melhoria da qualidade e do atendimento ao consumidor. O Fale Conosco é o canal dedicado a auxiliar o consumidor a utilizar a plataforma de maneira eficiente. O serviço disponibilizado na plataforma é exclusivo para interação entre empresas e consumidores, sem a intervenção de um órgão de defesa do consumidor, como os Procons, Defensoria Pública ou Juizados Especiais. Para orientações a respeito da existência de direitos, denúncias, reclamações em face de empresas não participantes ou no caso de não solução do problema, recomendamos que o consumidor busque o apoio dos canais tradicionais de atendimento providos pelos Procons Estaduais e Municipais, Defensorias Públicas, Juizados Especiais Cíveis, entre outros órgãos do Sistema Nacional de Defesa do Consumidor. Para saber mais sobre o consumidor.gov.br , acesse a seção Sobre o Serviço , os Termos de Uso e leia o Guia do Usuário, na aba Publicações . Para tirar dúvidas sobre as formas de uso, cadastro, prazos de resposta e outros assuntos, consulte as Perguntas Frequentes e as Orientações de Uso . Atenciosamente, Por favor não responda este e-mail. Caso haja necessidade de novo contato, por favor acesse www.consumidor.gov.br e clique em Fale Conosco. Em qua., 12 de jun. de 2024 às 18:57, < admin@consumidor.gov.br > escreveu: Consumidor .gov.br Mensagem do Fale Conosco. Nome: Jesse Daniel Brown Email: plasmatoid@gmail.com Cidade: Indaiatuba/SP Telefone Celular: (Sem Telefone) Telefone Residencial: (19) 99946-3675 Credenciada: (Sem Credenciada) 3 - Empresa não cadastrada na Plataforma Prezados, Venho por meio desta denunciar a seguradora Sura Seguros pelo tratamento inadequado e pela má-fé no tratamento do sinistro nº 02.310.24.1784, referente ao acidente ocorrido em 13/12/2023. Apesar de ter enviado todos os documentos solicitados, a seguradora insiste em alegar a ausência de documentos e a indisponibilidade do veículo para inspeção. Gostaria de esclarecer os seguintes pontos: 1. **Danos Corporais**: - Devido às dificuldades financeiras e de transporte decorrentes do acidente, não pude fornecer laudos periciais e médicos completos. No entanto, as internações e o atendimento médico foram consequência direta do acidente. Anexei cópias do RG e CPF das vítimas, que já foram enviados anteriormente. 2. **Lucros Cessantes**: - A oficina onde o veículo está localizado confirmou que o carro está disponível para inspeção. Temos gravações e comunicações documentadas mostrando que inspetores foram agendados para verificar o veículo. Além disso, a inspeção foi realizada por mecânicos independentes, fornecendo orçamentos de reparo de R$ 30.000 e R$ 32.000. 3. **Danos Materiais**: - O carro foi rebocado para o pátio do DETRAN porque eu e minha esposa fomos levados de ambulância ao hospital. O pátio confirmou que a inspeção pode ser realizada no local. A alegação da seguradora de que a inspeção não poderia ser realizada é infundada e demonstra falta de boa-fé. 4. **Má-Fé e Falta de Resolução**: - A seguradora não reavaliou a proposta de compensação, que não cobre os custos e perdas documentadas resultantes do acidente. A oferta de R$ 55.000 é insuficiente e não corresponde às nossas perdas. Solicito a intervenção da SUSEP para que a seguradora Sura Seguros seja responsabilizada por suas ações e para que o sinistro seja resolvido de maneira justa e conforme as leis aplicáveis, incluindo os artigos 6º e 14 do Código de Defesa do Consumidor. Esta é uma mensagem automática, por favor, não responda. Atenciosamente, Consumidor.gov.br Copyright © 2014

## Raw body (tamper-evident)

```
Can you provide the link where I can refile the complaint directly?
I need to file this complaint as the company is breaking the law.
Jesse

On Thu, Jun 13, 2024 at 9:43 AM faleconosco@consumidor.gov.br <
faleconosco@consumidor.gov.br> wrote:

> Prezado(a) Consumidor(a),
>
> Pedimos que realize sua reclamação na Plataforma do consumidor.gov.br,
> haja vista que o Fale Conosco/ Suporte não se configura como canal para
> resolução de demandas individuais, porque este é o serviço prestado pelo
> sítio.
>
> O consumidor.gov.br propõe a prestação de um serviço que visa a resolução
> alternativa de conflitos de consumo pela internet, a partir da ação
> integrada entre a Secretaria Nacional do Consumidor (SENACON) do Ministério
> da Justiça, Procons, Ministérios Públicos, Defensorias Públicas, Tribunais
> de Justiça e empresas participantes.
>
> Considerando que o foco da plataforma é promover a comunicação direta
> entre consumidores e fornecedores de produtos e serviços de consumo, a
> participação das empresas é voluntária e só permitida àquelas que aderem
> formalmente ao serviço, mediante assinatura de Termo de Adesão e
> Compromisso, no qual se comprometem a conhecer, analisar e investir todos
> os esforços disponíveis para a solução dos problemas apresentados. Deste
> modo, se a empresa não fizer parte da plataforma, o consumidor não terá a
> oportunidade de tentar solucionar seu problema.
>
> *Antes de registrar uma reclamação*, leia os Termos de Uso
> <https://consumidor.gov.br/pages/conteudo/publico/7>, as Perguntas
> Frequentes <https://consumidor.gov.br/pages/conteudo/publico/3> e as Orientações
> de Uso <https://consumidor.gov.br/pages/conteudo/publico/8> da plataforma.
>
> *Para registrar uma reclamação*, o consumidor deverá primeiramente
> consultar se a empresa está ou não cadastrada, indo no campo “pesquise a
> empresa”, representado por uma barra de pesquisa na página principal
> <https://consumidor.gov.br/pages/principal/?1603162011812>, ou na aba “Empresas
> participantes
> <https://consumidor.gov.br/pages/principal/empresas-participantes>”.
>
> Caso a empresa esteja cadastrada, o consumidor pode clicar sobre o nome
> dela e, na próxima página, clicar no botão “Nova Reclamação”. Após esse
> passo, será necessário realizar login na plataforma, mediante uso da sua
> Conta gov.br. Caso ainda não possua, crie sua conta em: Governo Digital
> <https://www.gov.br/governodigital/pt-br/conta-gov-br/conta-gov-br/>
>
> ATENÇÃO! É necessário ter uma conta gov.br *nível PRATA ou OURO* para
> registrar e acompanhar suas reclamações no Consumidor.gov.br. Para
> verificar o nível de sua conta, basta acessar a Conta Gov.br
> https://contas.acesso.gov.br
> <https://nam02.safelinks.protection.outlook.com/?url=https%3A%2F%2Fcontas.acesso.gov.br%2F&data=04%7C01%7CGREICEMARTINEZ%40natura.net%7Caf6121bc69d04339554108d9c6181752%7Cb9203540bfb147a29e2bd73ec0debf49%7C0%7C0%7C637758629076023422%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000&sdata=y%2BHwv%2BdUmJDG8xUnb8j4NDsO53LxJ6X8xa9lDTx%2F1UM%3D&reserved=0> ,
> clicar em "Privacidade" > "*Selos de Confiabilidade*".
>
> Reclamações também podem ser registradas diretamente no menu do usuário.
>
> Conforme os Termos de Uso do site (item 4), as reclamações só podem ser
> registradas pelo titular do serviço (por exemplo, o contratante do serviço
> ou a pessoa cujo nome aparece na nota fiscal do produto adquirido).
>
> É possível indicar um representante legal da pessoa física para atuar como
> intermediador. Neste caso, o consumidor deve realizar o registro da
> reclamação na plataforma e, após, anexar uma procuração indicando a pessoa
> que está autorizada a intermediar a negociação.
>
> *Para acompanhar sua reclamação*, acesse o sistema com a conta gov.br.  Ao
> acessar sua área, clique no botão *"Menu"*, que está localizado no canto
> superior esquerdo da tela. Depois, clique na opção *"Reclamações". *Na
> coluna "Protocolo", clique no número desejado, para visualizar detalhes da
> sua reclamação.
>
> A partir do registro de sua reclamação, a empresa tem *até 10 dias *para
> analisá-la e respondê-la. Com a resposta do fornecedor, o consumidor tem *até
> 20 dias* para conversar e negociar com a empresa, por meio do
> botão “Interagir com o Fornecedor” e anexar até 5 arquivos (com 1 MB por
> documento). As interações e a resposta postadas pela empresa são
> visualizadas ao clicar no botão azul “*Detalhes*” e no
> botão “Anexos”, que estão localizados na coluna “Ações” dessa mesma página. Se
> desejar uma impressão da reclamação, clique no ícone *"imprimir"*,
> localizado no canto superior direito da página.
>
> O site do Consumidor.gov está limitado para anexar apenas *5 arquivos* (1
> mb por anexo), sendo que o nome do anexo tem que possuir menos de 80
> caracteres. São aceitas apenas as seguintes extensões de arquivos: pdf, doc
> e docx, xls e xlsx, jpg e gif, odt e ods, txt. É importante que seu
> conteúdo esteja legível.  Caso precise enviar mais do que o
> disponibilizado pelo site, solicite, por meio do botão “Interagir com o
> Fornecedor”, algum e-mail do Fornecedor para enviar o restante dos
> arquivos.
>
> *Para avaliar a resposta*, clique em “Avaliar Resposta do Fornecedor”.
> Esta opção deve ser utilizada nos casos em que o consumidor considerar a
> demanda resolvida antes dos 20 dias de prazo, ou ao final do prazo de 20
> dias para demandas resolvidas ou não resolvidas. Nesta ocasião, o
> consumidor poderá fazer uma última manifestação sobre o
> atendimento/resposta prestado pela empresa.  *O consumidor tem apenas uma
> oportunidade para avaliar e, com sua avaliação, a reclamação é finalizada,
> não sendo mais possível interagir com a empresa, reabrir a reclamação ou
> alterar a avaliação registrada.*
>
> Com a avaliação ou expirado o prazo de 20 dias, sua reclamação é
> finalizada e receberá o status de “Finalizada Avaliada”, caso tenha sido
> encerrada com sua avaliação, ou “Finalizada Não Avaliada”, caso tenha sido
> encerrada em função do fim do prazo mencionado.
>
> *Sobre o Consumidor.gov.br*
>
> O consumidor.gov.br
> <https://consumidor.gov.br/pages/principal/?1603378652139> é um serviço
> público para solução de conflitos de consumo por meio da internet, que
> permite a interlocução direta entre os consumidores e as empresas
> cadastradas.  As informações do site auxiliam o Poder Público na elaboração
> e implementação de políticas públicas de defesa dos consumidores, e
> incentivam a competitividade no mercado pela melhoria da qualidade e do
> atendimento ao consumidor. O Fale Conosco é o canal dedicado a auxiliar o
> consumidor a utilizar a plataforma de maneira eficiente.
>
> O serviço disponibilizado na plataforma é exclusivo para interação entre
> empresas e consumidores, sem a intervenção de um órgão de defesa do
> consumidor, como os Procons, Defensoria Pública ou Juizados Especiais. Para
> orientações a respeito da existência de direitos, denúncias, reclamações em
> face de empresas não participantes ou no caso de não solução do problema,
> recomendamos que o consumidor busque o apoio dos canais tradicionais de
> atendimento providos pelos Procons Estaduais e Municipais, Defensorias
> Públicas, Juizados Especiais Cíveis, entre outros órgãos do Sistema
> Nacional de Defesa do Consumidor.
>
> Para saber mais sobre o consumidor.gov.br
> <https://consumidor.gov.br/pages/principal/?1603378652139>, acesse a
> seção Sobre o Serviço
> <https://consumidor.gov.br/pages/conteudo/sobre-servico>, os Termos de Uso
> <https://consumidor.gov.br/pages/conteudo/publico/7> e leia o Guia do
> Usuário, na aba Publicações
> <https://consumidor.gov.br/pages/publicacao/externo/>. Para tirar dúvidas
> sobre as formas de uso, cadastro, prazos de resposta e outros assuntos,
> consulte as Perguntas Frequentes
> <https://consumidor.gov.br/pages/conteudo/publico/3> e as Orientações de
> Uso <https://consumidor.gov.br/pages/conteudo/publico/8>.
>
> Atenciosamente,
>
>   <https://www.consumidor.gov.br/pages/principal/?1403644411677>
>
> *Por favor não responda este e-mail.*
>
> *Caso haja necessidade de novo contato, por favor acesse **www.consumidor.gov.br
> <https://www.consumidor.gov.br/pages/principal/?1403644411677>** e clique
> em Fale Conosco. *
>
>
> Em qua., 12 de jun. de 2024 às 18:57, <admin@consumidor.gov.br> escreveu:
>
>> Consumidor.gov.br <#m_-5280850186187427277_m_-2780517350210443151_>
>> Mensagem do Fale Conosco.
>> <#m_-5280850186187427277_m_-2780517350210443151_>
>> Nome: Jesse Daniel Brown
>> Email: plasmatoid@gmail.com
>> Cidade: Indaiatuba/SP
>> Telefone Celular: (Sem Telefone)
>> Telefone Residencial: (19) 99946-3675
>> Credenciada: (Sem Credenciada)
>>
>>
>> *3 - Empresa não cadastrada na Plataforma*
>>
>> *Prezados, Venho por meio desta denunciar a seguradora Sura Seguros pelo
>> tratamento inadequado e pela má-fé no tratamento do sinistro nº
>> 02.310.24.1784, referente ao acidente ocorrido em 13/12/2023. Apesar de ter
>> enviado todos os documentos solicitados, a seguradora insiste em alegar a
>> ausência de documentos e a indisponibilidade do veículo para inspeção.
>> Gostaria de esclarecer os seguintes pontos: 1. **Danos Corporais**: -
>> Devido às dificuldades financeiras e de transporte decorrentes do acidente,
>> não pude fornecer laudos periciais e médicos completos. No entanto, as
>> internações e o atendimento médico foram consequência direta do acidente.
>> Anexei cópias do RG e CPF das vítimas, que já foram enviados anteriormente.
>> 2. **Lucros Cessantes**: - A oficina onde o veículo está localizado
>> confirmou que o carro está disponível para inspeção. Temos gravações e
>> comunicações documentadas mostrando que inspetores foram agendados para
>> verificar o veículo. Além disso, a inspeção foi realizada por mecânicos
>> independentes, fornecendo orçamentos de reparo de R$ 30.000 e R$ 32.000. 3.
>> **Danos Materiais**: - O carro foi rebocado para o pátio do DETRAN porque
>> eu e minha esposa fomos levados de ambulância ao hospital. O pátio
>> confirmou que a inspeção pode ser realizada no local. A alegação da
>> seguradora de que a inspeção não poderia ser realizada é infundada e
>> demonstra falta de boa-fé. 4. **Má-Fé e Falta de Resolução**: - A
>> seguradora não reavaliou a proposta de compensação, que não cobre os custos
>> e perdas documentadas resultantes do acidente. A oferta de R$ 55.000 é
>> insuficiente e não corresponde às nossas perdas. Solicito a intervenção da
>> SUSEP para que a seguradora Sura Seguros seja responsabilizada por suas
>> ações e para que o sinistro seja resolvido de maneira justa e conforme as
>> leis aplicáveis, incluindo os artigos 6º e 14 do Código de Defesa do
>> Consumidor. *
>>
>>
>>
>> * Esta é uma mensagem automática, por favor, não responda. *
>>
>> Atenciosamente,
>> Consumidor.gov.br <http://www.consumidor.gov.br/>
>> Copyright © 2014
>>
>


=== HTML PART ===
<div dir="ltr">Can you provide the link where I can refile the complaint directly?<br>I need to file this complaint as the company is breaking the law.<br>Jesse</div><br><div class="gmail_quote"><div dir="ltr" class="gmail_attr">On Thu, Jun 13, 2024 at 9:43 AM <a href="mailto:faleconosco@consumidor.gov.br">faleconosco@consumidor.gov.br</a> &lt;<a href="mailto:faleconosco@consumidor.gov.br">faleconosco@consumidor.gov.br</a>&gt; wrote:<br></div><blockquote class="gmail_quote" style="margin:0px 0px 0px 0.8ex;border-left:1px solid rgb(204,204,204);padding-left:1ex"><div dir="ltr"><div class="gmail_default" style="font-family:verdana,sans-serif;font-size:small"><p style="text-align:justify;line-height:150%;margin:0cm;font-size:12pt;font-family:&quot;Times New Roman&quot;,serif"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">Prezado(a) Consumidor(a), </span></p>

<p style="text-align:justify;line-height:150%;margin:0cm;font-size:12pt;font-family:&quot;Times New Roman&quot;,serif"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">Pedimos que realize sua reclamação na
Plataforma do </span><a href="http://consumidor.gov.br/" style="color:rgb(5,99,193)" target="_blank"><span style="color:blue"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif;color:rgb(17,85,204)">consumidor.gov.br</span></span></a><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">, haja vista que o Fale Conosco/ Suporte não se configura
como canal para resolução de demandas individuais, porque este é o serviço
prestado pelo sítio.</span></p>

<p style="text-align:justify;line-height:150%;margin:0cm;font-size:12pt;font-family:&quot;Times New Roman&quot;,serif"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">O </span><a href="http://consumidor.gov.br/" style="color:rgb(5,99,193)" target="_blank"><span style="color:blue"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif;color:rgb(17,85,204)">consumidor.gov.br</span></span></a><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif"> propõe a
prestação de um serviço que visa a resolução alternativa de conflitos de
consumo pela internet, a partir da ação integrada entre a Secretaria Nacional
do Consumidor (SENACON) do Ministério da Justiça, Procons, Ministérios
Públicos, Defensorias Públicas, Tribunais de Justiça e empresas participantes.</span></p>

<p style="text-align:justify;line-height:150%;margin:0cm;font-size:12pt;font-family:&quot;Times New Roman&quot;,serif"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">Considerando que o foco da plataforma é
promover a comunicação direta entre consumidores e fornecedores de produtos e
serviços de consumo, a participação das empresas é voluntária e só permitida
àquelas que aderem formalmente ao serviço, mediante assinatura de Termo de
Adesão e Compromisso, no qual se comprometem a conhecer, analisar e investir
todos os esforços disponíveis para a solução dos problemas apresentados. Deste
modo, se a empresa não fizer parte da plataforma, o consumidor não terá a
oportunidade de tentar solucionar seu problema.</span></p>

<p style="text-align:justify;line-height:150%;margin:0cm;font-size:12pt;font-family:&quot;Times New Roman&quot;,serif"><b><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif;background-image:initial;background-position:initial;background-size:initial;background-repeat:initial;background-origin:initial;background-clip:initial">Antes de registrar uma
reclamação</span></b><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif;background-image:initial;background-position:initial;background-size:initial;background-repeat:initial;background-origin:initial;background-clip:initial">, leia os </span><a href="https://consumidor.gov.br/pages/conteudo/publico/7" style="color:rgb(5,99,193)" target="_blank"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif;background-image:initial;background-position:initial;background-size:initial;background-repeat:initial;background-origin:initial;background-clip:initial">Termos de Uso</span></a><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif;background-image:initial;background-position:initial;background-size:initial;background-repeat:initial;background-origin:initial;background-clip:initial">, as </span><a href="https://consumidor.gov.br/pages/conteudo/publico/3" style="color:rgb(5,99,193)" target="_blank"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif;background-image:initial;background-position:initial;background-size:initial;background-repeat:initial;background-origin:initial;background-clip:initial">Perguntas Frequentes</span></a><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif;background-image:initial;background-position:initial;background-size:initial;background-repeat:initial;background-origin:initial;background-clip:initial"> e as </span><a href="https://consumidor.gov.br/pages/conteudo/publico/8" style="color:rgb(5,99,193)" target="_blank"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif;background-image:initial;background-position:initial;background-size:initial;background-repeat:initial;background-origin:initial;background-clip:initial">Orientações de Uso</span></a><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif;background-image:initial;background-position:initial;background-size:initial;background-repeat:initial;background-origin:initial;background-clip:initial"> da plataforma.</span><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif"></span></p>

<p class="MsoNormal" style="text-align:justify;line-height:150%;background-image:initial;background-position:initial;background-size:initial;background-repeat:initial;background-origin:initial;background-clip:initial;margin:0cm;font-size:12pt;font-family:&quot;Liberation Serif&quot;,serif"><b><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">Para
registrar uma reclamação</span></b><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">,
o consumidor deverá primeiramente consultar se a empresa está ou não
cadastrada, indo no campo “pesquise a empresa”, representado por uma </span><span style="color:black"><a href="https://consumidor.gov.br/pages/principal/?1603162011812" style="color:rgb(5,99,193)" target="_blank"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">barra de pesquisa na página principal</span></a></span><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">, ou na aba “</span><span style="color:black"><a href="https://consumidor.gov.br/pages/principal/empresas-participantes" style="color:rgb(5,99,193)" target="_blank"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">Empresas participantes</span></a></span><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">”.</span><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif"></span></p>

<p style="text-align:justify;line-height:150%;margin:0cm;font-size:11pt;font-family:Calibri,sans-serif"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">Caso a empresa esteja cadastrada, o consumidor
pode clicar sobre o nome dela e, na próxima página, clicar no botão “Nova
Reclamação”. Após esse passo, será necessário realizar login na plataforma,
mediante uso </span><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">da sua Conta <a href="http://gov.br" target="_blank">gov.br</a>. Caso ainda não possua, crie sua
conta em: </span><a href="https://www.gov.br/governodigital/pt-br/conta-gov-br/conta-gov-br/" style="color:rgb(5,99,193)" target="_blank"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">Governo Digital</span></a><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif"></span></p>

<p style="text-align:justify;line-height:150%;margin:0cm;font-size:11pt;font-family:Calibri,sans-serif"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">ATENÇÃO! É necessário ter uma conta <a href="http://gov.br" target="_blank">gov.br</a> <b>nível
PRATA ou OURO</b> para registrar e acompanhar suas reclamações no
<a href="http://Consumidor.gov.br" target="_blank">Consumidor.gov.br</a>. Para verificar o nível de sua conta, basta acessar a
Conta Gov.br </span><a href="https://nam02.safelinks.protection.outlook.com/?url=https%3A%2F%2Fcontas.acesso.gov.br%2F&amp;data=04%7C01%7CGREICEMARTINEZ%40natura.net%7Caf6121bc69d04339554108d9c6181752%7Cb9203540bfb147a29e2bd73ec0debf49%7C0%7C0%7C637758629076023422%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000&amp;sdata=y%2BHwv%2BdUmJDG8xUnb8j4NDsO53LxJ6X8xa9lDTx%2F1UM%3D&amp;reserved=0" title="https://contas.acesso.gov.br" style="color:rgb(5,99,193)" target="_blank"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">https://contas.acesso.gov.br</span></a><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif"> ,
clicar em &quot;Privacidade&quot; &gt; &quot;<b>Selos de Confiabilidade</b>&quot;.</span></p>

<p style="text-align:justify;line-height:150%;margin:0cm;font-size:11pt;font-family:Calibri,sans-serif"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">Reclamações também podem ser registradas
diretamente no menu do usuário. </span></p>

<p style="text-align:justify;line-height:150%;margin:0cm;font-size:12pt;font-family:&quot;Times New Roman&quot;,serif"><a name="m_-5280850186187427277__Hlk141170408"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">Conforme os Termos de Uso do site (item 4), as reclamações só
podem ser registradas pelo titular do serviço (por exemplo, o contratante do
serviço ou a pessoa cujo nome aparece na nota fiscal do produto adquirido). </span></a></p>

<p style="text-align:justify;line-height:150%;margin:0cm;font-size:12pt;font-family:&quot;Times New Roman&quot;,serif"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">É possível indicar um representante
legal da pessoa física para atuar como intermediador. Neste caso, o consumidor
deve realizar o registro da reclamação na plataforma e, após, anexar uma
procuração indicando a pessoa que está autorizada a intermediar a negociação. </span></p>

<p class="MsoNormal" style="text-align:justify;line-height:150%;background-image:initial;background-position:initial;background-size:initial;background-repeat:initial;background-origin:initial;background-clip:initial;margin:0cm;font-size:12pt;font-family:&quot;Liberation Serif&quot;,serif"><b><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">Para acompanhar sua reclamação</span></b><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">,
acesse o sistema com a conta</span><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif;color:black"> <a href="http://gov.br" target="_blank">gov.br</a>. </span><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif"> Ao
acessar sua área, clique no botão <b>&quot;Menu&quot;</b>, que está
localizado no canto superior esquerdo da tela. Depois, clique na opção <b>&quot;Reclamações&quot;. </b>Na
coluna &quot;Protocolo&quot;, clique no número desejado, para visualizar detalhes
da sua reclamação.</span><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif"></span></p>

<p class="MsoNormal" style="text-align:justify;line-height:150%;background-image:initial;background-position:initial;background-size:initial;background-repeat:initial;background-origin:initial;background-clip:initial;margin:0cm;font-size:12pt;font-family:&quot;Liberation Serif&quot;,serif"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">A partir do registro de sua
reclamação, a empresa tem <b>até 10 dias </b>para analisá-la e
respondê-la. </span><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif;color:black">Com a resposta do fornecedor, o
consumidor tem <b>até 20 dias</b> para conversar e negociar com a empresa,
por meio do botão “Interagir com o Fornecedor” e anexar até 5
arquivos (com 1 MB por documento). </span><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">As interações e a resposta postadas
pela empresa são visualizadas ao clicar no botão azul “</span><b><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif;color:white;background:rgb(46,116,181)">Detalhes</span></b><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">” e no
botão “Anexos”, que estão localizados na coluna “Ações” dessa
mesma página. </span><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif;color:black">Se desejar uma impressão da reclamação,
clique no ícone <b>&quot;imprimir&quot;</b>, localizado no canto superior
direito da página.</span></p>

<p style="text-align:justify;line-height:150%;margin:0cm;font-size:12pt;font-family:&quot;Times New Roman&quot;,serif"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">O site do Consumidor.gov está
limitado para anexar apenas <b>5 arquivos</b>
(1 mb por anexo), sendo que o nome do anexo tem que possuir menos de 80
caracteres. São aceitas apenas as seguintes extensões de arquivos: pdf, doc e
docx, xls e xlsx, jpg e gif, odt e ods, txt. É importante que seu conteúdo
esteja legível.</span>  <span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">Caso
precise enviar mais do que o disponibilizado pelo site, solicite, por meio do
botão “Interagir com o Fornecedor”, algum e-mail do Fornecedor para enviar o
restante dos arquivos. </span></p>

<p class="MsoNormal" style="text-align:justify;line-height:150%;background-image:initial;background-position:initial;background-size:initial;background-repeat:initial;background-origin:initial;background-clip:initial;margin:0cm;font-size:12pt;font-family:&quot;Liberation Serif&quot;,serif"><a name="m_-5280850186187427277__Hlk126572894"><b><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif;color:black">Para
avaliar a resposta</span></b></a><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif;color:black">,
clique em “Avaliar Resposta do Fornecedor”. Esta opção deve ser utilizada nos
casos em que o consumidor considerar a demanda resolvida antes dos 20 dias de
prazo, ou ao final do prazo de 20 dias para demandas resolvidas ou não
resolvidas. </span><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif;color:black">Nesta ocasião, o consumidor poderá
fazer uma última manifestação sobre o atendimento/resposta prestado
pela empresa.  <b>O consumidor tem apenas uma oportunidade para
avaliar e, com sua avaliação, a reclamação é finalizada, não sendo mais
possível interagir com a empresa, reabrir a reclamação ou alterar a avaliação
registrada.</b></span><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif"></span></p>

<p class="MsoNormal" style="margin:5pt 0cm 0cm;text-align:justify;line-height:150%;background-image:initial;background-position:initial;background-size:initial;background-repeat:initial;background-origin:initial;background-clip:initial;font-size:12pt;font-family:&quot;Liberation Serif&quot;,serif"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif;color:black">Com a avaliação ou expirado o prazo de
20 dias, sua reclamação é finalizada e receberá o status de
“Finalizada Avaliada”, caso tenha sido encerrada com sua avaliação, ou
“Finalizada Não Avaliada”, caso tenha sido encerrada em função do fim do prazo
mencionado.</span></p>



<p style="text-align:justify;line-height:150%;margin:0cm;font-size:12pt;font-family:&quot;Times New Roman&quot;,serif"><a name="m_-5280850186187427277__Hlk80291773"><b><u><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">Sobre o Consumidor.gov.br</span></u></b></a></p>



<p class="MsoNormal" style="text-align:justify;line-height:150%;margin:0cm;font-size:12pt;font-family:&quot;Liberation Serif&quot;,serif"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">O </span><a href="https://consumidor.gov.br/pages/principal/?1603378652139" style="color:rgb(5,99,193)" target="_blank"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">consumidor.gov.br</span></a><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif"> é
um serviço público para solução de conflitos de consumo por meio da internet,
que permite a interlocução direta entre os consumidores e as empresas
cadastradas.  As informações do site
auxiliam o Poder Público na elaboração e implementação de políticas públicas de
defesa dos consumidores, e incentivam a competitividade no mercado pela
melhoria da qualidade e do atendimento ao consumidor. O Fale Conosco é o canal
dedicado a auxiliar o consumidor a utilizar a plataforma de maneira eficiente.</span></p>

<p class="MsoNormal" style="text-align:justify;line-height:150%;margin:0cm;font-size:12pt;font-family:&quot;Liberation Serif&quot;,serif"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">O serviço disponibilizado na plataforma é exclusivo para
interação entre empresas e consumidores, sem a intervenção de um órgão de
defesa do consumidor, como os Procons, Defensoria Pública ou Juizados
Especiais. Para orientações a respeito da existência de direitos, denúncias,
reclamações em face de empresas não participantes ou no caso de não solução do
problema, recomendamos que o consumidor busque o apoio dos canais tradicionais
de atendimento providos pelos Procons Estaduais e Municipais, Defensorias Públicas,
Juizados Especiais Cíveis, entre outros órgãos do Sistema Nacional de Defesa do
Consumidor.</span></p>

<p class="MsoNormal" style="text-align:justify;line-height:150%;margin:0cm;font-size:12pt;font-family:&quot;Liberation Serif&quot;,serif"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">Para saber mais sobre o </span><a href="https://consumidor.gov.br/pages/principal/?1603378652139" style="color:rgb(5,99,193)" target="_blank"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">consumidor.gov.br</span></a><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">,
acesse a seção </span><a href="https://consumidor.gov.br/pages/conteudo/sobre-servico" style="color:rgb(5,99,193)" target="_blank"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">Sobre
o Serviço</span></a><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">, os </span><a href="https://consumidor.gov.br/pages/conteudo/publico/7" style="color:rgb(5,99,193)" target="_blank"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">Termos
de Uso</span></a><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif"> e leia o Guia do Usuário, na aba </span><a href="https://consumidor.gov.br/pages/publicacao/externo/" style="color:rgb(5,99,193)" target="_blank"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">Publicações</span></a><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">.
Para tirar dúvidas sobre as formas de uso, cadastro, prazos de resposta e
outros assuntos, consulte as </span><a href="https://consumidor.gov.br/pages/conteudo/publico/3" style="color:rgb(5,99,193)" target="_blank"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">Perguntas
Frequentes</span></a><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif"> e as </span><a href="https://consumidor.gov.br/pages/conteudo/publico/8" style="color:rgb(5,99,193)" target="_blank"><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">Orientações
de Uso</span></a><span style="font-size:10pt;line-height:150%;font-family:Verdana,sans-serif">. </span></p></div><div><div dir="ltr" class="gmail_signature"><div dir="ltr"><p><span style="color:rgb(0,0,0);font-family:verdana,sans-serif;font-size:small">Atenciosamente,</span><br></p><p><span style="color:rgb(31,73,125)"><font face="arial, helvetica, sans-serif"> <a href="https://www.consumidor.gov.br/pages/principal/?1403644411677" target="_blank"><img src="https://lh6.googleusercontent.com/sjaJ7j4YSXTvI9EtzhvDA8rCmRQG9qp-YG2fHNA8Wd0=w725-h207-p-no" width="200" height="57"></a></font></span></p><p><font face="verdana, sans-serif" size="2"><b><span style="color:rgb(31,73,125)">Por favor não responda este e-mail.</span></b><br></font></p><p><font face="verdana, sans-serif" size="2"><b><span style="color:rgb(31,73,125)">Caso haja necessidade de novo contato, por favor acesse </span></b><b><span style="color:blue"><a href="https://www.consumidor.gov.br/pages/principal/?1403644411677" target="_blank">www.consumidor.gov.br</a></span></b><b><span style="color:rgb(31,73,125)"> e clique em Fale Conosco. </span></b></font></p></div></div></div><br></div><br><div class="gmail_quote"><div dir="ltr" class="gmail_attr">Em qua., 12 de jun. de 2024 às 18:57, &lt;<a href="mailto:admin@consumidor.gov.br" target="_blank">admin@consumidor.gov.br</a>&gt; escreveu:<br></div><blockquote class="gmail_quote" style="margin:0px 0px 0px 0.8ex;border-left:1px solid rgb(204,204,204);padding-left:1ex"><div>





<div style="margin:0px">
	<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#273593">
		<tbody>
			<tr> 
				<td bgcolor="#1D2666">
					<table width="100%" border="0" cellspacing="0" cellpadding="0">
						<tbody>
							<tr>								
								<td valign="top">
									<table width="600" border="0" cellspacing="0" cellpadding="0" align="center" height="35">
										<tbody>											
											<tr></tr>										
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
				</td>			
			</tr>
			<tr>
				<td>
					<table width="100%" border="0" cellspacing="0" cellpadding="0">
						<tbody>
							<tr>								
								<td valign="top">
									<table width="600" border="0" cellspacing="0" cellpadding="0" align="center">						
										<tbody>
											<tr>
												<td>
													<table width="100%" border="0" cellspacing="0" cellpadding="0">
														<tbody>
															<tr>
																<td height="25"></td>
															</tr>
															<tr>                       
																<td align="center">
																	<div style="color:rgb(255,255,255);font-family:open_sansextrabold,Arial,Helvetica,sans-serif;font-weight:normal;line-height:1em;margin:20px 0px">
																		<a title="Início do Portal" accesskey="0" href="#m_-5280850186187427277_m_-2780517350210443151_" style="color:white;text-transform:none;text-decoration:none">Consumidor<small style="font-size:0.5em">.gov.br</small></a>
																	</div>
																</td>                      
															</tr>
														</tbody>
													</table>
												</td>
											</tr>                            
										<tr>
											<td>
												<table width="100%" border="0" cellspacing="0" cellpadding="0">
													<tbody>
														<tr>
															<td bgcolor="#ffffff" valign="top">
																<table width="100%" border="0" cellspacing="0" cellpadding="0">
																	<tbody>
																		<tr>
																			<td width="18"></td>
																			<td>
																				<table width="100%" border="0" cellspacing="0" cellpadding="0">
																					<tbody>
																						<tr>
																							<td height="16"></td>
																						</tr>                                
																						<tr>
																							<td valign="top">
																								<table width="100%" border="0" cellspacing="0" cellpadding="0">
																									<tbody>
																										<tr>
																											<td height="18"></td>
																										</tr>
																										<tr>
																											<td style="font-family:Arial,Helvetica,sans-serif,&quot;Trebuchet MS&quot;;font-size:18px;line-height:24px;color:rgb(84,89,141);text-align:center;text-transform:uppercase">
																												<a href="#m_-5280850186187427277_m_-2780517350210443151_" style="color:rgb(84,89,141);text-decoration:none">Mensagem do Fale Conosco.</a>
																											</td>
																										</tr>
																										<tr>
																											<td height="10"></td>
																										</tr>
																										<tr>
																											<td style="font-family:Arial,Helvetica,sans-serif,&quot;Trebuchet MS&quot;;font-size:13px;line-height:22px;color:rgb(79,99,98);text-align:justify">
																												
Nome: Jesse Daniel Brown<br>

Email: <a href="mailto:plasmatoid@gmail.com" target="_blank">plasmatoid@gmail.com</a><br>
Cidade: Indaiatuba/SP<br>
Telefone Celular: (Sem Telefone)<br>
Telefone Residencial: (19) 99946-3675<br>
Credenciada: (Sem Credenciada)<br>

<br><br>

<b>3  - Empresa não cadastrada na Plataforma</b>
<br><br>

<i>Prezados,

Venho por meio desta denunciar a seguradora Sura Seguros pelo tratamento inadequado e pela má-fé no tratamento do sinistro nº 02.310.24.1784, referente ao acidente ocorrido em 13/12/2023.

Apesar de ter enviado todos os documentos solicitados, a seguradora insiste em alegar a ausência de documentos e a indisponibilidade do veículo para inspeção. Gostaria de esclarecer os seguintes pontos:

1. **Danos Corporais**:
   - Devido às dificuldades financeiras e de transporte decorrentes do acidente, não pude fornecer laudos periciais e médicos completos. No entanto, as internações e o atendimento médico foram consequência direta do acidente. Anexei cópias do RG e CPF das vítimas, que já foram enviados anteriormente.

2. **Lucros Cessantes**:
   - A oficina onde o veículo está localizado confirmou que o carro está disponível para inspeção. Temos gravações e comunicações documentadas mostrando que inspetores foram agendados para verificar o veículo. Além disso, a inspeção foi realizada por mecânicos independentes, fornecendo orçamentos de reparo de R$ 30.000 e R$ 32.000.

3. **Danos Materiais**:
   - O carro foi rebocado para o pátio do DETRAN porque eu e minha esposa fomos levados de ambulância ao hospital. O pátio confirmou que a inspeção pode ser realizada no local. A alegação da seguradora de que a inspeção não poderia ser realizada é infundada e demonstra falta de boa-fé.

4. **Má-Fé e Falta de Resolução**:
   - A seguradora não reavaliou a proposta de compensação, que não cobre os custos e perdas documentadas resultantes do acidente. A oferta de R$ 55.000 é insuficiente e não corresponde às nossas perdas.

Solicito a intervenção da SUSEP para que a seguradora Sura Seguros seja responsabilizada por suas ações e para que o sinistro seja resolvido de maneira justa e conforme as leis aplicáveis, incluindo os artigos 6º e 14 do Código de Defesa do Consumidor.
</i>
<br><br>

																												<br><br>
																												<div style="text-align:center;color:red">
																													<b>
																														Esta é uma mensagem automática, por favor, não responda.
																													</b>
																												</div>
																												<br>
																												Atenciosamente, <br>
																												<a href="http://www.consumidor.gov.br/" target="_blank">Consumidor.gov.br</a>
																											</td>
																										</tr>
																										<tr>
																											<td height="20"></td>
																										</tr>
																									</tbody>
																								</table>
																							</td>
																						</tr>
																					</tbody>
																				</table>
																			</td>
																			<td width="18"></td>
																		</tr>
																	</tbody>
																</table>
															</td>
														</tr>																				
													</tbody>
												</table>
											</td>
										</tr>
										<tr height="50"></tr>
									</tbody>
								</table>
							</td>
						</tr>
					</tbody>
				</table>
			</td>
		  </tr>
			<tr>
				<td bgcolor="#1D2666">
					<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
						<tbody>
							<tr>								
								<td valign="top">
									<table width="600" border="0" cellspacing="0" cellpadding="0" align="center">
										<tbody>
											<tr>
												<td height="10"></td>
											</tr>
											<tr>
												<td style="font-family:Arial,Helvetica,sans-serif,&quot;Trebuchet MS&quot;;font-size:13px;line-height:22px;color:rgb(255,255,255);text-align:center">Copyright © 2014</td>
											</tr>
											<tr>
												<td height="10"></td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
		  </tr>
		</tbody>
	</table>
</div></div></blockquote></div>
</blockquote></div>


```
