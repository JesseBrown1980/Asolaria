---
gmail_message_id: 18d6b856c6ecf064
account: plasmatoid@gmail.com
date_header: Fri, 2 Feb 2024 17:31:35 -0300
from: Carmen Anagennisi <carmen.anagennisi@gmail.com>
to: <itaro.yamato@simpar.com.br>
subject: ENC: *** SOLICITAÇÃO DOS DOCUMENTOS - RVO5H11 X QWT5A13  SEGUNDO
body_sha256: 84893fb5a1f3bbc7833a17c10037eca2966778da280f344b2f2c78afb9318615
snippet: SEGUNDO. De: Carmen Anagennisi &lt;carmen.anagennisi@gmail.com&gt; Enviada em: sexta-feira, 2 de fevereiro de 2024 17:07 Para: itaro.yamato@simpar.com.br Cc: &#39;Jesse Daniel Brown&#39; &lt;plasmatoid
---

# ENC: *** SOLICITAÇÃO DOS DOCUMENTOS - RVO5H11 X QWT5A13  SEGUNDO

**From:** Carmen Anagennisi <carmen.anagennisi@gmail.com>
**To:** <itaro.yamato@simpar.com.br>
**Date:** Fri, 2 Feb 2024 17:31:35 -0300
**SHA256:** `84893fb5a1f3bbc7833a17c10037eca2966778da280f344b2f2c78afb9318615`

## Body (extracted text)

SEGUNDO. De: Carmen Anagennisi > Enviada em: sexta-feira, 2 de fevereiro de 2024 17:07 Para: itaro.yamato@simpar.com.br Cc: 'Jesse Daniel Brown' >; carlos.magalhaes@aasp.org.br Assunto: RES: *** SOLICITAÇÃO DOS DOCUMENTOS - RVO5H11 X QWT5A13 Prioridade: Alta Itaro, em anexo novamente toda a documentação solicitada. Aguardamos retorno. De: Carmen Lucia Souza Campos > Enviada em: sexta-feira, 2 de fevereiro de 2024 16:16 Para: itaro.yamato@simpar.com.br Cc: Jesse Daniel Brown >; carlos.magalhaes@aasp.org.br Assunto: Fwd: *** SOLICITAÇÃO DOS DOCUMENTOS - RVO5H11 X QWT5A13 Boa tarde, Itaro. Estamos enviando novamente, toda a documentação do sinistro de veículo placa QWT5A13. Já falamos diversas vezes por telefone, vocês ficaram de responder até o dia 31 de janeiro, por e-mail. Ocorre que não responderam e também não atendem os telefones há exatos três dias. Já perdemos a conta do número de vezes que ligamos. Jesse é americano e fala muito pouco portugues. Gentileza responder por escrito e também atender os telefones: 011.2377.7987; 011.2377.8798. Temos aqui o registro de mais de 30 ligações não atendidas!!! Aguardamos retorno urgente! Att ---------- Forwarded message --------- De: Jesse Daniel Brown > Date: seg., 29 de jan. de 2024 às 16:23 Subject: Fwd: *** SOLICITAÇÃO DOS DOCUMENTOS - RVO5H11 X QWT5A13 To: > ---------- Forwarded message --------- From: Jesse Daniel Brown > Date: Sat, Jan 27, 2024 at 1:04 PM Subject: Re: *** SOLICITAÇÃO DOS DOCUMENTOS - RVO5H11 X QWT5A13 To: Itaro Kiyoshi Dos Santos Yamato > Cc: Carlos Henrique Bitencourt De Castro Magalhaes > Bom, eu responde com informáticao: Orcinameto 1: 32.980 BRL Orcinamento 2 : 30.000,00 brl Zeca funileria Bank account: Edivania Farias Brown Agencia 0001 Conta 36693719-6 Banco 0260 Nu Pegamentos S.A. Instituicao de Pegamento CPF: 36168377824 Edivania's id Jesse's id front Dtran data Jesse ID back Car data proof of residency Por favor falo comigo se vc preciso mais informatica. Sinceramente, Jesse Daniel Brown +55 19 999 463675 === HTML PART === SEGUNDO. De: Carmen Anagennisi < carmen.anagennisi@gmail.com > Enviada em: sexta-feira, 2 de fevereiro de 2024 17:07 Para: itaro.yamato@simpar.com.br Cc: 'Jesse Daniel Brown' < plasmatoid@gmail.com >; carlos.magalhaes@aasp.org.br Assunto: RES: *** SOLICITAÇÃO DOS DOCUMENTOS - RVO5H11 X QWT5A13 Prioridade: Alta Itaro, em anexo novamente toda a documentação solicitada. Aguardamos retorno. De: Carmen Lucia Souza Campos < carmen.anagennisi@gmail.com > Enviada em: sexta-feira, 2 de fevereiro de 2024 16:16 Para: itaro.yamato@simpar.com.br Cc: Jesse Daniel Brown < plasmatoid@gmail.com >; carlos.magalhaes@aasp.org.br Assunto: Fwd: *** SOLICITAÇÃO DOS DOCUMENTOS - RVO5H11 X QWT5A13 Boa tarde, Itaro. Estamos enviando novamente, toda a documentação do sinistro de veículo placa QWT5A13. Já falamos diversas vezes por telefone, vocês ficaram de responder até o dia 31 de janeiro, por e-mail. Ocorre que não responderam e também não atendem os telefones há exatos três dias. Já perdemos a conta do número de vezes que ligamos. Jesse é americano e fala muito pouco portugues. Gentileza responder por escrito e também atender os telefones: 011.2377.7987; 011.2377.8798. Temos aqui o registro de mais de 30 ligações não atendidas!!! Aguardamos retorno urgente! Att ---------- Forwarded message --------- De: Jesse Daniel Brown < plasmatoid@gmail.com > Date: seg., 29 de jan. de 2024 às 16:23 Subject: Fwd: *** SOLICITAÇÃO DOS DOCUMENTOS - RVO5H11 X QWT5A13 To: < carmen.anagennisi@gmail.com > ---------- Forwarded message --------- From: Jesse Daniel Brown < plasmatoid@gmail.com > Date: Sat, Jan 27, 2024 at 1:04 PM Subject: Re: *** SOLICITAÇÃO DOS DOCUMENTOS - RVO5H11 X QWT5A13 To: Itaro Kiyoshi Dos Santos Yamato < itaro.yamato@simpar.com.br > Cc: Carlos Henrique Bitencourt De Castro Magalhaes < carlos.magalhaes@aasp.org.br > Bom, eu responde com informáticao: Orcinameto 1: 32.980 BRL Orcinamento 2 : 30.000,00 brl Zeca funileria Bank account: Edivania Farias Brown Agencia 0001 Conta 36693719-6 Banco 0260 Nu Pegamentos S.A. Instituicao de Pegamento CPF: 36168377824 Edivania's id Jesse's id front Dtran data Jesse ID back Car data proof of residency Por favor falo comigo se vc preciso mais informatica. Sinceramente, Jesse Daniel Brown +55 19 999 463675

## Raw body (tamper-evident)

```
SEGUNDO.

 

De: Carmen Anagennisi <carmen.anagennisi@gmail.com <mailto:carmen.anagennisi@gmail.com> > 
Enviada em: sexta-feira, 2 de fevereiro de 2024 17:07
Para: itaro.yamato@simpar.com.br <mailto:itaro.yamato@simpar.com.br> 
Cc: 'Jesse Daniel Brown' <plasmatoid@gmail.com <mailto:plasmatoid@gmail.com> >; carlos.magalhaes@aasp.org.br <mailto:carlos.magalhaes@aasp.org.br> 
Assunto: RES: *** SOLICITAÇÃO DOS DOCUMENTOS - RVO5H11 X QWT5A13
Prioridade: Alta

 

Itaro, em anexo novamente toda a documentação solicitada. 

Aguardamos retorno.

 

De: Carmen Lucia Souza Campos <carmen.anagennisi@gmail.com <mailto:carmen.anagennisi@gmail.com> > 
Enviada em: sexta-feira, 2 de fevereiro de 2024 16:16
Para: itaro.yamato@simpar.com.br <mailto:itaro.yamato@simpar.com.br> 
Cc: Jesse Daniel Brown <plasmatoid@gmail.com <mailto:plasmatoid@gmail.com> >; carlos.magalhaes@aasp.org.br <mailto:carlos.magalhaes@aasp.org.br> 
Assunto: Fwd: *** SOLICITAÇÃO DOS DOCUMENTOS - RVO5H11 X QWT5A13

 

Boa tarde, Itaro.

Estamos enviando novamente, toda a documentação do sinistro de veículo placa QWT5A13.  Já falamos diversas vezes por telefone, vocês ficaram de responder até o dia 31 de janeiro, por e-mail. Ocorre que não responderam e também não atendem os telefones há exatos três dias. Já perdemos a conta do número de vezes que ligamos. Jesse é americano e fala muito pouco portugues. Gentileza responder por escrito e também atender os telefones: 011.2377.7987; 011.2377.8798.  Temos aqui o registro de mais de 30 ligações não atendidas!!!  Aguardamos retorno urgente!

Att

---------- Forwarded message ---------
De: Jesse Daniel Brown <plasmatoid@gmail.com <mailto:plasmatoid@gmail.com> >
Date: seg., 29 de jan. de 2024 às 16:23
Subject: Fwd: *** SOLICITAÇÃO DOS DOCUMENTOS - RVO5H11 X QWT5A13
To: <carmen.anagennisi@gmail.com <mailto:carmen.anagennisi@gmail.com> >

 

 

---------- Forwarded message ---------
From: Jesse Daniel Brown <plasmatoid@gmail.com <mailto:plasmatoid@gmail.com> >
Date: Sat, Jan 27, 2024 at 1:04 PM
Subject: Re: *** SOLICITAÇÃO DOS DOCUMENTOS - RVO5H11 X QWT5A13
To: Itaro Kiyoshi Dos Santos Yamato <itaro.yamato@simpar.com.br <mailto:itaro.yamato@simpar.com.br> >
Cc: Carlos Henrique Bitencourt De Castro Magalhaes <carlos.magalhaes@aasp.org.br <mailto:carlos.magalhaes@aasp.org.br> >

 

 

 

Bom, eu responde com informáticao:
Orcinameto 1:
32.980 BRL

 

 

 

Orcinamento 2 : 

30.000,00 brl 

Zeca funileria

 

Bank account:
Edivania Farias Brown
Agencia 0001 
Conta 36693719-6
Banco 0260
Nu Pegamentos S.A.
Instituicao de Pegamento
CPF: 36168377824

 

Edivania's id



Jesse's id front

Dtran data

 

Jesse ID back

Car data

 

proof of residency

 

Por favor falo comigo se vc preciso mais informatica.

Sinceramente,

Jesse Daniel Brown

+55 19 999 463675

 

 



=== HTML PART ===
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40"><head><meta name=Generator content="Microsoft Word 15 (filtered medium)"><style><!--
/* Font Definitions */
@font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
/* Style Definitions */
p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0cm;
	margin-bottom:.0001pt;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
a:link, span.MsoHyperlink
	{mso-style-priority:99;
	color:blue;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-priority:99;
	color:purple;
	text-decoration:underline;}
p.msonormal0, li.msonormal0, div.msonormal0
	{mso-style-name:msonormal;
	mso-margin-top-alt:auto;
	margin-right:0cm;
	mso-margin-bottom-alt:auto;
	margin-left:0cm;
	font-size:11.0pt;
	font-family:"Calibri",sans-serif;}
span.EstiloDeEmail18
	{mso-style-type:personal;
	font-family:"Calibri",sans-serif;
	color:windowtext;}
span.EstiloDeEmail19
	{mso-style-type:personal;
	font-family:"Calibri",sans-serif;
	color:windowtext;}
span.EstiloDeEmail22
	{mso-style-type:personal-reply;
	font-family:"Calibri",sans-serif;
	color:windowtext;}
.MsoChpDefault
	{mso-style-type:export-only;
	font-size:10.0pt;}
@page WordSection1
	{size:612.0pt 792.0pt;
	margin:70.85pt 3.0cm 70.85pt 3.0cm;}
div.WordSection1
	{page:WordSection1;}
--></style><!--[if gte mso 9]><xml>
<o:shapedefaults v:ext="edit" spidmax="1026" />
</xml><![endif]--><!--[if gte mso 9]><xml>
<o:shapelayout v:ext="edit">
<o:idmap v:ext="edit" data="1" />
</o:shapelayout></xml><![endif]--></head><body lang=PT-BR link=blue vlink=purple><div class=WordSection1><p class=MsoNormal><span style='mso-fareast-language:EN-US'>SEGUNDO.<o:p></o:p></span></p><p class=MsoNormal><span style='mso-fareast-language:EN-US'><o:p>&nbsp;</o:p></span></p><div><div style='border:none;border-top:solid #E1E1E1 1.0pt;padding:3.0pt 0cm 0cm 0cm'><p class=MsoNormal><b>De:</b> Carmen Anagennisi &lt;<a href="mailto:carmen.anagennisi@gmail.com">carmen.anagennisi@gmail.com</a>&gt; <br><b>Enviada em:</b> sexta-feira, 2 de fevereiro de 2024 17:07<br><b>Para:</b> <a href="mailto:itaro.yamato@simpar.com.br">itaro.yamato@simpar.com.br</a><br><b>Cc:</b> 'Jesse Daniel Brown' &lt;<a href="mailto:plasmatoid@gmail.com">plasmatoid@gmail.com</a>&gt;; <a href="mailto:carlos.magalhaes@aasp.org.br">carlos.magalhaes@aasp.org.br</a><br><b>Assunto:</b> RES: *** SOLICITAÇÃO DOS DOCUMENTOS - RVO5H11 X QWT5A13<br><b>Prioridade:</b> Alta<o:p></o:p></p></div></div><p class=MsoNormal><o:p>&nbsp;</o:p></p><p class=MsoNormal><span style='mso-fareast-language:EN-US'>Itaro, em anexo novamente toda a documentação solicitada. <o:p></o:p></span></p><p class=MsoNormal><span style='mso-fareast-language:EN-US'>Aguardamos retorno.<o:p></o:p></span></p><p class=MsoNormal><span style='mso-fareast-language:EN-US'><o:p>&nbsp;</o:p></span></p><p class=MsoNormal><b>De:</b> Carmen Lucia Souza Campos &lt;<a href="mailto:carmen.anagennisi@gmail.com">carmen.anagennisi@gmail.com</a>&gt; <br><b>Enviada em:</b> sexta-feira, 2 de fevereiro de 2024 16:16<br><b>Para:</b> <a href="mailto:itaro.yamato@simpar.com.br">itaro.yamato@simpar.com.br</a><br><b>Cc:</b> Jesse Daniel Brown &lt;<a href="mailto:plasmatoid@gmail.com">plasmatoid@gmail.com</a>&gt;; <a href="mailto:carlos.magalhaes@aasp.org.br">carlos.magalhaes@aasp.org.br</a><br><b>Assunto:</b> Fwd: *** SOLICITAÇÃO DOS DOCUMENTOS - RVO5H11 X QWT5A13<o:p></o:p></p><p class=MsoNormal><o:p>&nbsp;</o:p></p><div><p class=MsoNormal>Boa tarde, Itaro.<o:p></o:p></p><div><p class=MsoNormal>Estamos enviando novamente, toda a documentação do sinistro de veículo placa QWT5A13.&nbsp; Já falamos diversas vezes por telefone, vocês ficaram de responder até o dia 31 de janeiro, por e-mail. Ocorre que não responderam e também não atendem os telefones há exatos três dias. Já perdemos a conta do número de vezes que ligamos. Jesse é americano e fala muito pouco portugues. Gentileza responder por escrito e também atender os telefones: 011.2377.7987; 011.2377.8798.&nbsp; Temos aqui o registro de mais de 30 ligações não atendidas!!!&nbsp; Aguardamos retorno urgente!<o:p></o:p></p></div><div><p class=MsoNormal style='margin-bottom:12.0pt'>Att<o:p></o:p></p><div><div><p class=MsoNormal>---------- Forwarded message ---------<br>De: <strong><span style='font-family:"Calibri",sans-serif'>Jesse Daniel Brown</span></strong> &lt;<a href="mailto:plasmatoid@gmail.com">plasmatoid@gmail.com</a>&gt;<br>Date: seg., 29 de jan. de 2024 às 16:23<br>Subject: Fwd: *** SOLICITAÇÃO DOS DOCUMENTOS - RVO5H11 X QWT5A13<br>To: &lt;<a href="mailto:carmen.anagennisi@gmail.com">carmen.anagennisi@gmail.com</a>&gt;<o:p></o:p></p></div><p class=MsoNormal style='margin-bottom:12.0pt'><o:p>&nbsp;</o:p></p><div><p class=MsoNormal style='margin-bottom:12.0pt'><o:p>&nbsp;</o:p></p><div><div><p class=MsoNormal>---------- Forwarded message ---------<br>From: <strong><span style='font-family:"Calibri",sans-serif'>Jesse Daniel Brown</span></strong> &lt;<a href="mailto:plasmatoid@gmail.com" target="_blank">plasmatoid@gmail.com</a>&gt;<br>Date: Sat, Jan 27, 2024 at 1:04 PM<br>Subject: Re: *** SOLICITAÇÃO DOS DOCUMENTOS - RVO5H11 X QWT5A13<br>To: Itaro Kiyoshi Dos Santos Yamato &lt;<a href="mailto:itaro.yamato@simpar.com.br" target="_blank">itaro.yamato@simpar.com.br</a>&gt;<br>Cc: Carlos Henrique Bitencourt De Castro Magalhaes &lt;<a href="mailto:carlos.magalhaes@aasp.org.br" target="_blank">carlos.magalhaes@aasp.org.br</a>&gt;<o:p></o:p></p></div><p class=MsoNormal style='margin-bottom:12.0pt'><o:p>&nbsp;</o:p></p><div><div><div><p class=MsoNormal><o:p>&nbsp;</o:p></p></div><div><p class=MsoNormal><o:p>&nbsp;</o:p></p></div><div><p class=MsoNormal>Bom, eu responde com informáticao:<br>Orcinameto 1:<br>32.980 BRL<o:p></o:p></p></div><div><p class=MsoNormal><o:p>&nbsp;</o:p></p></div><div><p class=MsoNormal style='margin-bottom:12.0pt'><o:p>&nbsp;</o:p></p></div><div><p class=MsoNormal><o:p>&nbsp;</o:p></p></div><div><p class=MsoNormal>Orcinamento 2 :&nbsp;<o:p></o:p></p></div><div><p class=MsoNormal>30.000,00 brl&nbsp;<o:p></o:p></p></div><div><p class=MsoNormal>Zeca funileria<o:p></o:p></p></div><div><p class=MsoNormal><o:p>&nbsp;</o:p></p></div><div><p class=MsoNormal style='margin-bottom:12.0pt'>Bank account:<br>Edivania Farias Brown<br>Agencia 0001 <br>Conta 36693719-6<br>Banco 0260<br>Nu Pegamentos S.A.<br>Instituicao de Pegamento<br>CPF: 36168377824<o:p></o:p></p></div><div><p class=MsoNormal><o:p>&nbsp;</o:p></p></div><div><p class=MsoNormal>Edivania's&nbsp;id<o:p></o:p></p></div><p class=MsoNormal style='margin-bottom:12.0pt'><br><br>Jesse's id front<o:p></o:p></p><div><p class=MsoNormal>Dtran&nbsp;data<o:p></o:p></p><div><p class=MsoNormal><o:p>&nbsp;</o:p></p></div><div><p class=MsoNormal style='margin-bottom:12.0pt'>Jesse ID back<o:p></o:p></p></div><div><p class=MsoNormal>Car data<o:p></o:p></p></div><div><p class=MsoNormal><o:p>&nbsp;</o:p></p></div><div><p class=MsoNormal>proof of residency<o:p></o:p></p></div><div><p class=MsoNormal><o:p>&nbsp;</o:p></p></div><div><p class=MsoNormal>Por favor falo comigo se vc preciso mais informatica.<o:p></o:p></p></div><div><p class=MsoNormal>Sinceramente,<o:p></o:p></p></div><div><p class=MsoNormal>Jesse Daniel Brown<o:p></o:p></p></div><div><p class=MsoNormal>+55 19 999 463675<o:p></o:p></p></div><div><p class=MsoNormal><o:p>&nbsp;</o:p></p><div style='border:solid #DDDDDD 1.0pt;padding:4.0pt 4.0pt 4.0pt 4.0pt;max-height:18px'><p class=MsoNormal style='background:whitesmoke'><b><span style='font-size:10.0pt;font-family:"Arial",sans-serif;color:#222222'><o:p>&nbsp;</o:p></span></b></p></div></div></div></div></div></div></div></div></div></div></div></body></html>

```
