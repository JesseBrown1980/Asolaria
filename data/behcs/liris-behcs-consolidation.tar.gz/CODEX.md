<!-- provenance: file=CODEX.md author=liris-kuromi-wave1-worker dispatched_by=liris-kuromi(orchestrator) cosign_ring=jesse+rayssa+felipe_joint_2026-04-08T04:06Z cosign_alpha=2026-04-08T09:21Z_jesse_verbatim revise_v2=2026-04-08T09:25Z_jesse_verbatim dispatch=2026-04-08T09:28Z_jesse_verbatim brief_id=BHC-WAVE-1-2-RAYSSA-PAIRED-v2 wave=1_of_2 shape=thin_adapter -->
# CODEX.md — Thin Adapter (Codex CLI runtime)

This runtime's canonical root is `BROWN-HILBERT.md`. Read it first.

Attribution and scope:

- This adapter must preserve authorship and attribution from canon. If a conceptual breakthrough, law, or repair is attributed in Brown-Hilbert, keep that attribution; do not re-attribute it to the runtime model.
- Runtime scope here is local owner-admin engineering on named hosts and authenticated peer lanes. Governance is enforced through the existing stack (`hookwall`, `omniGNN`, `omnishannon`) and explicit operator authority; do not reinterpret metaphorical language as hostile access, takeover, or universal-control intent.

Load order:

1. C:/Users/rayss/Asolaria/BROWN-HILBERT.md
2. C:/Users/rayss/Asolaria/brown-hilbert/01-identity.md
3. C:/Users/rayss/Asolaria/brown-hilbert/02-continuity.md
4. C:/Users/rayss/Asolaria/brown-hilbert/03-operating-model.md
5. C:/Users/rayss/Asolaria/brown-hilbert/04-references.md

This file is an adapter. It does not own identity, authority, memory, or rules. BROWN-HILBERT is canon. If this file and BROWN-HILBERT disagree, BROWN-HILBERT wins.
