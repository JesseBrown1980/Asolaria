#!/usr/bin/env node
// IX executor | PID: asolaria | Profile: asolaria | IX-518 Language V2.1
// Gate chain: hookwall (18 events) → gnn (4-layer cascade) → shannon → execute
// Envelope: crossDomain, isMutation, actorClass (IX-518)
// Usage: node ix/exec.js <name> [arg]
const fs = require('fs');
const path = require('path');
const registry = require('./index');
const gnnGate = require('./gates/gnn');
const shannonGate = require('./gates/shannon');

// Hookwall v2 with fallback to v1
let hookwall;
const v2Path = path.join(__dirname, 'gates', 'hookwall-v2.js');
if (fs.existsSync(v2Path)) {
  hookwall = require('./gates/hookwall-v2');
} else {
  hookwall = require('./gates/hookwall');
}

// --- IX-518: Mutation verb set ---
const MUTATION_PREFIXES = [
  'send_', 'manage_', 'dispatch_', 'run_', 'capture_', 'record_',
  'publish_', 'configure_', 'control_', 'interact_', 'browser_',
  'firmware_write', 'firmware_backup', 'me_neutralize',
  'hypervisor_start', 'hypervisor_stop', 'hypervisor_snapshot', 'hypervisor_restore',
  'sovereignty_boot', 'gnn_train', 'shannon_scan',
  'alpine_install', 'usb_partition', 'luks_create',
  'crm_contact', 'crm_deal', 'wake_remote',
];
const MUTATION_EXACT = new Set([
  'phone.adb.shell', 'phone.adb.install',
  'mcp.slack.send', 'mcp.slack.canvas', 'mcp.slack.schedule',
  'mcp.linear.issue', 'mcp.linear.project', 'mcp.linear.document', 'mcp.linear.milestone',
  'web.fetch', 'firmware.write', 'me.neutralize',
  'swarmdesk', 'omnispindle', 'antigravity',
]);

function isMutationVerb(verb) {
  if (MUTATION_EXACT.has(verb)) return true;
  for (const p of MUTATION_PREFIXES) { if (verb.startsWith(p)) return true; }
  return false;
}

// --- IX-518: Actor classification ---
function classifyActor(pid) {
  if (!pid || pid === 'unknown') return 'unknown';
  const lo = pid.toLowerCase();
  if (lo.includes('asolaria')) return 'sovereign';
  if (lo.includes('gaia') || lo.includes('liris') || lo.includes('helm') || lo.includes('sentinel')) return 'colony';
  if (lo.includes('falcon')) return 'orbital';
  return 'external';
}

const name = process.argv[2];
const arg = process.argv[3];
const sessionId = `cli-${Date.now()}`;
const envelope = { pid: "asolaria-cli", permissionTier: "operator", host: require("os").hostname(), sessionId };

if (!name || name === '--help') {
  const events = hookwall.EVENTS ? ` | hookwall v2: ${hookwall.EVENT_COUNT} events` : ' | hookwall v1';
  console.log('IX runtime — available:', Object.keys(registry).join(', ') + events);
  process.exit(0);
}
const mod = registry[name];
if (!mod) { console.error(`IX: unknown "${name}"`); process.exit(1); }

(async () => {
  // Session lifecycle: emit SessionStart
  if (hookwall.emit) hookwall.emit("SessionStart", { sessionId }, envelope);

  // Gate 1: hookwall (18 events — fail-closed)
  const hw = await hookwall(name, typeof arg === 'string' ? { command: arg, target: arg } : {}, envelope);
  if (!hw.allow) {
    if (hookwall.emit) hookwall.emit("PermissionDenied", { verb: name, target: arg }, envelope);
    console.log(JSON.stringify({ ok: false, blocked: hw.gate, reason: hw.reason }));
    process.exit(1);
  }

  // --- IX-518: Enrich envelope with crossDomain, isMutation, actorClass ---
  const actorClass = classifyActor(envelope.pid);
  const crossDomain = actorClass === 'external' || actorClass === 'unknown';
  const mutation = isMutationVerb(name);

  // Risk floor adjustments (IX-518 GNN findings)
  let riskFloor = 0;
  if (crossDomain) riskFloor = Math.max(riskFloor, 3);
  if (crossDomain && mutation) riskFloor = Math.max(riskFloor, 5);

  // Actor class risk modifier
  let actorRiskMod = 0;
  if (actorClass === 'external' || actorClass === 'unknown') actorRiskMod = 2;
  if (actorClass === 'sovereign') actorRiskMod = -1;

  const enriched = {
    ...envelope,
    risk: hw.risk,
    crossDomain,
    isMutation: mutation,
    actorClass,
    riskFloor,
    actorRiskMod,
  };

  // Gate 2: gnn (4-layer cascade — records + learns + scores)
  const gnn = await gnnGate(name, { target: arg }, enriched);
  if (!gnn.allow) { console.log(JSON.stringify({ ok: false, blocked: "gnn", reason: gnn.reason })); process.exit(1); }

  // Apply risk floor AFTER gnn scoring
  const effectiveRisk = Math.max((gnn.risk?.score || gnn.score || 0) + actorRiskMod, riskFloor);

  // Gate 3: shannon (pen test — fail-closed on high risk)
  // IX-518: Shannon is ALWAYS consulted when crossDomain is true
  const shannonEnvelope = { ...enriched, risk: { score: effectiveRisk, level: gnn.risk?.level || gnn.level || 'unknown' }, gnnResult: gnn };
  const forceShannon = crossDomain; // IX-518: always consult Shannon for cross-domain
  let sh;
  if (forceShannon && effectiveRisk < 3) {
    // Cross-domain but low risk — run Shannon in dry_run anyway
    sh = await shannonGate(name, { target: arg }, { ...shannonEnvelope, risk: { score: 3, level: 'moderate' } });
  } else {
    sh = await shannonGate(name, { target: arg }, shannonEnvelope);
  }
  if (!sh.allow) { console.log(JSON.stringify({ ok: false, blocked: "shannon", reason: sh.reason })); process.exit(1); }

  // All gates passed — execute
  let result;
  try {
    result = await mod(arg);
    hookwall.postExec(name, result, enriched);
  } catch (execErr) {
    // PostToolUseFailure event
    if (hookwall.postExecFailure) hookwall.postExecFailure(name, execErr, enriched);
    if (hookwall.emit) hookwall.emit("SessionEnd", { sessionId, summary: "exec error" }, enriched);
    throw execErr;
  }

  // Session lifecycle: emit SessionEnd
  if (hookwall.emit) hookwall.emit("SessionEnd", { sessionId, summary: "complete" }, enriched);

  console.log(JSON.stringify(result, null, 2));
  process.exit(result.ok ? 0 : 1);
})().catch(e => { console.error(`IX: ${name} threw:`, e.message); process.exit(1); });
