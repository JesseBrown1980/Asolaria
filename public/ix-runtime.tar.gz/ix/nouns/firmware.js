// IX noun: firmware | PID: asolaria | Profile: asolaria
// Reads firmware state from local hardware observation
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

async function firmware() {
  const result = { ok: true, ts: Date.now(), boot_guard: null, me: null, spi: null, secure_boot: null };

  // Check if we're on Linux with MSR access (bare-metal only)
  try {
    if (process.platform === 'linux' && fs.existsSync('/dev/cpu/0/msr')) {
      // Boot Guard MSR 0x13A
      const bg = execSync('rdmsr 0x13A 2>/dev/null', { encoding: 'utf8', timeout: 5000 }).trim();
      result.boot_guard = { raw: bg, enabled: bg !== '0', checked: true };
    } else {
      result.boot_guard = { checked: false, reason: process.platform === 'win32' ? 'windows-no-msr' : 'no-msr-access' };
    }
  } catch (e) { result.boot_guard = { checked: false, reason: e.message }; }

  // Check Intel ME status
  try {
    if (fs.existsSync('/dev/mei0')) {
      result.me = { device: true, accessible: true };
    } else if (process.platform === 'win32') {
      result.me = { device: false, reason: 'check-from-linux' };
    } else {
      result.me = { device: false, reason: 'mei0-not-found' };
    }
  } catch (e) { result.me = { device: false, reason: e.message }; }

  // Check sovereignty USB
  const sovRoot = process.env.ASOLARIA_SOVEREIGNTY_ROOT || '';
  if (sovRoot && fs.existsSync(sovRoot)) {
    try {
      const files = fs.readdirSync(sovRoot);
      result.spi = { usb_connected: true, root: sovRoot, files: files.length };
    } catch (e) { result.spi = { usb_connected: false, reason: e.message }; }
  } else {
    result.spi = { usb_connected: false, reason: 'no-sovereignty-root' };
  }

  // Check Secure Boot (Linux only)
  try {
    if (fs.existsSync('/sys/firmware/efi/efivars')) {
      result.secure_boot = { efi: true };
    } else {
      result.secure_boot = { efi: false, reason: process.platform === 'win32' ? 'check-from-linux' : 'no-efivars' };
    }
  } catch (e) { result.secure_boot = { efi: false, reason: e.message }; }

  return result;
}

module.exports = firmware;
if (require.main === module) firmware().then(r => console.log(JSON.stringify(r, null, 2)));
