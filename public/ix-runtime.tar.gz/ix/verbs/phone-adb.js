// IX verb: phone-adb | PID: asolaria | Profile: asolaria | IX-506
// Phone ADB surface — 3 verbs: phone.screen, phone.input, phone.shell
// Routes to ADB commands targeting Falcon (R5CXA4MGQXV)

const { exec } = require('child_process');
const DEVICE_SERIAL = process.env.FALCON_SERIAL || 'R5CXA4MGQXV';

const SUBCOMMANDS = {
  screen: { cmd: 'exec-out screencap -p',              risk: 2 },
  input:  { cmd: 'shell input',                         risk: 6 },
  shell:  { cmd: 'shell',                               risk: 5 },
};

/**
 * Runs ADB command against Falcon device
 * @param {string} adbArgs — the ADB subcommand + args
 * @returns {Promise<string>}
 */
function runAdb(adbArgs) {
  return new Promise((resolve, reject) => {
    const cmd = `adb -s ${DEVICE_SERIAL} ${adbArgs}`;
    exec(cmd, { maxBuffer: 10 * 1024 * 1024, timeout: 30000 }, (err, stdout, stderr) => {
      if (err) return reject(new Error(`adb failed: ${err.message} | stderr: ${stderr}`));
      resolve(stdout);
    });
  });
}

/**
 * @param {string} command — format: "subcommand args..." e.g. "shell getprop ro.build.version.release"
 * @returns {Promise<{ok: boolean, result: any, ts: number}>}
 */
async function phoneAdb(command) {
  const ts = Date.now();
  if (!command) {
    return { ok: false, result: { error: 'usage: phone.screen|phone.input|phone.shell <args>', subcommands: Object.keys(SUBCOMMANDS) }, ts };
  }

  const parts = command.trim().split(/\s+/);
  let sub = parts[0].replace(/^phone\./, '');
  const args = parts.slice(1).join(' ');

  const entry = SUBCOMMANDS[sub];
  if (!entry) {
    return { ok: false, result: { error: `unknown subcommand "${sub}"`, valid: Object.keys(SUBCOMMANDS) }, ts };
  }

  try {
    const adbCmd = sub === 'screen'
      ? entry.cmd
      : `${entry.cmd} ${args}`;

    const output = await runAdb(adbCmd);

    return {
      ok: true,
      result: {
        verb: `phone.${sub}`,
        device: DEVICE_SERIAL,
        output: sub === 'screen' ? `<binary screencap ${output.length} bytes>` : output.trim(),
        risk: entry.risk
      },
      ts
    };
  } catch (e) {
    return { ok: false, result: { error: e.message, verb: `phone.${sub}`, device: DEVICE_SERIAL }, ts };
  }
}

module.exports = phoneAdb;
module.exports.subcommands = SUBCOMMANDS;
if (require.main === module) phoneAdb(process.argv.slice(2).join(' ')).then(r => console.log(JSON.stringify(r, null, 2)));
