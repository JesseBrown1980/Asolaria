// IX verb: mcp-slack | PID: asolaria | Profile: asolaria | IX-506
// MCP Slack surface — 4 verbs: slack.search, slack.send, slack.read, slack.canvas
// Routes IX verb strings to MCP Slack tools via subprocess dispatch

const { execFile } = require('child_process');
const path = require('path');

const SUBCOMMANDS = {
  search:  { tool: 'mcp__claude_ai_Slack__slack_search_public_and_private', risk: 1 },
  send:    { tool: 'mcp__claude_ai_Slack__slack_send_message',              risk: 3 },
  read:    { tool: 'mcp__claude_ai_Slack__slack_read_channel',              risk: 1 },
  canvas:  { tool: 'mcp__claude_ai_Slack__slack_create_canvas',             risk: 3 },
};

/**
 * @param {string} command — format: "subcommand args..." e.g. "search asolaria inventory"
 * @returns {Promise<{ok: boolean, result: any, ts: number}>}
 */
async function mcpSlack(command) {
  const ts = Date.now();
  if (!command) {
    return { ok: false, result: { error: 'usage: slack.search|slack.send|slack.read|slack.canvas <args>', subcommands: Object.keys(SUBCOMMANDS) }, ts };
  }

  const parts = command.trim().split(/\s+/);
  // Accept both "search foo" and "slack.search foo" formats
  let sub = parts[0].replace(/^slack\./, '');
  const args = parts.slice(1).join(' ');

  const entry = SUBCOMMANDS[sub];
  if (!entry) {
    return { ok: false, result: { error: `unknown subcommand "${sub}"`, valid: Object.keys(SUBCOMMANDS) }, ts };
  }

  try {
    // Route to MCP tool — the actual MCP call is handled by the host runtime
    // In standalone mode, we return the routing info for the executor to dispatch
    return {
      ok: true,
      result: {
        verb: `slack.${sub}`,
        mcpTool: entry.tool,
        args,
        risk: entry.risk,
        routed: true
      },
      ts
    };
  } catch (e) {
    return { ok: false, result: { error: e.message, verb: `slack.${sub}` }, ts };
  }
}

module.exports = mcpSlack;
module.exports.subcommands = SUBCOMMANDS;
if (require.main === module) mcpSlack(process.argv.slice(2).join(' ')).then(r => console.log(JSON.stringify(r, null, 2)));
