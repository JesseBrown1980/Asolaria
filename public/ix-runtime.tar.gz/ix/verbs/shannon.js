// IX verb: shannon | PID: asolaria | Profile: asolaria
// Shannon security scanner — risk assessment + full audit
// Verbs: shannon.scan (risk assessment), shannon.audit (full audit)
// Wires into shannon gate (localhost:4791) OR runs standalone scan
// Reference: IX-506 §3, IX-491 (L6 Shannon), IX-513

const shannonGate = require('../gates/shannon');
const BASE = process.env.SHANNON_URL || 'http://localhost:4791';

// --- Shannon scan patterns learned from Keygraph session-manager ---
// Agent phases: pre-recon → recon → vuln-{type} → exploit-{type} → report
// Error classes: retryable (network/429/5xx) vs terminal (prompt/auth)
const VULN_TYPES = ['injection', 'xss', 'auth', 'ssrf', 'authz'];
const SCAN_PHASES = ['pre-recon', 'recon', 'vuln-scan', 'exploit-check', 'report'];

// --- Retryable pattern from eBacMap error-handling.ts ---
const RETRYABLE_PATTERNS = [
  'network', 'connection', 'timeout', 'econnreset', 'enotfound',
  'econnrefused', 'rate limit', '429', 'too many requests',
  'server error', '5xx', 'internal server error', 'service unavailable'
];

function isRetryable(errMsg) {
  const lower = (errMsg || '').toLowerCase();
  return RETRYABLE_PATTERNS.some(p => lower.includes(p));
}

/**
 * shannon.scan — risk assessment against a verb+args pair
 * Returns: {ok, risk, flags, blocked, reason, phase}
 */
async function scan(verb, args, envelope) {
  const ts = new Date().toISOString();
  const pid = envelope?.pid || 'unknown';

  // Phase 1: Run through the gate (hookwall already ran before us)
  const gateResult = await shannonGate(verb, args, envelope);

  // If gate skipped (low risk), return clean
  if (gateResult.skipped) {
    return {
      ok: true, risk: 0, flags: [], blocked: false,
      reason: 'below threshold', phase: 'skipped',
      pid, verb, ts
    };
  }

  // If gate blocked, return block
  if (!gateResult.allow) {
    return {
      ok: false, risk: gateResult.score || 9, flags: gateResult.flags || [],
      blocked: true, reason: gateResult.reason,
      phase: 'gate-blocked', pid, verb, ts
    };
  }

  // Phase 2: Standalone vuln type scan (if Shannon sidecar is reachable)
  const vulnFlags = [];
  try {
    const r = await fetch(`${BASE}/security/shannon/vuln-check`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        verb, args: typeof args === 'string' ? args : JSON.stringify(args)?.slice(0, 500),
        pid, types: VULN_TYPES
      }),
      signal: AbortSignal.timeout(5000)
    });
    if (r.ok) {
      const data = await r.json();
      vulnFlags.push(...(data.flags || []));
    }
  } catch {
    // Sidecar vuln-check endpoint may not exist yet — non-fatal
  }

  const allFlags = [...new Set([...(gateResult.flags || []), ...vulnFlags])];
  const risk = gateResult.score || 0;

  return {
    ok: true, risk, flags: allFlags, blocked: false,
    reason: allFlags.length ? `${allFlags.length} flag(s) noted` : 'clean',
    phase: 'scan-complete', mode: gateResult.mode,
    pid, verb, ts
  };
}

/**
 * shannon.audit — full multi-phase security audit
 * Runs all 5 phases: pre-recon → recon → vuln-scan → exploit-check → report
 * Returns: {ok, risk, flags, blocked, reason, phases, report}
 */
async function audit(verb, args, envelope) {
  const ts = new Date().toISOString();
  const pid = envelope?.pid || 'unknown';
  const phases = [];
  let maxRisk = 0;
  const allFlags = [];
  let blocked = false;
  let blockReason = null;

  for (const phase of SCAN_PHASES) {
    const phaseStart = Date.now();
    try {
      const r = await fetch(`${BASE}/security/shannon/audit`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          verb, args: typeof args === 'string' ? args : JSON.stringify(args)?.slice(0, 500),
          pid, phase
        }),
        signal: AbortSignal.timeout(10000)
      });

      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const data = await r.json();

      const phaseRisk = data.risk || data.score || 0;
      if (phaseRisk > maxRisk) maxRisk = phaseRisk;
      if (data.flags) allFlags.push(...data.flags);
      if (data.blocked) { blocked = true; blockReason = data.reason; }

      phases.push({
        name: phase, ok: true, risk: phaseRisk,
        flags: data.flags || [], ms: Date.now() - phaseStart
      });

      if (blocked) break; // Stop audit on block
    } catch (err) {
      const retryable = isRetryable(err.message);
      phases.push({
        name: phase, ok: false, error: err.message,
        retryable, ms: Date.now() - phaseStart
      });
      // Fail-closed on unreachable + high risk
      if (maxRisk >= 5 || (envelope?.risk?.score ?? 0) >= 5) {
        blocked = true;
        blockReason = `Shannon unreachable during ${phase}, fail-closed at risk ${maxRisk}`;
        break;
      }
    }
  }

  const uniqueFlags = [...new Set(allFlags)];

  return {
    ok: !blocked, risk: maxRisk, flags: uniqueFlags, blocked,
    reason: blocked ? blockReason : `${phases.length} phases complete`,
    phases,
    report: {
      verb, pid, ts,
      phasesRun: phases.length, phasesOk: phases.filter(p => p.ok).length,
      totalFlags: uniqueFlags.length, maxRisk, blocked
    }
  };
}

/**
 * Main entry: routes shannon.scan and shannon.audit
 */
async function shannon(subverb, args, envelope) {
  if (subverb === 'audit') return audit(args?.verb || args, args?.args, envelope);
  // Default to scan
  return scan(args?.verb || args, args?.args, envelope);
}

shannon.scan = scan;
shannon.audit = audit;

module.exports = shannon;
if (require.main === module) {
  const sub = process.argv[2] || 'scan';
  const verb = process.argv[3] || 'test.ping';
  shannon(sub, { verb, args: '' }, { pid: 'cli' })
    .then(r => console.log(JSON.stringify(r, null, 2)));
}
