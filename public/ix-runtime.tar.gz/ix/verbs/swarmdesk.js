// IX verb: swarmdesk | PID: asolaria | Profile: asolaria | IX-510
// SwarmDesk surface — 3 verbs: swarmdesk.sync, swarmdesk.status, swarmdesk.task
// Connects to madnessinteractive.cc/api/mcp/ using Omnispindle RPC pattern
// Source: swarmdesk-dashboard-hooks.js (tool invocation mapper)

const SWARMDESK_BASE = process.env.SWARMDESK_URL || 'https://madnessinteractive.cc/api/mcp';

const SUBCOMMANDS = {
  sync:   { endpoint: '/sync',   method: 'POST', risk: 2, description: 'Sync project state with SwarmDesk 3D dashboard' },
  status: { endpoint: '/status', method: 'GET',  risk: 0, description: 'Get SwarmDesk dashboard and project status' },
  task:   { endpoint: '/task',   method: 'POST', risk: 3, description: 'Execute MCP tool via SwarmDesk dispatcher' },
};

/**
 * Omnispindle RPC envelope — mirrors the dashboard-hooks executeMCPTool pattern.
 * All calls to SwarmDesk go through this envelope so the 3D dashboard can
 * log activity and route to the correct project workstation.
 */
function buildRPCEnvelope(verb, payload) {
  return {
    jsonrpc: '2.0',
    method: verb,
    params: payload || {},
    id: `ix-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    meta: { source: 'ix-swarmdesk', pid: 'asolaria', ts: new Date().toISOString() }
  };
}

/**
 * @param {string} command — format: "subcommand [json-payload]"
 *   e.g. "sync {\"project\":\"Asolaria\"}"
 *   e.g. "status"
 *   e.g. "task {\"tool\":\"search\",\"query\":\"open issues\"}"
 * @returns {Promise<{ok: boolean, result: any, ts: number}>}
 */
async function swarmdesk(command) {
  const ts = Date.now();
  if (!command) {
    return { ok: false, result: { error: 'usage: swarmdesk.sync|swarmdesk.status|swarmdesk.task [payload]', subcommands: Object.keys(SUBCOMMANDS) }, ts };
  }

  const parts = command.trim().split(/\s+/);
  let sub = parts[0].replace(/^swarmdesk\./, '');
  const rawArgs = parts.slice(1).join(' ');

  const entry = SUBCOMMANDS[sub];
  if (!entry) {
    return { ok: false, result: { error: `unknown subcommand "${sub}"`, valid: Object.keys(SUBCOMMANDS) }, ts };
  }

  let payload = {};
  if (rawArgs) {
    try {
      payload = JSON.parse(rawArgs);
    } catch (_) {
      payload = { query: rawArgs };
    }
  }

  const envelope = buildRPCEnvelope(`swarmdesk.${sub}`, payload);

  try {
    const url = `${SWARMDESK_BASE}${entry.endpoint}`;
    const fetchOpts = {
      method: entry.method,
      headers: { 'Content-Type': 'application/json' }
    };
    if (entry.method === 'POST') {
      fetchOpts.body = JSON.stringify(envelope);
    }

    const res = await fetch(url, fetchOpts);
    const data = await res.json();

    return {
      ok: res.ok,
      result: {
        verb: `swarmdesk.${sub}`,
        endpoint: url,
        risk: entry.risk,
        rpcId: envelope.id,
        response: data
      },
      ts
    };
  } catch (e) {
    return { ok: false, result: { error: e.message, verb: `swarmdesk.${sub}`, endpoint: `${SWARMDESK_BASE}${entry.endpoint}` }, ts };
  }
}

module.exports = swarmdesk;
module.exports.subcommands = SUBCOMMANDS;
module.exports.buildRPCEnvelope = buildRPCEnvelope;
if (require.main === module) swarmdesk(process.argv.slice(2).join(' ')).then(r => console.log(JSON.stringify(r, null, 2)));
