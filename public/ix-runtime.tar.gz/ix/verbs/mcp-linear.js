// IX verb: mcp-linear | PID: asolaria | Profile: asolaria | IX-506
// MCP Linear surface — 4 verbs: linear.issue, linear.project, linear.search, linear.doc
// Routes IX verb strings to MCP Linear tools

const SUBCOMMANDS = {
  issue:   { tools: ['mcp__claude_ai_Linear__list_issues', 'mcp__claude_ai_Linear__get_issue', 'mcp__claude_ai_Linear__save_issue'], risk: 3 },
  project: { tools: ['mcp__claude_ai_Linear__list_projects', 'mcp__claude_ai_Linear__get_project', 'mcp__claude_ai_Linear__save_project'], risk: 4 },
  search:  { tools: ['mcp__claude_ai_Linear__search_documentation'], risk: 1 },
  doc:     { tools: ['mcp__claude_ai_Linear__get_document', 'mcp__claude_ai_Linear__create_document', 'mcp__claude_ai_Linear__update_document'], risk: 3 },
};

/**
 * @param {string} command — format: "subcommand args..." e.g. "issue ASO-15"
 * @returns {Promise<{ok: boolean, result: any, ts: number}>}
 */
async function mcpLinear(command) {
  const ts = Date.now();
  if (!command) {
    return { ok: false, result: { error: 'usage: linear.issue|linear.project|linear.search|linear.doc <args>', subcommands: Object.keys(SUBCOMMANDS) }, ts };
  }

  const parts = command.trim().split(/\s+/);
  let sub = parts[0].replace(/^linear\./, '');
  const args = parts.slice(1).join(' ');

  const entry = SUBCOMMANDS[sub];
  if (!entry) {
    return { ok: false, result: { error: `unknown subcommand "${sub}"`, valid: Object.keys(SUBCOMMANDS) }, ts };
  }

  try {
    return {
      ok: true,
      result: {
        verb: `linear.${sub}`,
        mcpTools: entry.tools,
        args,
        risk: entry.risk,
        routed: true
      },
      ts
    };
  } catch (e) {
    return { ok: false, result: { error: e.message, verb: `linear.${sub}` }, ts };
  }
}

module.exports = mcpLinear;
module.exports.subcommands = SUBCOMMANDS;
if (require.main === module) mcpLinear(process.argv.slice(2).join(' ')).then(r => console.log(JSON.stringify(r, null, 2)));
