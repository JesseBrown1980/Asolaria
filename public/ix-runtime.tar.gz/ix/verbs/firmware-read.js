// IX verb: firmware.read | PID: asolaria | Profile: asolaria
// Reads SPI flash dump via CH341A (Linux only, gated at risk 3)
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

async function firmwareRead(target) {
  const outDir = target || '/tmp/sovereignty-firmware';
  const ts = new Date().toISOString().replace(/[:.]/g, '-');
  const outFile = path.join(outDir, `spi-dump-${ts}.rom`);

  if (process.platform !== 'linux') {
    return { ok: false, reason: 'firmware.read requires bare-metal Linux', ts: Date.now() };
  }

  try {
    if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

    // Check flashrom available
    execSync('which flashrom', { timeout: 5000 });

    // Read SPI flash (CH341A must be connected)
    execSync(`flashrom -p ch341a_spi -r "${outFile}"`, { timeout: 120000 });

    // Verify by reading again
    const verifyFile = outFile.replace('.rom', '-verify.rom');
    execSync(`flashrom -p ch341a_spi -r "${verifyFile}"`, { timeout: 120000 });

    // Compare hashes
    const hash1 = execSync(`sha256sum "${outFile}"`, { encoding: 'utf8' }).split(' ')[0];
    const hash2 = execSync(`sha256sum "${verifyFile}"`, { encoding: 'utf8' }).split(' ')[0];

    const match = hash1 === hash2;
    if (!match) {
      return { ok: false, reason: 'SPI reads do not match — bad connection', hash1, hash2, ts: Date.now() };
    }

    // Clean up verify file
    fs.unlinkSync(verifyFile);

    return { ok: true, file: outFile, hash: hash1, verified: true, ts: Date.now() };
  } catch (e) {
    return { ok: false, reason: e.message, ts: Date.now() };
  }
}

module.exports = firmwareRead;
if (require.main === module) firmwareRead(process.argv[2]).then(r => console.log(JSON.stringify(r, null, 2)));
