// IX verb: antigravity | PID: asolaria | Profile: asolaria | IX-510
// Antigravity surface — 2 verbs: antigravity.prompt, antigravity.status
// Last-resort AI provider in the 9-provider chain
// Source: externalBrainConnector.js (provider IDs: openai, cursor, antigravity)

const ASO_BASE = process.env.ASO_URL || 'http://localhost:4781';
const ANTIGRAVITY_SECRET_KEY = 'integrations.external.antigravity';

const SUBCOMMANDS = {
  prompt: { endpoint: '/api/integrations/external/antigravity/prompt', method: 'POST', risk: 2, description: 'Send prompt through Antigravity fallback provider' },
  status: { endpoint: '/api/integrations/external/antigravity/status', method: 'GET',  risk: 0, description: 'Check Antigravity provider availability and config' },
};

/**
 * Provider chain position (from voiceConnector.js + externalBrainConnector.js):
 *   1. Local Whisper
 *   2. OpenAI Cloud
 *   3. Gemini Cloud
 *   4. Cursor
 *   5. Antigravity  <-- THIS MODULE (last resort)
 *
 * Antigravity uses OpenAI-compatible chat completions API style.
 * Base URL, API key, and model are stored in Asolaria secure vault
 * under the "integrations.external.antigravity" prefix.
 *
 * @param {string} command — format: "subcommand [args]"
 *   e.g. "status"
 *   e.g. "prompt What is the capital of Brazil?"
 *   e.g. "prompt {\"messages\":[{\"role\":\"user\",\"content\":\"hello\"}],\"model\":\"default\"}"
 * @returns {Promise<{ok: boolean, result: any, ts: number}>}
 */
async function antigravity(command) {
  const ts = Date.now();
  if (!command) {
    return {
      ok: false,
      result: {
        error: 'usage: antigravity.prompt|antigravity.status [payload]',
        subcommands: Object.keys(SUBCOMMANDS),
        chainPosition: 'last-resort (position 5 of 5 external providers)',
        secretKey: ANTIGRAVITY_SECRET_KEY
      },
      ts
    };
  }

  const parts = command.trim().split(/\s+/);
  let sub = parts[0].replace(/^antigravity\./, '');
  const rawArgs = parts.slice(1).join(' ');

  const entry = SUBCOMMANDS[sub];
  if (!entry) {
    return { ok: false, result: { error: `unknown subcommand "${sub}"`, valid: Object.keys(SUBCOMMANDS) }, ts };
  }

  let payload = {};
  if (rawArgs) {
    try {
      payload = JSON.parse(rawArgs);
    } catch (_) {
      // Bare string becomes a simple user prompt
      payload = {
        messages: [{ role: 'user', content: rawArgs }],
        apiStyle: 'openai_chat_completions'
      };
    }
  }

  try {
    const url = `${ASO_BASE}${entry.endpoint}`;
    const fetchOpts = {
      method: entry.method,
      headers: { 'Content-Type': 'application/json' }
    };
    if (entry.method === 'POST') {
      fetchOpts.body = JSON.stringify(payload);
    }

    const res = await fetch(url, fetchOpts);
    const data = await res.json();

    return {
      ok: res.ok,
      result: {
        verb: `antigravity.${sub}`,
        endpoint: url,
        risk: entry.risk,
        chainPosition: 5,
        apiStyle: 'openai_chat_completions',
        response: data
      },
      ts
    };
  } catch (e) {
    return { ok: false, result: { error: e.message, verb: `antigravity.${sub}` }, ts };
  }
}

module.exports = antigravity;
module.exports.subcommands = SUBCOMMANDS;
if (require.main === module) antigravity(process.argv.slice(2).join(' ')).then(r => console.log(JSON.stringify(r, null, 2)));
