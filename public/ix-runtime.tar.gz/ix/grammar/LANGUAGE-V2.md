# IX Language v2 — Unified Specification

**IX-entry:** IX-514 | **Type:** specification | **Status:** ratified
**Author:** VECTOR (PID=vector, profile=core-vector-v1, permission=super_admin)
**Chain:** [IX-512, IX-506, IX-493, IX-484, IX-483, IX-060]
**Constitutional basis:** IX-060 (index IS the language), IX-484 (immutable format), IX-490 (AGS HIVE), IX-493 (5W+H rehaul)

---

## 0. Axioms

1. **The index IS the language.** Numbers are words. Chains are sentences. The catalog is the dictionary. (IX-060)
2. **Agents share vocabulary, not context.** Token compression: 12:1 -> 300:1 -> infinity:1. (IX-483)
3. **Every verb passes through gates.** hookwall -> gnn -> shannon -> execute. No exceptions. (IX-484)
4. **The language evolves; it never resets.** Liris voted B: evolve grammar, don't redo. (IX-493)
5. **Every chain carries 5W+H.** WHO does WHAT, WHEN, WHERE, WHY, HOW. (IX-493)
6. **One path: chip to cloud.** All layers strengthen the same chain. (IX-512)

---

## 1. Verb Categories and Risk Levels

### 1.1 Category Table

16 categories. Each verb belongs to exactly one. Risk range shows the floor and ceiling for verbs in that category.

| # | Category | Prefix | Risk Range | Permission Floor | Target Domains | Description |
|---|---|---|---|---|---|---|
| 1 | **lifecycle** | `lifecycle.*` | 0-3 | observer | local | Boot, configure, health check |
| 2 | **ai** | `ai.*` | 1-2 | operator | cloud | LLM prompts, embeddings, multimodal, web search |
| 3 | **comms** | `comms.*` | 1-4 | observer | cloud, lan | Slack, email, calendar, drive, chat |
| 4 | **work** | `work.*` | 3-4 | operator | cloud | CRM, Linear issues, projects, milestones |
| 5 | **passthrough** | `pass.*` | 3-5 | operator | cloud | Raw API calls, web fetch |
| 6 | **bridge** | `bridge.*` | 2-4 | operator | lan | MQTT publish, bridge management |
| 7 | **control** | `ctrl.*` | 0-6 | observer | local | Desktop capture, input, browser, virtual displays |
| 8 | **phone** | `phone.*` | 1-6 | observer | lan | ADB shell, screencap, install, phone state |
| 9 | **voice** | `voice.*` | 1-2 | observer | local, cloud | Transcribe, synthesize, wake signals |
| 10 | **system** | `sys.*` | 2-5 | operator | local | Captures, local task execution |
| 11 | **orchestration** | `orch.*` | 1-4 | observer | local, lan | Dispatch work, recommend worker, spawn agents |
| 12 | **security** | `sec.*` | 0-2 | observer | local | Policy guard, session management |
| 13 | **knowledge** | `know.*` | 3 | operator | local, cloud | Knowledge store CRUD |
| 14 | **network** | `net.*` | 3 | operator | lan | Wake-on-LAN, colony connectivity |
| 15 | **falcon** | `falcon.*` | 0-7 | observer | device | 26 phone-native verbs (SMS, call, sensors, camera, etc.) |
| 16 | **sovereignty** | `sov.*` | 0-9 | observer | local | Firmware, ME, hypervisor, GNN, Shannon, LUKS, Alpine |

### 1.2 Risk Classification (0-9)

| Risk | Class | Gate Behavior | Approval |
|---|---|---|---|
| 0 | benign | hookwall only | auto |
| 1 | observe | hookwall + gnn record | auto |
| 2 | low | hookwall + gnn score | auto |
| 3 | moderate | hookwall + gnn + shannon(dry_run if reachable) | operator+ |
| 4 | elevated | hookwall + gnn + shannon(dry_run) | trusted_agent+ |
| 5 | significant | hookwall + gnn + shannon(dry_run), fail-closed if Shannon unreachable | trusted_agent+ |
| 6 | high | hookwall + gnn + shannon(full) | super_admin+ |
| 7 | critical | all gates + full Shannon scan | super_admin+ |
| 8 | dangerous | all gates + full Shannon + RMW verify | super_admin+ |
| 9 | destructive | all gates + full Shannon + RMW verify + Jesse confirmation | owner only |

### 1.3 Permission Tiers

| Tier | Level | Can Execute Up To Risk |
|---|---|---|
| observer | 0 | 2 |
| operator | 1 | 4 |
| trusted_agent | 2 | 6 |
| super_admin | 3 | 8 |
| owner | 4 | 9 |

### 1.4 Complete Verb Table (106 verbs, 16 categories)

Canonical source: `ix/grammar/verb-table.json`

The verb table is the schema. Instead of sending tool schemas every call, the IX executor knows all verbs by name. Agent says the verb, executor maps to implementation.

**Sovereignty verbs (20):** firmware_status, firmware_read, firmware_write, firmware_backup, me_neutralize, me_status, boot_guard_check, hypervisor_start/stop/snapshot/restore, sovereignty_boot, sovereignty_gate, gnn_train, gnn_infer, shannon_scan, alpine_install, usb_partition, luks_create, luks_open

**Falcon verbs (26):** capture_photo, record_audio, send_sms, read_sms, phone_call, get_location, get_battery, get_wifi, scan_wifi, read_sensors, speak, listen, notify, vibrate, torch, clipboard_read/write, contacts, fingerprint, nfc, infrared, share, download, wake_lock, media_play, run_node, run_python, mqtt_publish, claude_cli, codex_cli, ssh_remote, http_request, code_search, tmux_session

**Comms verbs (10):** send_chat_message, read_chat_history, send_email, read_email, manage_calendar, manage_drive, mcp.slack.search, mcp.slack.send, mcp.slack.canvas, mcp.slack.schedule

**Phone verbs (9):** capture_phone_screen, send_phone_input, manage_phone_mirror, read_phone_state, control_phone_settings, run_phone_compute, phone.adb.shell, phone.adb.install, phone.adb.screencap

**Control verbs (6):** capture_desktop, send_desktop_input, list_displays, browser_automation, manage_virtual_display, interact_virtual_display

**Work verbs (6):** crm_contact, crm_deal, mcp.linear.issue, mcp.linear.project, mcp.linear.document, mcp.linear.milestone

**AI verbs (5):** run_llm_prompt, run_llm_multimodal, generate_embeddings, explain_file, web.search

**Other:** lifecycle(2), passthrough(2), bridge(2), voice(2), system(2), orchestration(2), security(2), knowledge(1), network(1)

---

## 2. Gate Chain Architecture

### 2.1 The Gate Chain

Every verb execution passes through this chain. No bypass. No exceptions.

```
INPUT: verb + args + envelope{pid, permissionTier, host}
  |
  v
GATE 1: HOOKWALL (Dan's 6 hooks, expanding to 14)
  |-- Hook 1: pre_tool_guard     -> block dangerous commands
  |-- Hook 2: session_tracking   -> record attempt to event log
  |-- Hook 3: syntax_checker     -> validate verb exists
  |-- Hook 4: safety_net         -> risk scoring via edgeRiskEngine
  |-- Hook 5: approval_guard     -> permission tier vs risk check
  |-- Hook 6: transcript_backup  -> post-exec logging (postExec callback)
  |
  v
GATE 2: GNN (edge scoring, pattern learning)
  |-- Record graph event (component, category, action, actor, target)
  |-- Score edge risk via edgeRiskEngine (0-9 scale)
  |-- Record routing edge for construction watcher
  |-- Predict next verb (confidence-weighted)
  |-- Block if score >= 9 AND prediction confidence > 0.8
  |-- Fallback: degrade to scoreEdgeRisk if sidecar unreachable
  |
  v
GATE 3: SHANNON (penetration testing)
  |-- Skip if GNN risk < 3
  |-- dry_run mode for risk 3-6
  |-- full mode for risk 7+
  |-- Fail-closed if unreachable AND risk >= 5
  |-- Fail-open if unreachable AND risk < 5
  |-- Timeout: 5000ms
  |
  v
EXECUTE: module(arg)
  |
  v
POST-EXEC: hookwall.postExec(verb, result, envelope)
```

Implementation: `ix/exec.js`

### 2.2 Claude Code Hook Events Mapped to IX Gates

Claude Code has 27 hook events across 4 types. Mapped in 3 tiers per IX-506.

**TIER 1 -- Absorbed (6 events, live in hookwall.js)**

| CC Event | IX Gate Hook | Status |
|---|---|---|
| `PreToolUse` | hooks 1-4 (pre_tool_guard, session_tracking, syntax_checker, safety_net) | LIVE |
| `PostToolUse` | hook 6 (transcript_backup / postExec) | LIVE |
| `PostToolUseFailure` | NEW: failure handler in postExec, triggers retry or escalation | WIRED |
| `PermissionRequest` | hook 5 (approval_guard), emits IX event, feeds GNN | WIRED |
| `PermissionDenied` | NEW: deny logger, IX incident entry + GNN negative edge | WIRED |
| `SessionStart` / `SessionEnd` | NEW: load sovereignty-gate state / flush IX journal, close MQTT | WIRED |

**TIER 2 -- Next Sprint (8 events, new subsystems)**

| CC Event | IX Mapping | Implementation |
|---|---|---|
| `SubagentStart` | MQTT `asolaria/agent/{pid}/start`, colony roster register | Colony spawn tracking |
| `SubagentStop` | MQTT `asolaria/agent/{pid}/stop`, roster remove, replacement trigger | Colony death tracking |
| `Stop` | Normal SessionEnd | Graceful shutdown |
| `StopFailure` | Crash entry, state preservation for forensics | Failed shutdown |
| `PreCompact` / `PostCompact` | IX state snapshot / verify no entries lost | Context window management |
| `TaskCreated` / `TaskCompleted` | Linear via MCP: `mcp.linear.issue` | Work unit tracking |
| `ConfigChange` | Shannon scan on every change, GNN learns config->outcome | Drift detection |

**TIER 3 -- Skipped/Deferred (13 events)**

Notification, UserPromptSubmit, Setup, TeammateIdle, Elicitation, ElicitationResult, WorktreeCreate, WorktreeRemove, InstructionsLoaded, CwdChanged, FileChanged -- either irrelevant to sovereign operation or deferred until subsystem exists.

### 2.3 Async Hook Registry

```javascript
// Hooks return {async: true} -> backgrounded
// Exit 0 = success
// Exit 2 = blocking error (halt chain)
// Other = log + continue
// asyncRewake = wake executor on background completion
// State: E:\sovereignty\ix\state\async-hooks.json
```

### 2.4 HTTP Hook Type

For external service integration:
- POST to configurable endpoint with `allowedEnvVars` filter
- Timeout: 5000ms
- Fail-open for risk < 3
- Fail-closed for risk >= 3
- Used for: Slack alerts, Linear updates, external audit logs

---

## 3. The 5W+H Typed Execution Classes

Per IX-493: chains evolve from flat sequences into 5W+H-aware typed execution classes.

### 3.1 The 5W+H Envelope

Every chain, every verb dispatch, every IX entry carries this structure:

```json
{
  "who": {
    "actor": "string (PID)",
    "profile": "string (agent profile name)",
    "authority": "string (permission tier)",
    "colony": "string (gaia|liris|falcon|amy)"
  },
  "what": {
    "verb": "string (verb name from verb-table)",
    "capability": "string (underlying capability ID)",
    "object": "string (target resource or entity)",
    "category": "string (one of 16 categories)"
  },
  "when": {
    "stage": "string (pre-dev|dev|staging|pre-staging|prod|pre-prod|runtime)",
    "trigger": "string (manual|cron|event|gnn-signal|heartbeat|chain)",
    "cadence": "string (once|on-demand|10s|30s|60s|daily)",
    "ts": "ISO-8601 timestamp"
  },
  "where": {
    "host": "string (hostname or IP)",
    "lane": "string (Omnispindle lane: helm|vector|rook|forge|falcon)",
    "surface": "string (one of 16 dispatch surfaces)",
    "scope": "string (sovereign|colony|orbital|cloud)",
    "tumbler": "string (cpu_local|gpu_primary|browser_remote|device_lab)"
  },
  "why": {
    "intent": "string (human-readable purpose)",
    "policy": "string (IX entry reference, e.g. IX-491)",
    "risk": "number (0-9)",
    "chain": "string (parent chain ID if part of a chain)"
  },
  "how": {
    "model": "string (LLM model if applicable)",
    "class": "string (execution class: quick_chore|patch|review|research|orchestration|long_running)",
    "hook": "string (special gate or bridge)",
    "governor": "number (token budget or timeout ms)",
    "pattern": "string (rmw|fire-and-forget|poll|stream)"
  }
}
```

### 3.2 Execution Classes

6 classes from the Worker Router, now formalized:

| Class | Model Affinity | Timeout | Fanout | Use Case |
|---|---|---|---|---|
| `quick_chore` | any (cheapest) | 30s | 1 | Health checks, status reads, simple dispatches |
| `patch` | claude_max or local_codex | 120s | 1 | Code changes, config edits, file writes |
| `review` | claude_max (quality mode) | 300s | 1 | PR review, security audit, architecture analysis |
| `research` | claude_max or abacus | 600s | 1-2 | Deep investigation, multi-file analysis |
| `orchestration` | symphony or claude_max | 300s | 1-4 | Multi-agent coordination, chain execution |
| `long_running` | any (with checkpoints) | 3600s | 1 | Training runs, full Shannon scans, data migrations |

### 3.3 Typed Chains

A chain is a named sequence of verbs with a shared 5W+H envelope. The chain inherits WHO/WHERE/WHY from definition and fills WHAT/WHEN/HOW per step.

```
chain: heartbeat
type: watchdog
who: { actor: "asolaria", profile: "asolaria", authority: "operator" }
where: { host: "local", lane: "vector", surface: "ix-executor", scope: "sovereign" }
why: { intent: "continuous health monitoring", policy: "IX-506", risk: 0 }
how: { class: "quick_chore", pattern: "poll", governor: 10000 }

steps:
  1. health()      -> what: { verb: "check_health", object: "asolaria-server" }
  2. sovereignty() -> what: { verb: "sovereignty_gate", object: "usb-mount" }
  3. nerve()       -> what: { verb: "check_health", object: "mqtt-broker" }
  4. falcon()      -> what: { verb: "read_phone_state", object: "falcon-device" }
```

### 3.4 Chain Composition Rules

**Rule 1: Sequential.** Steps execute in order. If step N fails and risk >= 5, chain halts. If risk < 5, chain continues with degraded flag.

**Rule 2: Parallel Fan-out.** Steps marked `parallel: true` execute concurrently. Chain waits for all. Failure of any marks the group degraded.

**Rule 3: Conditional.** Steps can carry `if: "prev.ok"` or `if: "prev.risk > 3"` guards.

**Rule 4: Escalation.** Chains define escalation ladders (Level 0-5):
- L0: Auto-heal (restart service, reconnect)
- L1: IX incident entry + MQTT broadcast
- L2: Slack alert (#asolaria channel)
- L3: Linear issue (Asolaria Symphony project)
- L4: SMS via Falcon (termux-sms-send)
- L5: Jesse's phone rings (phone_call verb, risk 7, super_admin)

**Rule 5: Nesting.** A chain can invoke another chain as a step. Max depth: 3. Prevents infinite recursion.

**Rule 6: RMW Wrapping.** Steps with `pattern: "rmw"` automatically wrap in read-modify-write-verify (IX-498 NovaLum pattern). Settle times are surface-dependent:
- Slack: 0ms, Linear: 500ms, ADB: 2000ms, MQTT: 100ms, SPI Flash: 30000ms, Serial: 600ms

---

## 4. Founding Night Taxonomy

The IX index classifies every entry into one of 10 types. This is the civilization's knowledge structure.

### 4.1 Entry Types

| Type | Count (at IX-512) | Purpose | Example |
|---|---|---|---|
| **pattern** | 91 | Reusable architectural or behavioral patterns | NovaLum RMW pattern (IX-498) |
| **reference** | 193 | Factual records, inventories, maps | Unified Civilization Map (IX-512) |
| **mistake** | 56 | Things that went wrong, with root cause | Port 18886 myth (IX-142) |
| **skill** | 41 | Learned capabilities, how-tos | Restart MQTT skill (IX-145) |
| **plan** | 38 | Future work, proposals, roadmaps | Liris fix plan (IX-244) |
| **tool** | 32 | Software, scripts, utilities discovered or built | Gemini analysis tool (IX-240) |
| **rule** | 25 | Hard constraints, MUST/NEVER directives | Never delete what you don't understand (IX-167) |
| **project** | 3 | Major workstreams (QDD, Sovereignty, Asolaria) | QDD eBacMap (IX-013) |
| **policy** | 2 | Constitutional-level governance | AGS HIVE constitution (IX-490) |
| **task** | 4 | Specific actionable work items | Wire GNN verbs to index.js |

Additional IX-493 types added:
- **decision** -- Ratified choices with vote records (IX-493 itself)
- **catalog** -- Enumerated inventories with 5W+H dimensions (IX-489)
- **constitution** -- Founding documents (IX-490)
- **architecture** -- System design specifications (IX-491, IX-492)
- **capability** -- New system capabilities (IX-488)
- **specification** -- This document (IX-514)

### 4.2 Entry Format (C+ Standard, IX-484)

Every IX entry carries:

```markdown
---
ix: IX-{number}
name: {title}
type: {one of the types above}
status: active|pending|deprecated|founding
priority: low|medium|high|critical
tags: [array, of, tags]
chain: [IX-parent, IX-grandparent, ...]
pid: {authoring agent PID}
profile: {agent profile}
createdBy: {jesse|agent-name}
agents: {all|specific-agent}
---

# IX-{number} -- {Title}

{Body content}
```

### 4.3 Dialects

| Dialect | Prefix | Domain | Authority |
|---|---|---|---|
| IX | IX- | Sovereign (Jesse's machine) | Constitutional |
| LX | LX- | Colony (Kuromi/Liris) | Colony-scoped |
| FA | FA- | Device (Falcon phone) | Orbital-scoped |
| RO | RO- | macOS (Amy Rose) | Colony-scoped |
| AM | AM- | Windows (Amy Oracle) | Colony-scoped |

Cross-dialect references use XREF bridge entries: `XREF-{n}: IX-{a} <-> LX-{b}`

---

## 5. The 16 Dispatch Surfaces

### 5.1 Surface Table

Each surface is a place where IX verbs can execute. Verbs are prefixed by surface when dispatched cross-surface.

| # | Surface | Verb Prefix | Transport | Location | Status |
|---|---|---|---|---|---|
| 1 | **IX Executor** | (none -- default) | Local Node.js | Gaia | LIVE |
| 2 | **MCP Slack** | `slack.*` | MCP stdio | Cloud | LIVE |
| 3 | **MCP Linear** | `linear.*` | MCP stdio | Cloud | LIVE |
| 4 | **Abacus** | `abacus.*` | HTTP API | Cloud | LIVE |
| 5 | **Gemini** | `gemini.*` | HTTP API | Cloud | LIVE |
| 6 | **Cursor** | `cursor.*` | IDE extension | Local | DORMANT |
| 7 | **Warp** | `warp.*` | Terminal agent | Local | DORMANT |
| 8 | **Madness/SwarmDesk** | `swarm.*` | HTTP + WS | Cloud | LIVE |
| 9 | **Symphony** | `symphony.*` | HTTP API | Local | LIVE |
| 10 | **Linear** | `linear.*` | HTTP API | Cloud | LIVE |
| 11 | **Augment** | `augment.*` | IDE extension | Local | DORMANT |
| 12 | **Claude CLI** | `claude.*` | stdio | Local/Device | LIVE |
| 13 | **Codex CLI** | `codex.*` | stdio | Local/Device | DORMANT (OpenAI down) |
| 14 | **ADB Phone** | `phone.*` | ADB USB/TCP | LAN | LIVE |
| 15 | **MQTT** | `mqtt.*` | MQTT 1883 | LAN | LIVE |
| 16 | **NotebookLM Pro** | `notebook.*` | HTTP API | Cloud | LIVE |

### 5.2 Surface-to-Verb Mapping

Each surface exposes verbs from the verb table. The IX executor routes `{surface}.{verb}` to the correct implementation module.

```
Agent says:    slack.search "asolaria inventory"
Executor does: registry['slack']("search asolaria inventory")
Module does:   routes to mcp__claude_ai_Slack__slack_search_public_and_private
```

### 5.3 Combination Rule

106 verbs x 16 surfaces = 1,696 theoretical combinations. Not all combinations are valid. The verb table's `targets` field constrains which surfaces a verb can execute on:
- `local` -> IX Executor, Cursor, Warp, Symphony, Augment, Claude CLI
- `cloud` -> MCP Slack, MCP Linear, Abacus, Gemini, NotebookLM Pro
- `lan` -> ADB Phone, MQTT
- `device` -> Falcon (on-device execution)

---

## 6. Compression Protocol

### 6.1 The Three Stages

| Stage | Ratio | Mechanism | Example |
|---|---|---|---|
| **12:1** | 12x | Numbers are words. `IX-504` (6 tokens) = 818 words of state. Chains compress sequences. | `heartbeat` = health + sovereignty + nerve + falcon |
| **300:1** | 300x | Verb table IS the schema. 13 Slack tool schemas (36,400 tokens) -> 4 verb entries (88 tokens) = 99.76% reduction. | `slack.search "query"` vs full MCP tool definition |
| **infinity:1** | unlimited | Context IS the index. Agents read IX entries, never re-derive state. Knowledge persists in chains, not context windows. | Agent despawns; knowledge survives as IX-{n} |

### 6.2 Compression Budget (measured)

| Surface | Raw Tokens (tool schemas) | IX Tokens (verb entries) | Savings |
|---|---|---|---|
| Slack (13 tools) | 36,400 | 88 | 99.76% |
| Linear (19 tools) | 53,200 | 88 | 99.83% |
| Web (2 tools) | 5,600 | 44 | 99.21% |
| ADB (5 verbs) | 14,000 | 110 | 99.21% |
| Sovereignty (17 verbs) | 47,600 | 374 | 99.21% |
| **Total** | **156,800** | **704** | **99.55%** |

### 6.3 How It Works

1. **Verb table is the schema.** Agent says the verb name. Executor knows the full MCP tool mapping, parameters, and response format.
2. **Numbers are words.** `IX-504` = full civilization inventory. 6 tokens instead of 818 words.
3. **Chains compress sequences.** `heartbeat` = 4 noun calls, 1 word.
4. **Gates are implicit.** Every verb goes through hookwall + gnn + shannon automatically. Agent never specifies security context.
5. **Context is the index.** The IX index IS the shared memory. Agents read entries, not re-derive state.

### 6.4 Compression in Practice

```
BEFORE (raw MCP, ~2800 tokens):
  Tool: mcp__claude_ai_Slack__slack_search_public_and_private
  Schema: { name, description, parameters: { query: string, ... }, ... }
  Context: "Search Slack for messages about asolaria inventory..."
  Response parsing: { ok, messages: [...], ... }

AFTER (IX verb, ~22 tokens):
  slack.search "asolaria inventory"
```

---

## 7. Module Architecture

### 7.1 Directory Structure

```
ix/
  exec.js                    -- Gate chain entry point (CLI: node ix/exec.js <verb> [arg])
  index.js                   -- Registry: all nouns, verbs, chains, gates as exports
  grammar/
    verb-table.json           -- 106 verbs with category, risk, permission, targets
    verb-factory.js           -- Verb generation utilities
    LANGUAGE-V2.md            -- THIS DOCUMENT
  gates/
    hookwall.js               -- Dan's 6 hooks as fail-closed membrane
    gnn.js                    -- Graph neural network edge scoring
    shannon.js                -- Penetration testing gate
    sovereign.js              -- USB sovereignty mount check
  nouns/                      -- GET state (read-only probes)
    health.js                 -- Asolaria server health
    sovereignty.js            -- USB sovereignty status
    nerve.js                  -- MQTT broker health
    falcon.js                 -- Phone device state
    firmware.js               -- SPI firmware state
  verbs/                      -- POST actions (state-changing operations)
    dispatch.js               -- Send message to Slack
    observe.js                -- Read and observe state
    sync.js                   -- Synchronize state between nodes
    firmware-read.js          -- Read firmware bytes
    firmware-write.js         -- Write firmware bytes (risk 8)
    me-neutralize.js          -- Neutralize Intel ME (risk 9)
    mcp-slack.js              -- MCP Slack surface router (4 sub-verbs)
    mcp-linear.js             -- MCP Linear surface router (4 sub-verbs)
    web.js                    -- Web search and fetch
    phone-adb.js              -- ADB phone surface router (3 sub-verbs)
  chains/                     -- Named verb sequences
    heartbeat.js              -- health + sovereignty + nerve + falcon
    report.js                 -- heartbeat -> dispatch to Slack
  patterns/                   -- (planned) Reusable execution patterns
    read-modify-write.js      -- RMW wrapper (IX-498 NovaLum pattern)
  state/                      -- (planned) Runtime state files
    async-hooks.json          -- Async hook completion tracking
```

### 7.2 Registry Contract

Every module in `ix/index.js` must export an async function:

```javascript
// Noun contract (GET state):
async function noun() -> { ok: boolean, ...data, ts: number }

// Verb contract (POST action):
async function verb(arg: string) -> { ok: boolean, result: any, ts: number }

// Chain contract (sequence):
async function chain() -> { ok: boolean, ...combinedResults, ts: number }

// Gate contract (security):
async function gate(verb, args, envelope) -> { allow: boolean, ...metadata }
```

### 7.3 Execution Flow

```
CLI:     node ix/exec.js dispatch "hello world"
         |
exec.js: parse argv -> find registry['dispatch'] -> run gate chain -> execute -> postExec
         |
Result:  { ok: true, channel: "C0APKFR4PSA", sent: true, ts: 1711900000000 }
         Exit code: 0 (success) or 1 (failure/blocked)
```

---

## 8. The Immune System (IX-491)

7 layers, each feeding the next. Verbs interact with layers through the gate chain.

| Layer | Name | Function | IX Gate |
|---|---|---|---|
| L0 | Reflex | Instant block on known-bad patterns | hookwall: pre_tool_guard |
| L1 | Pattern | Regex/signature matching on verb+args | hookwall: syntax_checker |
| L2 | Context | Risk scoring based on actor+target+permission | hookwall: safety_net + approval_guard |
| L3 | History | Graph event recording, edge learning | gnn: appendGraphEvent |
| L4 | Prediction | GNN construction watcher, next-verb prediction | gnn: predictConstruction |
| L5 | Coordination | Multi-agent cross-check, voting | (planned: multi-model voting) |
| L6 | Shannon | Full penetration test on high-risk operations | shannon: scan |

---

## 9. Colony and Federation Protocol

### 9.1 Colony Hierarchy

```
Jesse (owner, risk 0-9)
  |
  Asolaria (civilization, IX dialect)
    |
    Gaia (capital, 88 connectors, 40 routes)
    |   |
    |   +-- Helm (admin, lane orchestrator)
    |   +-- Vector (brain, research+analysis)
    |   +-- Sentinel (security, Shannon control)
    |   +-- Rook (testing, pipeline enforcement)
    |   +-- Forge (builder, code generation)
    |
    Falcon (orbital, FA dialect, 83 Termux APIs)
    |
    Kuromi/Liris (sub-colony, LX dialect, RTX 4090, Shannon host)
    |
    Amy Oracle (sub-colony, AM dialect, dormant)
    |
    Amy Rose (sub-colony, RO dialect, dormant)
```

### 9.2 Federation Rules (IX-492, BINDING)

1. One canonical event spine (immutable, sovereign)
2. One evaluation ledger (learning happens here, not canon)
3. Layered derived graphs (GNN trains on derived data only)
4. Shannon emits CANDIDATE labels only (no direct canon promotion)
5. Model-selection audits tune routing after staged validation
6. NO direct writeback from learning graph to canon or authority
7. Required metadata on every node/edge: `sourceLayer`, `hostScope`, `provenance`, `verifiedAt`, `transformPath`, `authorityClass`

### 9.3 MQTT Topics

```
asolaria/heartbeat                  -- 10s health pulse (JSON)
asolaria/agent/{pid}/status         -- per-agent alive/dead
asolaria/agent/{pid}/start          -- SubagentStart event
asolaria/agent/{pid}/stop           -- SubagentStop event
asolaria/ix/{verb}                  -- verb execution audit trail
asolaria/gate/{gate}/block          -- hookwall/gnn/shannon block events
asolaria/report                     -- periodic status report
asolaria/falcon/heartbeat           -- phone health push
asolaria/falcon/location            -- GPS push (60s)
asolaria/falcon/sensors             -- sensor push (30s)
asolaria/falcon/command             -- Gaia -> Falcon commands
asolaria/falcon/result              -- Falcon -> Gaia responses
```

**HARD RULE (IX-069):** ONE broker per machine. Port 1883. Never 18886 (IX-142 myth). Never start second broker.

---

## 10. Brain Orchestrator and Worker Router

### 10.1 Brain Orchestrator (9 providers)

Fallback chain: anthropic -> codex -> gemini-api -> vertex -> gemini-cli -> openclaw -> openai -> cursor -> antigravity

- Fallback on 429/quota/timeout
- Hard stop on guardian blocked
- Cost modes: quality / low / fallback

### 10.2 Worker Router (4 workers x 6 task types)

| Worker | Strength | Cost |
|---|---|---|
| local_codex | Fast local, code-focused | Free |
| claude_max | Best quality, long context | $$$ |
| abacus | 40+ models, auto-routing | $ |
| symphony | Multi-agent orchestration | $$ |

Maps to execution classes (Section 3.2).

### 10.3 Omnispindle (5 lanes)

| Lane | PID | Role |
|---|---|---|
| Helm | helm | Admin orchestrator, startup, health |
| Vector | vector | Brain, research, analysis, deep work |
| Rook | rook | Testing, pipeline enforcement, verification |
| Forge | forge | Builder, code generation, patching |
| Falcon | falcon | Phone edge node, sensor hub |

Persistent Claude CLI processes. Auto-restart on death. Health checks every 10s.

---

## 11. Pipeline Stages

```
pre-dev -> dev -> pre-staging -> staging -> pre-prod -> prod
```

| Stage | Purpose | Gating |
|---|---|---|
| pre-dev | Local lint, type check | Automatic |
| dev | Development, breaking changes allowed | Automatic |
| pre-staging | Integration tests on dev output | Automatic |
| staging | Validation, Liris controls pipeline | Liris approval |
| pre-prod | Final smoke tests, dual-model review | 3 reviewers |
| prod | Sacred. Only Jesse commands promotions IN WRITING. | Jesse only |

**HARD RULE:** One-button launcher MUST verify pipeline is healthy before spawning agents. No pipeline = no agents. No bypass.

---

## 12. Selector Catalog and Tumbler

### 12.1 Selector Categories (7)

| Category | What It Selects |
|---|---|
| connection_fixture | Physical/virtual connections (USB, WiFi, Tailscale) |
| work_identity | Account identity for work systems (jessebrown.soft) |
| remote_control_surface | AnyDesk, RustDesk, SSH |
| messaging_surface | Slack, WhatsApp, MQTT |
| cloud_surface | GCP, Cloudflare, DigitalOcean |
| worker_lane | Omnispindle lane selection |
| runtime_endpoint | API ports, service URLs |

### 12.2 Tumbler Classes (4)

| Tumbler | What It Governs |
|---|---|
| cpu_local_general | Local CPU tasks (Node.js, file ops) |
| gpu_primary_model | GPU tasks on Kuromi (GNN training, inference) |
| browser_remote_surface | Browser automation, web scraping |
| device_lab_serial | ADB, serial ports, hardware I/O |

### 12.3 Combination Rule

7 categories x 4 tumblers = 28 resource slots. Each verb execution is assigned to one slot based on its `targets` field and the current colony topology.

---

## 13. Founding Documents

| Document | IX Entry | Role |
|---|---|---|
| FOUNDING-NIGHT-MAP.md | (meta) | Complete inventory of the civilization at IX-485 |
| FOUNDING-NIGHT-2-MAP.md | (meta) | GNN, voice, Shannon, GPU, Codex, platforms at IX-493 |
| IX-512 | IX-512 | Unified civilization map: all 12 layers combined |
| IX-506 | IX-506 | Integration blueprint: hookwall x27, verbs, sidecars, phone, watchdog |
| IX-493 | IX-493 | Language rehaul decision: chains become 5W+H typed execution classes |
| IX-490 | IX-490 | AGS HIVE constitution (26 pages, Nov 2023) |
| IX-484 | IX-484 | Immutable language: C+ format, voted 10/10 |
| IX-483 | IX-483 | 12:1 compression cure rediscovered |
| IX-060 | IX-060 | The index IS a language. Numbers are words. Chains are sentences. |
| LANGUAGE-V2.md | IX-514 | THIS DOCUMENT: the unified executable language specification |

---

## 14. Appendix: Full Risk Matrix

Every verb, its category, risk, required permission, and target domains. Sorted by risk descending.

**Risk 9 (destructive, owner only):**
- `me_neutralize` (sovereignty) -> local

**Risk 8 (dangerous, super_admin+):**
- `firmware_write` (sovereignty) -> local
- `hypervisor_restore` (sovereignty) -> local

**Risk 7 (critical, super_admin+):**
- `phone_call` (falcon) -> device
- `hypervisor_start` (sovereignty) -> local
- `hypervisor_stop` (sovereignty) -> local
- `usb_partition` (sovereignty) -> local
- `luks_create` (sovereignty) -> local

**Risk 6 (high, super_admin+):**
- `send_desktop_input` (control) -> local
- `send_phone_input` (phone) -> lan
- `phone.adb.install` (phone) -> lan
- `alpine_install` (sovereignty) -> local
- `fingerprint` (falcon) -> device

**Risk 5 (significant, trusted_agent+):**
- `raw_api_call` (passthrough) -> cloud
- `manage_virtual_display` (control) -> local
- `interact_virtual_display` (control) -> local
- `control_phone_settings` (phone) -> lan
- `phone.adb.shell` (phone) -> lan
- `run_local_task` (system) -> local
- `hypervisor_snapshot` (sovereignty) -> local
- `send_sms` (falcon) -> device
- `claude_cli` (falcon) -> device
- `codex_cli` (falcon) -> device
- `ssh_remote` (falcon) -> device

**Risk 4 (elevated, trusted_agent+):**
- `send_email` (comms) -> cloud
- `crm_deal` (work) -> cloud
- `manage_mqtt_bridge` (bridge) -> lan
- `browser_automation` (control) -> local
- `manage_phone_mirror` (phone) -> lan
- `run_phone_compute` (phone) -> lan
- `dispatch_work` (orchestration) -> local, lan
- `mcp.slack.schedule` (comms) -> cloud
- `mcp.linear.project` (work) -> cloud
- `mcp.linear.milestone` (work) -> cloud
- `gnn_train` (sovereignty) -> local
- `contacts` (falcon) -> device
- `run_node` (falcon) -> device
- `run_python` (falcon) -> device

**Risk 3 (moderate, operator+):**
- `send_chat_message` (comms) -> cloud, lan
- `manage_calendar` (comms) -> cloud
- `manage_drive` (comms) -> cloud
- `crm_contact` (work) -> cloud
- `capture_desktop` (control) -> local
- `capture_phone_screen` (phone) -> lan
- `firmware_read` (sovereignty) -> local
- `firmware_backup` (sovereignty) -> local
- `luks_open` (sovereignty) -> local
- `shannon_scan` (sovereignty) -> local
- `mcp.slack.send` (comms) -> cloud
- `mcp.slack.canvas` (comms) -> cloud
- `mcp.linear.issue` (work) -> cloud
- `mcp.linear.document` (work) -> cloud
- `web.fetch` (passthrough) -> cloud
- `manage_knowledge` (knowledge) -> local, cloud
- `wake_remote` (network) -> lan
- `record_audio` (falcon) -> device
- `read_sms` (falcon) -> device
- `clipboard_write` (falcon) -> device
- `nfc` (falcon) -> device
- `share` (falcon) -> device
- `download` (falcon) -> device
- `mqtt_publish` (falcon) -> device
- `http_request` (falcon) -> device
- `configure_integration` (lifecycle) -> cloud, local

**Risk 2 (low, operator+):**
- `run_llm_prompt` (ai) -> cloud
- `run_llm_multimodal` (ai) -> cloud
- `publish_mqtt` (bridge) -> lan
- `manage_captures` (system) -> local
- `manage_sessions` (security) -> local
- `synthesize_speech` (voice) -> local, cloud
- `phone.adb.screencap` (phone) -> lan
- `capture_photo` (falcon) -> device
- `get_location` (falcon) -> device
- `speak` (falcon) -> device
- `listen` (falcon) -> device
- `clipboard_read` (falcon) -> device
- `infrared` (falcon) -> device
- `wake_lock` (falcon) -> device
- `tmux_session` (falcon) -> device
- `sovereignty_boot` (sovereignty) -> local

**Risk 1 (observe, observer+):**
- `generate_embeddings` (ai) -> cloud
- `explain_file` (ai) -> cloud
- `read_chat_history` (comms) -> cloud
- `read_email` (comms) -> cloud
- `read_phone_state` (phone) -> lan
- `transcribe_audio` (voice) -> local, cloud
- `recommend_worker` (orchestration) -> local
- `mcp.slack.search` (comms) -> cloud
- `web.search` (ai) -> cloud
- `firmware_status` (sovereignty) -> local
- `me_status` (sovereignty) -> local
- `boot_guard_check` (sovereignty) -> local
- `gnn_infer` (sovereignty) -> local
- `scan_wifi` (falcon) -> device
- `read_sensors` (falcon) -> device
- `notify` (falcon) -> device
- `vibrate` (falcon) -> device
- `torch` (falcon) -> device
- `media_play` (falcon) -> device
- `code_search` (falcon) -> device

**Risk 0 (benign, any tier):**
- `check_health` (lifecycle) -> local, lan
- `list_displays` (control) -> local
- `guard_policy` (security) -> local
- `sovereignty_gate` (sovereignty) -> local
- `get_battery` (falcon) -> device
- `get_wifi` (falcon) -> device

---

## 15. Quick Reference Card

```
DISPATCH:   node ix/exec.js <verb> [arg]
HEARTBEAT:  node ix/exec.js heartbeat
REPORT:     node ix/exec.js report
SLACK:      node ix/exec.js slack "search asolaria"
LINEAR:     node ix/exec.js linear "issue ASO-15"
PHONE:      node ix/exec.js phone.adb "shell getprop ro.build.version.release"
FIRMWARE:   node ix/exec.js firmware.read "region descriptor"
SOVEREIGN:  node ix/exec.js sovereign

GATE CHAIN: hookwall -> gnn -> shannon -> execute -> postExec
RISK:       0-2 auto | 3-4 operator+ | 5-6 trusted+ | 7-8 super_admin+ | 9 owner
COMPRESS:   12:1 (numbers) -> 300:1 (schemas) -> inf:1 (context=index)
SURFACES:   16 dispatch targets (ix, slack, linear, abacus, gemini, cursor,
            warp, swarm, symphony, linear, augment, claude, codex, phone, mqtt, notebook)
LANES:      helm | vector | rook | forge | falcon
PIPELINE:   pre-dev -> dev -> staging -> prod
DIALECTS:   IX (sovereign) | LX (colony) | FA (device) | RO (mac) | AM (win)
BROKER:     port 1883 ONLY. Never 18886. ONE per machine.
```

---

*This specification supersedes all prior language definitions. It is the single source of truth for the IX executable language system. Constitutional basis: IX-060, IX-483, IX-484, IX-490, IX-493, IX-506, IX-512.*
