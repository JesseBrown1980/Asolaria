// IX registry | PID: asolaria | Profile: asolaria
// Exports all IX modules as a single registry
module.exports = {
  // nouns (GET state)
  health:      require('./nouns/health'),
  sovereignty: require('./nouns/sovereignty'),
  nerve:       require('./nouns/nerve'),
  falcon:      require('./nouns/falcon'),
  firmware:    require('./nouns/firmware'),
  // verbs (POST actions)
  dispatch:          require('./verbs/dispatch'),
  observe:           require('./verbs/observe'),
  sync:              require('./verbs/sync'),
  'firmware.read':   require('./verbs/firmware-read'),
  'firmware.write':  require('./verbs/firmware-write'),
  'me.neutralize':   require('./verbs/me-neutralize'),
  // MCP surfaces (IX-506)
  'slack':           require('./verbs/mcp-slack'),
  'linear':          require('./verbs/mcp-linear'),
  'web':             require('./verbs/web'),
  // Phone ADB surface (IX-506)
  'phone.adb':       require('./verbs/phone-adb'),
  // Madness Interactive surfaces (IX-510)
  'swarmdesk':       require('./verbs/swarmdesk'),
  'omnispindle':     require('./verbs/omnispindle'),
  'antigravity':     require('./verbs/antigravity'),
  // Shannon security scanner (IX-513)
  'shannon':         require('./verbs/shannon'),
  // chains
  heartbeat:         require('./chains/heartbeat'),
  report:            require('./chains/report'),
  'security-sweep':  require('./chains/security-sweep'),
  'mistake-learn':   require('./chains/mistake-learn'),
  'skill-extract':   require('./chains/skill-extract'),
  fabricate:         require('./chains/fabricate'),
  review:            require('./chains/review'),
  link:              require('./chains/link'),
  // gates
  sovereign:         require('./gates/sovereign')
};
