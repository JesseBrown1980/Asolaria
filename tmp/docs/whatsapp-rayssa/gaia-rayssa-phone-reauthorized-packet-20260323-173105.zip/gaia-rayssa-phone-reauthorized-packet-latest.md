# Gaia Rayssa Phone Reauthorized Packet

Generated: 2026-03-23 America/Sao_Paulo
Scope: Rayssa host only

## Current accepted proof

- `adb devices -l` now shows both the USB serial and the wireless endpoint as `device`
- USB serial: `RQCX907KFTK`
- Wireless endpoint: `192.168.15.47:5555`
- USB reverse is present: `UsbFfs tcp:4781 tcp:4781`
- `GET /api/mobile/bootstrap` is healthy and advertises `viewer=liris`
- `GET /api/mobile/session?channel=usb` returns `200` with the bootstrap token
- `GET /api/mobile/control/status?channel=usb` returns `200` with the bootstrap token
- Fresh phone tunnel smoke passes

## Exact probe output

### ADB devices

```text
List of devices attached
RQCX907KFTK            device product:r12sxxx model:SM_S721B device:r12s transport_id:52
192.168.15.47:5555     device product:r12sxxx model:SM_S721B device:r12s transport_id:8
```

### USB reverse proof

```text
UsbFfs tcp:4781 tcp:4781
```

### Bootstrap/session/control proof

- `BOOTSTRAP_OK=True`
- `VIEWER=liris`
- `/api/mobile/session?channel=usb` with token: `STATUS=200`
- `/api/mobile/control/status?channel=usb` with token: `STATUS=200`

### Fresh smoke summary

- `ok: true`
- `effectiveChannel: usb`
- `authorizedCount: 2`
- `usbAuthorizedCount: 1`
- `selectedDevice: RQCX907KFTK`
- `reversePresent: true`
- `reportPath: C:\Users\rayss\Asolaria\reports\phone-tunnel-smoke-20260323-173105.md`

## Use rule

- Treat the Rayssa-host USB phone lane as re-authorized and healthy again.
- Default label remains `liris/kuromi`, not `falcon`.
- This packet is host-scoped recovery proof only; it does not change the current compute boundary.
