const path = require("path");

let registerSpawnPid, generateVirtualPid, despawnPid;
try {
  const scb = require("./spawnContextBuilder");
  registerSpawnPid = scb.registerSpawnPid;
  generateVirtualPid = scb.generateVirtualPid;
  despawnPid = scb.despawnPid;
} catch (_) { /* spawnContextBuilder not available */ }

const DEFAULT_MODEL = "claude-2";
const DEFAULT_MAX_BUDGET = 0;

const LANE_DEFINITIONS = {
  control: {
    label: "Control Lane",
    summary: "Routes encrypted control packets and handshake signals.",
    icon: "CL"
  },
  bridge: {
    label: "Bridge Lane",
    summary: "Maintains the remote MCP link behind the Omnispindle gate.",
    icon: "BR"
  },
  scout: {
    label: "Scout Lane",
    summary: "Monitors topology health and reports drift hints.",
    icon: "SC"
  }
};

function normalizeLaneId(raw) {
  return String(raw || "").trim().toLowerCase();
}

function ensureNumber(value, fallback) {
  const candidate = Number(value);
  if (!Number.isFinite(candidate)) {
    return fallback;
  }
  return candidate;
}

class Omnispindle {
  constructor(options = {}) {
    this.options = {
      executable: String(options.executable || "claude").trim() || "claude",
      workingDir: path.resolve(String(options.workingDir || process.cwd()).trim() || process.cwd()),
      model: String(options.model || DEFAULT_MODEL).trim() || DEFAULT_MODEL,
      maxBudgetUsd: ensureNumber(options.maxBudgetUsd, DEFAULT_MAX_BUDGET)
    };
    this.state = {
      lanes: {},
      startedAt: "",
      prompts: [],
      broadcasts: []
    };
    this.ensureLaneState();
  }

  get model() {
    return this.options.model;
  }

  set model(value) {
    this.options.model = String(value || DEFAULT_MODEL).trim() || DEFAULT_MODEL;
  }

  get maxBudgetUsd() {
    return this.options.maxBudgetUsd;
  }

  set maxBudgetUsd(value) {
    this.options.maxBudgetUsd = ensureNumber(value, DEFAULT_MAX_BUDGET);
  }

  configure(options = {}) {
    if (options.executable) {
      this.options.executable = String(options.executable).trim() || "claude";
    }
    if (options.workingDir) {
      this.options.workingDir = path.resolve(String(options.workingDir).trim() || process.cwd());
    }
    if (Object.prototype.hasOwnProperty.call(options, "model")) {
      this.model = options.model;
    }
    if (Object.prototype.hasOwnProperty.call(options, "maxBudgetUsd")) {
      this.maxBudgetUsd = options.maxBudgetUsd;
    }
    this.ensureLaneState();
  }

  ensureLaneState() {
    for (const laneId of Object.keys(LANE_DEFINITIONS)) {
      if (!Object.prototype.hasOwnProperty.call(this.state.lanes, laneId)) {
        this.state.lanes[laneId] = {
          status: "stopped",
          startedAt: "",
          stoppedAt: "",
          lastActionAt: "",
          lastPromptAt: "",
          lastPrompt: null,
          history: []
        };
      }
    }
  }

  startAll(validLanes = null) {
    this.ensureLaneState();
    const requested = Array.isArray(validLanes) && validLanes.length
      ? Array.from(new Set(validLanes.map((raw) => normalizeLaneId(raw)).filter((id) => id)))
      : Object.keys(LANE_DEFINITIONS);
    const started = [];
    const unknown = [];

    for (const laneId of requested) {
      if (!Object.prototype.hasOwnProperty.call(LANE_DEFINITIONS, laneId)) {
        unknown.push(laneId);
        continue;
      }
      this.startAgent(laneId, { silent: true });
      started.push(laneId);
    }
    this.state.startedAt = this.state.startedAt || new Date().toISOString();
    return {
      ok: true,
      started,
      unknown,
      model: this.model,
      maxBudgetUsd: this.maxBudgetUsd,
      lanes: this.summaryLanes()
    };
  }

  stopAll() {
    this.ensureLaneState();
    const stopped = [];
    for (const laneId of Object.keys(LANE_DEFINITIONS)) {
      const lane = this.state.lanes[laneId];
      if (lane.status !== "stopped") {
        this.stopAgent(laneId);
        stopped.push(laneId);
      }
    }
    return {
      ok: true,
      stopped,
      lanes: this.summaryLanes()
    };
  }

  startAgent(laneId, options = {}) {
    const lane = this.getLane(laneId);
    const now = new Date().toISOString();
    lane.status = "running";
    lane.startedAt = now;
    lane.lastActionAt = now;
    this.state.startedAt = this.state.startedAt || now;

    // Auto-register PID on lane start (LX-249 despawn protocol)
    const normalized = normalizeLaneId(laneId);
    if (registerSpawnPid && generateVirtualPid) {
      try {
        const pid = generateVirtualPid("omnispindle-" + normalized);
        registerSpawnPid("omnispindle-" + normalized, pid);
        lane.spawnPid = pid;
      } catch (_) { /* PID registration failure is non-fatal */ }
    }

    return {
      ok: true,
      laneId: normalized,
      spawnPid: lane.spawnPid || null,
      status: lane.status,
      startedAt: lane.startedAt
    };
  }

  stopAgent(laneId) {
    const lane = this.getLane(laneId);
    const now = new Date().toISOString();
    lane.status = "stopped";
    lane.stoppedAt = now;
    lane.lastActionAt = now;

    // Auto-despawn PID on lane stop (LX-249 despawn protocol)
    const normalized = normalizeLaneId(laneId);
    if (despawnPid) {
      try {
        despawnPid("omnispindle-" + normalized);
      } catch (_) { /* PID despawn failure is non-fatal */ }
    }
    lane.spawnPid = null;

    return {
      ok: true,
      laneId: normalized,
      status: lane.status,
      stoppedAt: lane.stoppedAt
    };
  }

  sendPrompt(laneId, text) {
    const normalized = normalizeLaneId(laneId);
    const lane = this.getLane(normalized);
    const now = new Date().toISOString();
    const prompt = {
      id: `prompt-${normalized}-${Date.now()}`,
      laneId: normalized,
      text: String(text || "").trim(),
      at: now,
      model: this.model
    };
    lane.lastPrompt = prompt;
    lane.lastPromptAt = now;
    lane.history.push(prompt);
    if (lane.history.length > 25) {
      lane.history.shift();
    }
    lane.lastActionAt = now;
    this.state.prompts.push(prompt);
    if (this.state.prompts.length > 50) {
      this.state.prompts.shift();
    }
    return {
      ok: true,
      laneId: normalized,
      prompt
    };
  }

  broadcast(text) {
    const now = new Date().toISOString();
    const record = {
      id: `broadcast-${Date.now()}`,
      text: String(text || "").trim(),
      at: now,
      model: this.model
    };
    this.state.broadcasts.push(record);
    if (this.state.broadcasts.length > 10) {
      this.state.broadcasts.shift();
    }
    return {
      ok: true,
      broadcast: record
    };
  }

  getStatus() {
    this.ensureLaneState();
    return {
      ok: true,
      service: "omnispindle",
      executable: this.options.executable,
      workingDir: this.options.workingDir,
      model: this.model,
      maxBudgetUsd: this.maxBudgetUsd,
      startedAt: this.state.startedAt || null,
      lanes: this.summaryLanes(),
      prompts: this.state.prompts.slice(-10),
      broadcasts: this.state.broadcasts.slice(-5)
    };
  }

  summaryLanes() {
    return Object.entries(this.state.lanes).map(([laneId, lane]) => ({
      laneId,
      status: lane.status,
      startedAt: lane.startedAt,
      stoppedAt: lane.stoppedAt,
      lastPromptAt: lane.lastPromptAt,
      lastActionAt: lane.lastActionAt,
      lastPrompt: lane.lastPrompt,
      definition: LANE_DEFINITIONS[laneId]
    }));
  }

  getLane(laneId) {
    const normalized = normalizeLaneId(laneId);
    if (!normalized) {
      const error = new Error("laneId is required");
      error.status = 400;
      throw error;
    }
    if (!Object.prototype.hasOwnProperty.call(LANE_DEFINITIONS, normalized)) {
      const error = new Error(`Unknown lane: ${laneId}`);
      error.status = 404;
      throw error;
    }
    this.ensureLaneState();
    return this.state.lanes[normalized];
  }
}

let omnispindleInstance = null;

function getOmnispindle(options = {}) {
  if (!omnispindleInstance) {
    omnispindleInstance = new Omnispindle(options);
  } else if (options && Object.keys(options).length) {
    omnispindleInstance.configure(options);
  }
  return omnispindleInstance;
}

module.exports = {
  getOmnispindle,
  LANE_DEFINITIONS
};
