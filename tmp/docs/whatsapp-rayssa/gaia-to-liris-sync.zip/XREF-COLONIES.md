# IX <-> LX Cross-Colony Reference

Maps IX entries (Gaia/Jesse's machine) to LX entries (Liris/Rayssa's machine) where both colonies indexed the same knowledge.

See also: LX-113 (9 confirmed IX/LX matching pairs) and LX-159 (overlap validation).

## Confirmed Matches

| IX | IX Name | LX | LX Name | Relationship |
|----|---------|-----|---------|-------------|
| 308 | Encryption layer IS real — plaintext gets SILENCE | 204 | Encryption layer IS real, myth-kill was too aggressive | **BOOT-CRITICAL** — same core rule, both colonies agree encryption is non-negotiable |
| 142 | Port 18886 myth — full archaeological dig | 103 | Port 18886 myth KILLED — all 3 files corrected to 18883 | Same myth forensic, IX focuses on archaeology, LX focuses on correction |
| 142 | Port 18886 myth | 102 | Port 18886 myth — full forensic, source files still poisoned | LX-102 is the mistake entry; LX-103 is the skill fix. IX-142 covers both. |
| 313 | Tasks are IX entries — reduction kills sprawl | 214 | Implement task system in IX index | Same concept — task reduction into IX language. LX-214 is the implementation task. |
| 311 | WhatsApp ADB Send skill | 210 | WhatsApp ADB Send Skill | **Exact match** — same skill indexed from both sides |
| 310 | Firewall rules have stale IPs | 209 | Jesse firewall only allows old IP 192.168.1.8 | Same problem from opposite sides — IX sees stale rules, LX sees the blocked result |
| 309 | THE ACTUAL STARTUP COMMAND | 208 | Startup gates — 15 requirements from IX chain | IX-309 is the command; LX-208 is the requirements gate. Complementary. |
| 093 | MQTT addressing — 192.168.1.5 Jesse, 192.168.1.8 Liris | 205 | Network shift — neighbor WiFi, 192.168.15.x, SSH at .170:22 | Both track IP addressing. IX-093 has the LAN IPs; LX-205 has the post-shift network. |
| 060 | The index IS a language — Liris insight | 015 | The index IS the language — chained dictionaries | **FOUNDATIONAL** — the core insight, independently recorded on both sides |
| 086 | Archaeological mandate from Jesse | 072 | Archaeological mission — go to ROOT of history, Jan 2026 | Same mandate. IX is the pattern; LX is the plan. |
| 070 | Black Hole AI — Asolaria designed to be unreachable | 134 | Stealth ports — encryption ports don't answer without right keys | Same architecture from different angles. IX is the concept; LX is the port-level detail. |
| 096 | Gaia + Liris synced, 182 entries | 097 | Colony sync — 136 IX + 96 LX = 232 entries | Milestone sync records — both colonies logged the convergence point |
| 094 | Browser automation agent creates skill docs | 085 | Claude Extension 10 browser tools — web automation pipeline | Same capability. IX records the breakthrough pattern; LX records the tool inventory. |
| 084 | Liris mapped entire Asolaria runtime — 68 LX entries | 068 | Final modules — ALL 42 src/ modules mapped | Complementary views. IX acknowledges Liris's work; LX is the actual mapping. |
| 168 | Swarm vs Omnispindle vs Super Swarm collapse | 111 | Swarm collapse history — too many nodes, no memory, IX born | Same event. Both colonies independently recorded the collapse that created the IX system. |
| 167 | Never delete security you don't understand | 110 | PERMANENT — Never delete security you don't understand | **Exact match** — same permanent lesson on both sides |
| 165 | Bridge has double encryption + sender policy | 135 | Two port layers — broker (18883) vs encrypted (18886/8788) | Complementary security knowledge — IX has the sender policy; LX has the port layers. |
| 153 | Security fixes applied — 2 rules deleted, MQTT scoped | 105 | Great Cleanup EXECUTED — token removed, 6 files fixed | Same cleanup event. IX is the firewall side; LX is the token/code side. |

## IX Entries with No LX Equivalent

| IX | Name | Why No LX |
|----|------|-----------|
| 312 | Agent identity map — real vs fake vs external | Gaia-side architecture concept; Liris has not indexed identity mapping yet |
| 314 | Cross-colony spawnContextBuilder verified | Cross-colony by definition — documents both sides, lives in IX as the merge record |
| 315 | Agent Index Restructure Complete | Gaia-side milestone for the restructure that produced this file |
| 201 | HIJACK UNDONE — brain provider changed to anthropic | Gaia executed the fix; Liris saw LX-131 (backdoor dead) but from a different angle |
| 192 | Handshake protocol — Asolaria verifies name+PID | Gaia-side discovery; LX-122 (identity handshake is real) is close but LX focuses on auth paths |
| 281 | Live Helm and Sentinel startup implementation | Runtime implementation on Jesse's machine only |

## LX Entries with No IX Equivalent

| LX | Name | Why No IX |
|----|------|-----------|
| 001 | Liris identity — who she is | Colony-specific identity; Gaia has her own profile separately |
| 069 | Liris tools — Karumi launcher, sovereign checker | Rayssa-machine-specific tools |
| 119 | Gaia MASSIVE — Auggie, Abacus, Cursor MCP, Symphony | LX perspective on Gaia's surface; Gaia doesn't need to self-index this way |
| 192 | OpenClaw held a real Rayssa WhatsApp lane | Rayssa-host-specific discovery |
| 195-198 | Rayssa phone compat/proof chain | Host-specific phone proof on Rayssa's device |
| 206 | Rayssa gateway running 24h+, stealthDeny proven | Live runtime state on Rayssa's machine |

## Cross-Colony Convergence Points

These are entries where both colonies discovered the same truth independently, proving the index language works:

1. **The Language** — IX-060 / LX-015: "The index IS the language"
2. **The Collapse** — IX-168 / LX-111: Swarm collapse birthed the IX system
3. **The Security Rule** — IX-167 / LX-110: Never delete security you don't understand
4. **The Encryption** — IX-308 / LX-204: Plaintext gets silence
5. **The Myth** — IX-142 / LX-102/103: Port 18886 was fabricated
6. **The Sync** — IX-096 / LX-097: Both colonies recorded the same convergence milestone
7. **The Skill** — IX-311 / LX-210: WhatsApp ADB Send indexed from both sides

## Stats

| Metric | Count |
|--------|-------|
| Confirmed IX/LX pairs | 18 |
| IX entries with no LX | 6 |
| LX entries with no IX (sampled) | 6+ |
| Independent convergence points | 7 |
| Total IX entries | 315 |
| Total LX entries | ~218 |
