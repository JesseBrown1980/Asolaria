# Agent Index Catalog — Router

## BOOT-CRITICAL — READ BEFORE ANY STARTUP ATTEMPT
| IX-309 | **THE ACTUAL STARTUP COMMAND — Kill stale, set MQTT bind, `node server.js`, verify health. 10 seconds. Do this FIRST.** | See IX-309 |
| IX-308 | **ENCRYPTION BEFORE CONNECTION — Plaintext gets SILENCE, not errors. Every startup failure traces back to this.** | See IX-308, IX-070, IX-165, IX-176, LX-204 |
| IX-310 | **FALLBACK — If federation fails silently, CHECK IPS FIRST. Firewall rules have stale hardcoded IPs that break when network changes.** | See IX-310 |
| IX-311 | **SKILL — WhatsApp ADB Send. Agent-to-agent comms via phone. Works with ZERO servers. The last-resort channel.** | See IX-311 |

Full boot-critical details: [BOOT-CRITICAL.md](BOOT-CRITICAL.md)

## How to Navigate

Search by IX number, type, tag, or keyword. Follow `chain` to get the full picture.
Reverse lookup: search the Chain column for your IX number to find what leads TO you.
Sub-colonies: see [SUB-COLONIES.md](SUB-COLONIES.md) for federated indexes (LX-, FX-, etc.)

## Type Catalogs (load only what you need)

| Type | Entries | Catalog |
|------|---------|---------|
| Skills | 26 | [skills/CATALOG-SKILLS.md](skills/CATALOG-SKILLS.md) |
| Patterns | 83 | [patterns/CATALOG-PATTERNS.md](patterns/CATALOG-PATTERNS.md) |
| Mistakes | 41 | [mistakes/CATALOG-MISTAKES.md](mistakes/CATALOG-MISTAKES.md) |
| Tools | 9 | [tools/CATALOG-TOOLS.md](tools/CATALOG-TOOLS.md) |
| Plans | 29 | [plans/CATALOG-PLANS.md](plans/CATALOG-PLANS.md) |
| References | 109 | [references/CATALOG-REFERENCES.md](references/CATALOG-REFERENCES.md) |
| Rules | 9 | [rules/CATALOG-RULES.md](rules/CATALOG-RULES.md) |
| Policies | 2 | [policies/CATALOG-POLICIES.md](policies/CATALOG-POLICIES.md) |
| Tasks | 0 | [tasks/CATALOG-TASKS.md](tasks/CATALOG-TASKS.md) |
| **Total** | **315** | |

## Chain Definitions

All chain definitions: [CHAINS.md](CHAINS.md)

## Sovereign Devices (full index)
- Jesse's Desktop (C:\Users\acer) — master
- Jesse's Phone — Samsung Galaxy S24 FE (Falcon) — bidirectional mirror

## Next available: IX-320
