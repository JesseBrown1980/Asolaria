# Tasks Catalog

0 entries. Active task board for the colony. Each task is a compressed IX entry.

## Task Frontmatter Schema

```yaml
ix: IX-NNN
name: Short task title
type: task
status: open | active | blocked | done
assignee: helm | sentinel | gaia | liris | falcon | rook | forge | jesse
priority: critical | high | normal | low
tags: [relevant, tags]
chain: [IX-refs this task depends on or relates to]
blockedBy: IX-NNN (if status=blocked)
agents: [who can work on this]
```

## Rules

1. **One line per task in this catalog.** The essay goes in the IX file body.
2. **Status is frontmatter, not prose.** `status: done` not "completed after ingesting..."
3. **Tasks that are done get moved to the done section** below the active table.
4. **External surfaces (NotebookLM, Linear, phone notes) are MIRRORS, not sources.**
   The IX entry is canonical. Everything else syncs FROM here.
5. **Compress.** If your task description is longer than 10 lines, you're writing a report, not a task. Put the report in `reports/` and link it.

## Active Tasks

| IX | Name | Status | Assignee | Priority | Blocked By |
|----|------|--------|----------|----------|------------|

## Done Tasks

| IX | Name | Completed | Assignee |
|----|------|-----------|----------|
