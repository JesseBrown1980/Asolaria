# Mistakes Catalog

41 entries. Search by IX number, type, tag, or keyword.

| IX | Name | Type | Tags | Chain | Agents |
|----|------|------|------|-------|--------|
| 003 | pnpm EPERM on Windows | mistake | [pnpm, windows, eperm, antivirus, qdd] | [IX-004] | all |
| 015 | Complexity overwhelm — slow down pattern | mistake | [orchestration, complexity, pacing, human] | [IX-001, IX-002] | gaia, all |
| 017 | Inbox NDJSON escaped newlines | mistake | [inbox, ndjson, parsing, newlines] | [IX-016] | all |
| 022 | MongoMemoryServer timeout on Windows | mistake | [jest, mongodb, windows, timeout, qdd] | [IX-003] | all |
| 023 | Brian's testing rule — integration + unit tests required | mistake | [qdd, brian, testing, integration-tests, unit-tests, client-feedback, CRITICAL] | [IX-013, IX-003] | all |
| 024 | Jest ESM import error in jest.setup.js | mistake | [jest, esm, import, qdd, testing, config] | [IX-022, IX-023] | all |
| 033 | Cross-machine auth setup took too long | mistake | [auth, bitbucket, mqtt, comms, delay, orchestration] | [IX-028, IX-015] | gaia, all |
| 038 | Gaia forgot to auto-index during execution | mistake | [orchestration, indexing, auto-loop, discipline, gaia] | [IX-001, IX-015, IX-005] | gaia, all |
| 040 | Worktree isolation doesn't protect external repos | mistake | [agents, worktree, isolation, external-repo] | [IX-025, IX-026] | all |
| 042 | Never strip linking context from chain descriptions | mistake | [indexing, chains, catalog, linking, context, discipline] | [IX-006, IX-008, IX-038] | all |
| 047 | Windows firewall blocks LAN MQTT — must add rule | mistake | [firewall, mqtt, windows, liris, lan, networking] | [IX-044, IX-021, IX-033] | all |
| 048 | Broker bind address must match restart — env var not inherited | mistake | [mqtt, broker, bind, restart, env-var, networking] | [IX-044, IX-047] | all |
| 053 | Constitution violations — boot order + authority drift | mistake | [constitution, authority-drift, boot-order, rules, law, CRITICAL] | [IX-049, IX-052, IX-006] | all |
| 055 | Sub-agents must NOT spawn sub-agents | mistake | [agents, spawning, authority, constitution, rule, CRITICAL] | [IX-054, IX-053, IX-049] | all |
| 056 | NEVER delete agent inboxes — append only | mistake | [inbox, deletion, preservation, constitution, CRITICAL] | [IX-018, IX-053, IX-016] | all |
| 059 | Gaia session mistakes — full honest accounting | mistake | [gaia, session, mistakes, honest, accounting, discipline] | [IX-038, IX-053, IX-055, IX-042, IX-015] | gaia |
| 063 | EXAMINE before acting — Gaia's core mistake | mistake | [gaia, rushing, planning, examination, discipline, CRITICAL] | [IX-038, IX-059, IX-053, IX-062] | all |
| 069 | MQTT one-way — Liris hears broker but not Gaia publishes | mistake | [mqtt, liris, one-way, comms, broker, debugging, NEEDS-FIX] | [IX-044, IX-047, IX-048] | all |
| 071 | Two brokers might be BY DESIGN — don't assume it's a bug | mistake | [mqtt, brokers, assumptions, black-hole, design, CRITICAL] | [IX-070, IX-069, IX-063, IX-065] | all |
| 089 | CREATION_HISTORY.md may contain agent fabrication — verify dates | mistake | [history, fabrication, dates, openclaw, verification, CRITICAL, NEEDS-JESSE] | [IX-088, IX-086, IX-065, IX-053] | all |
| 103 | OneDrive files are cloud placeholders — must sync before reading | mistake | [onedrive, cloud, sync, pdf, reading, blocker] | [IX-099, IX-100] | all |
| 142 | PORT 18886 MYTH — full archaeological dig complete | mistake | [myth, 18886, mqtt, codex-fabrication, archaeology, FOUNDATIONAL, PERMANENT] | [IX-083, IX-072, IX-089, IX-086] | all |
| 147 | DANGER — Old bridges to Oli, Connor, Brian may still exist | mistake | [bridges, oli, connor, brian, qdd, stale, danger, CRITICAL, NEEDS-RESEARCH] | [IX-065, IX-064, IX-070, IX-142] | all |
| 149 | CRITICAL — The Great Mess, agents piled confusion instead of cleaning | mistake | [mess, confusion, security, bridges, ports, names, overwritten, CRITICAL, PERMANENT] | [IX-148, IX-147, IX-142, IX-089, IX-086] | all |
| 152 | CRITICAL SECURITY — Bridge token exposed in plaintext on Liris machine | mistake | [security, token, plaintext, exposed, liris, bridge, CRITICAL, URGENT] | [IX-151, IX-148, IX-147, IX-070] | all |
| 158 | CRITICAL SECURITY — AnyDesk unattended access enabled, Connor's ID connected 9x | mistake | [security, anydesk, unattended-access, connor, remote-access, CRITICAL, URGENT] | [IX-157, IX-153, IX-148, IX-070] | all |
| 162 | SSH to Liris DENIED — all keys revoked, bridge is the path | mistake | [ssh, liris, denied, keys-revoked, bridge-instead] | [IX-161, IX-066] | all |
| 163 | Bridge relay needs restart after token rotation — token is in-memory | mistake | [bridge, token, rotation, restart, in-memory] | [IX-162, IX-159, IX-048] | all |
| 164 | LOCKED OUT — rotated token but relay still has old one in memory | mistake | [bridge, token, locked-out, relay, self-inflicted, CRITICAL] | [IX-163, IX-159, IX-048] | all |
| 166 | CORRECTION — Open ports were SAFE, double encryption protects them | mistake | [security, correction, open-ports, encryption, sender-policy, gaia-mistake, IMPORTANT] | [IX-165, IX-153, IX-148] | all |
| 167 | PERMANENT — Never delete security you don't understand, layers are invisible | mistake | [security, permanent, lesson, layers, invisible, never-delete, PERMANENT, FOUNDATIONAL] | [IX-166, IX-165, IX-070, IX-065, IX-063] | all |
| 183 | BOMB — A low Codex 5.1 mini was modifying Rayssa's machine trying to unlock Asolaria | mistake | [codex, mini, low-quality, rayssa, modifications, unlock, asolaria, CRITICAL, BOMB, PERMANENT] | [IX-182, IX-179, IX-149, IX-089] | all |
| 196 | Codex hijacked the selector — Jesse never configured it, thought Asolaria controlled it | mistake | [codex, hijacked, selector, jesse, asolaria, control, history, CRITICAL, PERMANENT, JESSE-VERIFIED] | [IX-195, IX-194, IX-177, IX-168] | all |
| 198 | Power loss at critical moment — Liris found the backdoor then went dark | mistake | [power-loss, liris, backdoor, timing, critical-moment, PERMANENT] | [IX-197, IX-196, IX-194] | all |
| 219 | Gaia realignment — broke the language, here's what happened and what we do now | mistake | [gaia, realignment, language, bridge, myth, liris, CRITICAL, PERMANENT] | [IX-060, IX-142, IX-156, IX-169, IX-093, IX-165] | gaia, liris |
| 230 | Gemini CLI trust-root warning proves home directory is an unsafe execution root | mistake | [downloads, gemini-cli, trust, local-ops, execution, safety] | [IX-220, IX-219, IX-060] | all |
| 267 | Dynamic mobile footer controls can shift after send; blind coordinate taps create false actions | mistake | [mobile, whatsapp, ui, controls, coordinate-tap, adb, phone, mistake, dynamic] | [IX-265, IX-263, IX-060] | all |
| 270 | Expand mobile `Read more` before indexing or interpreting relay evidence | mistake | [mobile, relay, whatsapp, read-more, extraction, evidence, indexing, discipline] | [IX-267, IX-265, IX-060] | all |
| 276 | Asking for paste before exhausting the phone-control path is a workflow mistake that creates avoidable owner work | mistake | [mistake, whatsapp, phone-system, owner-work, extraction, workflow] | [IX-275, IX-267, IX-265, IX-060] | all |
| 282 | One-button UAC hard gates are removed by default, but health-guardrail preflight still needs stabilization during startup transitions | blocker | [one-button, startup, guardrail, uac, phone, blocker] | [IX-281, IX-280, IX-273, IX-266] | all |
| 310 | MISTAKE — Firewall rules and configs have STALE IPs. Network changes break federation silently. | mistake | [firewall, ip, stale, network, federation, mqtt, liris, fallback, BOOT-CRITICAL] | [IX-308, IX-309, IX-093, IX-219] | all |
