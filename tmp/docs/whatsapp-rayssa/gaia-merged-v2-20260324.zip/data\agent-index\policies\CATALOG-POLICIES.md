# Policies Catalog

2 entries. Search by IX number, type, tag, or keyword.

| IX | Name | Type | Tags | Chain | Agents |
|----|------|------|------|-------|--------|
| 265 | Startup back-talk with Liris must remain owner-observable unless Jesse explicitly orders a hidden lane | policy | [startup, liris, relay, observability, authority, jesse, owner, communication] | [IX-263, IX-244, IX-060] | all |
| 266 | Constitution changes are Jesse-gated and QDD completion outranks speculative expansion | policy | [constitution, authority, qdd, priority, survival, scope, jesse] | [IX-265, IX-253, IX-060] | all |
