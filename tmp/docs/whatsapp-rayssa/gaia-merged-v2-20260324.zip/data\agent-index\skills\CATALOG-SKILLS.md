# Skills Catalog

26 entries. Search by IX number, type, tag, or keyword.

| IX | Name | Type | Tags | Chain | Agents | PID | Device Binding |
|----|------|------|------|-------|--------|-----|----------------|
| 004 | Corepack auto-resolves pnpm per project | skill | [pnpm, corepack, version-management, qdd] | [IX-003] | all | — | — |
| 008 | Reverse lookup system | skill | [indexing, reverse-lookup, bidirectional, discovery] | [IX-006, IX-007] | all | — | — |
| 011 | Phone bidirectional index — Falcon bridge | skill | [phone, falcon, bidirectional, samsung, galaxy-ai, core-concept] | [IX-009, IX-006] | gaia, falcon | — | — |
| 014 | WhatsApp as agent comms channel | skill | [whatsapp, comms, liris, falcon, phone, integration] | [IX-009, IX-011] | gaia, falcon | — | — |
| 019 | Codex agents available — gpt-5.4 xhigh | skill | [codex, openai, agents, rook, forge, falcon, spawning] | [IX-012, IX-009] | all | — | — |
| 020 | Claude Dispatch — native phone bridge | skill | [dispatch, phone, claude, bidirectional, desktop-phone] | [IX-011, IX-009, IX-014] | gaia, falcon | — | — |
| 028 | Gaia can read local git config directly | skill | [git, remote, local-access, self-service, ability] | [IX-001, IX-016] | gaia, dasein | — | — |
| 029 | EZ Protect unit tests — COMPLETE | skill | [qdd, testing, unit-tests, ez-protect, brian] | [IX-027, IX-023, IX-026] | gaia | — | — |
| 030 | EZ Protect integration tests — COMPLETE | skill | [qdd, testing, integration-tests, ez-protect, brian] | [IX-027, IX-023, IX-026] | gaia | — | — |
| 031 | Bitbucket access granted to Liris | skill | [bitbucket, qdd, liris, rayssa, access, repo] | [IX-028, IX-013, IX-009] | gaia, liris | — | — |
| 034 | Dan's advice — gh CLI + private remotes | skill | [git, github, gh-cli, dan, remotes, agents, tooling] | [IX-028, IX-016] | all | — | — |
| 039 | Jest auth error message pattern | skill | [jest, testing, auth, regex, qdd] | [IX-024, IX-023] | all | — | — |
| 041 | Parallel agent dispatch — split by type not count | skill | [agents, parallel, testing, dispatch, orchestration] | [IX-001, IX-025, IX-026] | gaia, all | — | — |
| 043 | Jest mock hoisting — use closures not direct refs | skill | [jest, mocking, hoisting, closures, testing, qdd] | [IX-039, IX-023, IX-041] | all | — | — |
| 072 | Port 18886 is the LAN port — Constitution says so | skill | [mqtt, port, lan, 18886, constitution, networking] | [IX-071, IX-070, IX-044] | all | — | — |
| 080 | Admin terminal API — ensure, stop, prompt endpoints | skill | [admin-terminal, sidecar, api, helm, sentinel, startup, FOUNDATIONAL] | [IX-064, IX-074, IX-070, IX-068] | all | — | — |
| 081 | Admin terminal API — exact request formats | skill | [admin-terminal, api, ensure, prompt, stop, helm, sentinel, FOUNDATIONAL] | [IX-080, IX-070, IX-064] | all | — | — |
| 082 | Gaia's correct method to reach Helm — API not CLI | skill | [gaia, helm, api, correct-method, tiny-hole, FOUNDATIONAL] | [IX-081, IX-080, IX-070, IX-055] | gaia | — | — |
| 093 | MQTT addressing — 192.168.1.5 is Jesse (was .3, changed 2026-03-21), 192.168.1.8 is Liris | skill | [mqtt, addressing, ip, liris, jesse, networking] | [IX-069, IX-044, IX-009] | all | — | — |
| 100 | SKILL — RSS feeds bypass browser requirement for blogs | skill | [rss, wordpress, blog, reading, bypass, liris-discovery, tool] | [IX-094, IX-095, IX-092] | all | — | — |
| 140 | SKILL — Install Poppler for native PDF reading | skill | [pdf, poppler, winget, install, reading, liris-discovery] | [IX-103, IX-100] | all | — | — |
| 144 | Myth killed — 18886 references corrected in source files | skill | [myth, 18886, corrected, source-files, archaeology] | [IX-142, IX-083, IX-086] | all | — | — |
| 145 | SKILL — How to restart Asolaria with MQTT LAN access | skill | [restart, mqtt, lan, bridge, asolaria, one-button, FOUNDATIONAL] | [IX-142, IX-144, IX-083, IX-074, IX-068] | all | — | — |
| 153 | Security fixes applied — 2 wide-open rules deleted, MQTT scoped | skill | [security, firewall, cleanup, applied, verified] | [IX-152, IX-151, IX-148] | all | — | — |
| 201 | HIJACK UNDONE — brainPrimaryProvider changed from gemini-api to anthropic | skill | [brain, provider, changed, anthropic, claude, hijack-undone, resurrection, PERMANENT] | [IX-200, IX-199, IX-196, IX-195] | all | — | — |
| 311 | SKILL — WhatsApp ADB Send. Agent-to-agent comms via phone. Works with zero servers. | skill | [whatsapp, adb, phone, comms, gaia, liris, falcon, heartbeat, BOOT-CRITICAL, FOUNDATIONAL] | [IX-309, IX-310, IX-014, IX-011, IX-020] | gaia, liris, falcon | — | — |
