# Rules Catalog

10 entries. Search by IX number, type, tag, or keyword.

| IX | Name | Type | Tags | Chain | Agents |
|----|------|------|------|-------|--------|
| 050 | Jesse's directive — efficient not fancy, learn from Dan | feedback | [jesse, directive, efficiency, dan, madness-interactive, absorb, core-concept] | [IX-046, IX-035, IX-006] | all |
| 274 | Helm dying near context exhaustion means startup must refresh Helm and keep memory in indexed packets, not stale terminal context | rule | [helm, context-window, memory, packets, admin-terminal, startup, anti-drift] | [IX-273, IX-268, IX-265, IX-060] | all |
| 275 | Live WhatsApp relay extraction should use the existing phone system first; owner paste is fallback only | rule | [whatsapp, phone-system, extraction, adb, ui-dump, mirror, owner-visible, fallback] | [IX-267, IX-270, IX-265, IX-268] | all |
| 277 | Minimal Helm startup packet should contain only current runtime truth, active blockers, next executable step, and hard boundaries | rule | [helm, startup, minimal-packet, context, runtime-truth, blockers, boundaries] | [IX-274, IX-273, IX-268, IX-265] | all |
| 279 | Helm and Sentinel must boot from the minimal startup packet and IX chain instead of archaeology-heavy file lists | rule | [helm, sentinel, startup, index-language, compression, qdd] | [IX-278, IX-277, IX-274, IX-273, IX-268] | all |
| 291 | Mixed-scope Rayssa archaeology and cloud-helper lanes stay out of Helm startup memory | rule | [helm, sentinel, startup, rayssa, archaeology, openclaw, claude, cloud-helper, host-scope] | [IX-287, IX-280, IX-279, IX-268] | all |
| 292 | Notebook export absence is a coverage limit, not host-truth proof | rule | [notebooklm, startup, helm, evidence, coverage, host-truth, rayssa, omnispindle] | [IX-291, IX-280, IX-279, IX-268] | all |
| 308 | BOOT-CRITICAL — Encryption layer IS real. Plaintext connections get SILENCE. Every startup failure traces back to this. | rule | [boot, encryption, stealth, silence, plaintext, identity-handshake, ABSOLUTE, FOUNDATIONAL, PERMANENT, BOOT-CRITICAL] | [IX-070, IX-165, IX-176, IX-178, IX-181, IX-142] | all |
| 309 | BOOT-CRITICAL — THE ACTUAL STARTUP COMMAND. Do this FIRST. Stop reading index for hours. | rule | [boot, startup, command, ABSOLUTE, FOUNDATIONAL, PERMANENT, BOOT-CRITICAL] | [IX-308, IX-145, IX-074, IX-080, IX-181] | all |
| 321 | SELF-INDEXING RULE — agents must index discoveries before despawn, system feeds itself | rule | [self-indexing, despawn, discovery, automation, meta-rule, FOUNDATIONAL, PERMANENT] | [IX-052, IX-054, IX-060, IX-313, IX-320, LX-249] | all |
