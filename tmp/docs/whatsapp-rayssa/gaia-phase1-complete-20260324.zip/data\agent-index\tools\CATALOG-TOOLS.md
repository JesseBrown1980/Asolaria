# Tools Catalog

16 entries. Search by IX number, type, tag, or keyword.

| IX | Name | Type | Tags | Chain | Agents |
|----|------|------|------|-------|--------|
| 016 | inbox-send.js — agent messaging tool | tool | [inbox, messaging, agents, comms, cli] | [IX-012, IX-009] | all |
| 021 | MQTT bridge to Liris exists | tool | [mqtt, liris, rayssa, bridge, comms] | [IX-016, IX-009, IX-010] | gaia, helm |
| 032 | Chrome extension bridge — Claude Code on work browser | tool | [chrome, claude-code, extension, browser, cross-account] | [IX-014, IX-009, IX-020] | gaia, all |
| 044 | MQTT broker live on 0.0.0.0:18883 | tool | [mqtt, broker, comms, liris, colony-wide, persistent] | [IX-021, IX-009, IX-037] | all |
| 095 | Medium.com browser automation — 10 tools mapped | tool | [medium, browser, automation, tools, dom, accessibility-tree] | [IX-094, IX-078, IX-032] | all |
| 240 | Recent-download-analysis Gemini skill/tool now exists locally with first and deep pass modes | tool | [downloads, gemini, skill, tool, multimodal, video, image, synthesis] | [IX-220, IX-006, IX-219] | all |
| 242 | Indexed memory retrieval now reaches IX documents through workspace knowledge | tool | [agent-index, workspace-knowledge, retrieval, ix-language, api, semantic, memory] | [IX-238, IX-240, IX-006] | all |
| 247 | Liris startup report validator exists locally and gates the next branch choice | tool | [liris, validator, startup-report, powershell, intake, readiness] | [IX-246, IX-244, IX-242] | all |
| 259 | Colony-memory contracts are now wired into runtime retrieval surfaces and prompt context | tool | [colony-memory, runtime, retrieval, workspace-knowledge, semantic, prompt-context, transport-epoch, schema] | [IX-257, IX-258, IX-242] | all |
| 318 | Execution infrastructure — sandbox, runners, sidecars, workers, GNN pipeline | tool | [sandbox, runner, sidecar, worker, gnn, omnispindle, execution, FOUNDATIONAL] | [IX-316, IX-312, IX-054, IX-168] | all |
| 329 | TOOL — Meeting recorder (FFmpeg NVENC/QSV/AMF hardware accelerated) | tool | [meeting, recording, ffmpeg, nvenc, qsv, video, audio, mkv] | [IX-328, IX-317, IX-320] | falcon, helm, rook |
| 330 | TOOL — Sandbox manager (Docker isolated execution for untrusted code) | tool | [sandbox, docker, execution, isolation, security, python, node] | [IX-318, IX-320] | rook, forge, helm |
| 331 | TOOL — Phone developer options (23 toggles, sweep, capture states) | tool | [phone, developer-options, adb, toggles, wifi-logging, animation, gpu] | [IX-320, IX-319, IX-316] | falcon, rook |
| 332 | TOOL — Phone mirror connector (screenshot, tap, swipe, type, WhatsApp) | tool | [phone, mirror, adb, screenshot, tap, swipe, whatsapp, control] | [IX-331, IX-311, IX-320] | falcon |
| 333 | TOOL — External brain connector (7-provider LLM fallback chain) | tool | [brain, llm, anthropic, openai, gemini, vertex, cursor, antigravity, fallback] | [IX-320, IX-318] | vector, helm |
| 334 | TOOL — Worker router (4-worker dispatch: codex, claude, abacus, symphony) | tool | [worker, router, dispatch, codex, claude, abacus, symphony, task] | [IX-333, IX-318, IX-320] | helm, rook |
