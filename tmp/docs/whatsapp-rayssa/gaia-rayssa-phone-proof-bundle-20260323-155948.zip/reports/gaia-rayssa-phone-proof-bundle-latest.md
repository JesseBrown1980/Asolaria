# Rayssa Host Fresh Phone Proof Bundle

Generated: 2026-03-23 15:59:50 -03:00
Scope: Rayssa host only
Naming: default phone-side label on Rayssa host is liris/kuromi, not falcon

## Consistency Verdict

- consistent: true
- bootstrap viewer: liris
- selected USB serial for reverse proof: RQCX907KFTK
- smoke ok: True
- adb authorized count: 2
- adb reverse present: True

## 1. GET /api/mobile/bootstrap

- timestamp: 2026-03-23 15:59:48 -03:00
- status: 200
- output:
```json
{
  "ok": true,
  "compatListener": true,
  "compatSurface": "proxy_4781",
  "token": "<redacted-token>",
  "tokenHint": "**********************************************************01d7d1",
  "viewer": "liris",
  "urls": {
    "local": "http://127.0.0.1:4781/mobile-console.html?token=<redacted-token>&viewer=liris&channel=usb",
    "remote": "http://127.0.0.1:4781/mobile-console.html?token=<redacted-token>&viewer=liris&channel=usb",
    "localConsole": "http://127.0.0.1:4781/mobile-console.html?token=<redacted-token>&viewer=liris&channel=usb",
    "remoteConsole": "http://127.0.0.1:4781/mobile-console.html?token=<redacted-token>&viewer=liris&channel=usb",
    "localApprovals": "http://127.0.0.1:4781/mobile-approvals.html?token=<redacted-token>&viewer=liris&channel=usb",
    "remoteApprovals": "http://127.0.0.1:4781/mobile-approvals.html?token=<redacted-token>&viewer=liris&channel=usb",
    "local_console": "http://127.0.0.1:4781/mobile-console.html?token=<redacted-token>&viewer=liris&channel=usb",
    "remote_console": "http://127.0.0.1:4781/mobile-console.html?token=<redacted-token>&viewer=liris&channel=usb",
    "local_approvals": "http://127.0.0.1:4781/mobile-approvals.html?token=<redacted-token>&viewer=liris&channel=usb",
    "remote_approvals": "http://127.0.0.1:4781/mobile-approvals.html?token=<redacted-token>&viewer=liris&channel=usb"
  },
  "connection": {
    "remoteBaseUrl": "http://127.0.0.1:4781",
    "preference": [
      "usb",
      "private_internet"
    ],
    "available": [
      "usb",
      "private_internet"
    ],
    "allowPublicInternet": false,
    "publicInternetPrivate": false,
    "remoteAuthRequired": true,
    "requireEncryptedRemote": true,
    "stealthDeny": true
  }
}
```

## 2. GET /api/mobile/session?channel=usb

- timestamp: 2026-03-23 15:59:48 -03:00
- status: 200
- token: <redacted-token>
- output:
```json
{
  "ok": true,
  "compatListener": true,
  "compatSurface": "proxy_4781",
  "viewer": "liris",
  "sessionId": "proxy_4781:liris:usb",
  "pendingCount": 0,
  "approvals": {
    "mode": "smart",
    "preference": "balanced"
  },
  "guardian": {
    "mode": "compat_local",
    "source": "proxy_4781"
  },
  "connectionRouting": {
    "preferred": [
      "usb",
      "private_internet"
    ],
    "detectedAvailable": [
      "usb",
      "private_internet"
    ],
    "filteredAvailable": [
      "usb",
      "private_internet"
    ],
    "removedChannels": [],
    "removedDetails": [],
    "selected": {
      "channel": "usb",
      "reason": "Requested channel accepted: usb.",
      "fallbackUsed": false
    },
    "remoteBaseUrl": "http://127.0.0.1:4781",
    "policy": {
      "remoteBaseUrl": "http://127.0.0.1:4781",
      "allowPublicInternet": false,
      "publicInternetPrivate": false,
      "remoteAuthRequired": true,
      "requireEncryptedRemote": true,
      "stealthDeny": true
    }
  },
  "control": {
    "armed": false,
    "remainingMs": 0,
    "expiresAt": "",
    "by": "",
    "lastAction": "",
    "lastError": "",
    "updatedAt": "2026-03-23T18:24:03.434Z"
  },
  "push": {
    "enabled": false,
    "subscriptions": 0,
    "reason": "push_not_implemented_on_proxy_4781"
  },
  "workOrgs": {
    "activeOrg": "",
    "activeOrgLabel": "",
    "profiles": {}
  }
}
```

## 3. GET /api/mobile/control/status?channel=usb

- timestamp: 2026-03-23 15:59:48 -03:00
- status: 200
- token: <redacted-token>
- output:
```json
{
  "ok": true,
  "compatListener": true,
  "compatSurface": "proxy_4781",
  "control": {
    "armed": false,
    "remainingMs": 0,
    "expiresAt": "",
    "by": "",
    "lastAction": "",
    "lastError": "",
    "updatedAt": "2026-03-23T18:24:03.434Z"
  },
  "authority": {
    "superMasterControlAllowed": true,
    "reason": "",
    "actorId": "proxy_4781",
    "role": "compat_local"
  },
  "phoneBridgeKeeper": {
    "running": true,
    "pid": 4612,
    "pidFile": "C:\\Users\\rayss\\Asolaria\\logs\\phone-link-keeper.pid",
    "latestLogPath": "C:\\Users\\rayss\\Asolaria\\logs\\phone-link-keeper-20260323-153235.log",
    "latestLogUpdatedAt": "2026-03-23T18:58:11.179Z",
    "latestLogStaleSeconds": 98,
    "latestLogTail": "[2026-03-23 15:47:07] health=True; authorized=2; unauthorized=0; usb_serials=RQCX907KFTK; reverse_ok=True; reverse_changed=True; reverse_detail=reverse_set serial=RQCX907KFTK; wireless_endpoint=192.168.15.47:5555 | [2026-03-23 15:47:27] health=True; authorized=2; unauthorized=0; usb_serials=RQCX907KFTK; reverse_ok=True; reverse_changed=False; reverse_detail=reverse_present serial=RQCX907KFTK; wireless_endpoint=192.168.15.47:5555 | [2026-03-23 15:47:47] health=True; authorized=2; unauthorized=0; usb_serials=RQCX907KFTK; reverse_ok=True; reverse_changed=False; reverse_detail=reverse_present serial=RQCX907KFTK; wireless_endpoint=192.168.15.47:5555; wireless_discovery=discovered_existing | [2026-03-23 15:48:07] health=True; authorized=2; unauthorized=0; usb_serials=RQCX907KFTK; reverse_ok=True; reverse_changed=False; reverse_detail=reverse_present serial=RQCX907KFTK; wireless_endpoint=192.168.15.47:5555 | [2026-03-23 15:52:49] health=True; authorized=2; unauthorized=0; usb_serials=RQCX907KFTK; reverse_ok=True; reverse_changed=False; reverse_detail=reverse_present serial=RQCX907KFTK; wireless_endpoint=192.168.15.47:5555; wireless_discovery=discovered_existing | [2026-03-23 15:53:09] health=True; authorized=2; unauthorized=0; usb_serials=RQCX907KFTK; reverse_ok=True; reverse_changed=False; reverse_detail=reverse_present serial=RQCX907KFTK; wireless_endpoint=192.168.15.47:5555 | [2026-03-23 15:57:51] health=True; authorized=2; unauthorized=0; usb_serials=RQCX907KFTK; reverse_ok=True; reverse_changed=False; reverse_detail=reverse_present serial=RQCX907KFTK; wireless_endpoint=192.168.15.47:5555; wireless_discovery=discovered_existing | [2026-03-23 15:58:11] health=True; authorized=2; unauthorized=0; usb_serials=RQCX907KFTK; reverse_ok=True; reverse_changed=False; reverse_detail=reverse_present serial=RQCX907KFTK; wireless_endpoint=192.168.15.47:5555"
  },
  "phoneTunnelMonitor": {
    "running": true,
    "pid": 17496,
    "pidFile": "C:\\Users\\rayss\\Asolaria\\logs\\phone-tunnel-smoke-monitor.pid",
    "latestLogPath": "C:\\Users\\rayss\\Asolaria\\logs\\phone-tunnel-smoke-monitor-20260323-153233.log",
    "latestLogUpdatedAt": "2026-03-23T18:47:44.721Z",
    "latestLogStaleSeconds": 724,
    "latestLogTail": "﻿[2026-03-23 15:32:36] monitor_start port=4781 interval_s=300 max_hours=0 raw_probe=False route_failover=True tailnet_proxy_port=4782 | [2026-03-23 15:32:36] monitor_policy phone_only=True | [2026-03-23 15:32:36] url_sync_ok=False; changed=False; url=; error=public_sync_disabled_phone_only | [2026-03-23 15:32:36] route_ok=True; mode=keep_current_healthy; switched=False; selected=http://127.0.0.1:4781; selected_channel=usb; current=http://127.0.0.1:4781; private_ok=False; public_ok=False; current_ok=True; tailscale=tailscale_not_found; update_reason=not_required; phone_only=True | [2026-03-23 15:32:39] ok=True; reason=ok; remote=http://127.0.0.1:4781; session=True; control=True; keeper_running=True; reverse=False; ping=False; raw_status=0; route_mode=keep_current_healthy; route_base=http://127.0.0.1:4781; route_switched=False; report=C:\\Users\\rayss\\Asolaria\\reports\\phone-tunnel-smoke-latest.md | [2026-03-23 15:47:44] ok=True; reason=ok; remote=http://127.0.0.1:4781; session=True; control=True; keeper_running=True; reverse=True; ping=True; raw_status=0; route_mode=keep_current_healthy; route_base=http://127.0.0.1:4781; route_switched=False; report=C:\\Users\\rayss\\Asolaria\\reports\\phone-tunnel-smoke-latest.md",
    "latestReportPath": "C:\\Users\\rayss\\Asolaria\\reports\\phone-tunnel-smoke-latest.md",
    "latestReportUpdatedAt": "2026-03-23T18:57:52.904Z",
    "latestReportStaleSeconds": 116,
    "latestReportPass": true
  }
}
```

## 4. adb devices -l

- timestamp: 2026-03-23 15:59:49 -03:00
- adb path: C:\Users\rayss\AppData\Local\Microsoft\WinGet\Packages\Google.PlatformTools_Microsoft.Winget.Source_8wekyb3d8bbwe\platform-tools\adb.exe
- output:
```text
List of devices attached
RQCX907KFTK            device product:r12sxxx model:SM_S721B device:r12s transport_id:7
192.168.15.47:5555     device product:r12sxxx model:SM_S721B device:r12s transport_id:8
```

## 5. adb -s <usb-serial> reverse --list

- timestamp: 2026-03-23 15:59:49 -03:00
- selected USB serial: RQCX907KFTK
- output:
```text
UsbFfs tcp:4781 tcp:4781
```

## 6. Fresh Phone Tunnel Smoke

- timestamp: 2026-03-23 15:59:49 -03:00
- report path: C:\Users\rayss\Asolaria\reports\phone-tunnel-smoke-20260323-155948.md
- smoke result:
```json
{
  "ok": true,
  "checkedAt": "2026-03-23T15:59:50.6026179-03:00",
  "baseUrl": "http://127.0.0.1:4781",
  "localPort": 4781,
  "tokenHint": "************************************************************d7d1",
  "local": {
    "healthOk": true,
    "healthError": "",
    "bootstrapOk": true,
    "bootstrapError": ""
  },
  "remote": {
    "baseUrl": "http://127.0.0.1:4781",
    "requestedChannel": "auto",
    "effectiveChannel": "usb",
    "healthOk": true,
    "healthError": "",
    "consoleStatusCode": 200,
    "sessionOk": true,
    "sessionError": "",
    "sessionChannel": "usb",
    "controlOk": true,
    "controlError": "",
    "controlPlaneHealthy": true,
    "keeperRunning": true,
    "keeperPid": 4612,
    "keeperStaleSeconds": 99
  },
  "adb": {
    "skipped": false,
    "path": "C:\\Users\\rayss\\AppData\\Local\\Microsoft\\WinGet\\Packages\\Google.PlatformTools_Microsoft.Winget.Source_8wekyb3d8bbwe\\platform-tools\\adb.exe",
    "authorizedCount": 2,
    "usbAuthorizedCount": 1,
    "hostVisiblePhoneCount": 0,
    "hostVisiblePhones": [],
    "authorizedDevices": [
      "RQCX907KFTK",
      "192.168.15.47:5555"
    ],
    "usbAuthorizedDevices": [
      "RQCX907KFTK"
    ],
    "selectedDevice": "RQCX907KFTK",
    "reversePresent": true
  },
  "phonePing": {
    "attempted": true,
    "ok": true,
    "host": "127.0.0.1",
    "error": ""
  },
  "rawProbe": {
    "attempted": false,
    "statusCode": 0,
    "statusLine": "",
    "error": ""
  },
  "notes": [],
  "reportPath": "C:\\Users\\rayss\\Asolaria\\reports\\phone-tunnel-smoke-20260323-155948.md"
}
```

## Included Fresh Smoke File

- latest aligned path: C:\Users\rayss\Asolaria\reports\phone-tunnel-smoke-latest.md

