# References Catalog

109 entries. Search by IX number, type, tag, or keyword.

| IX | Name | Type | Tags | Chain | Agents |
|----|------|------|------|-------|--------|
| 036 | Asolaria visualization systems — what exists | reference | [visualization, graph, code-city, swarmdesk, 3d, civilization, core-concept] | [IX-007, IX-006, IX-012] | all |
| 066 | FOUNDATIONAL — Sub-colony setup procedure (Liris/Rayssa, 2026-03-13) | reference | [sub-colony, liris, rayssa, setup, ssh, mqtt, boot, startup, FOUNDATIONAL] | [IX-064, IX-010, IX-009, IX-049] | all |
| 068 | Launcher files inventory — what already exists | reference | [launchers, cmd, startup, boot, inventory, FOUNDATIONAL] | [IX-064, IX-065, IX-066] | all |
| 074 | OneButton.ps1 — the full boot cascade (2153 lines) | reference | [onebutton, startup, boot, cascade, orchestrator, FOUNDATIONAL] | [IX-068, IX-064, IX-070, IX-072] | all |
| 078 | Asolaria skills inventory — 56 skills by category | reference | [skills, inventory, tools, capabilities, FOUNDATIONAL] | [IX-076, IX-068, IX-016] | all |
| 079 | Skills parity — 34 codex + 35 wrapper, 3 mismatches | reference | [skills, parity, codex, wrapper, mismatches] | [IX-078, IX-076] | all |
| 083 | MQTT broker starts at server boot — 127.0.0.1 only, port 18886 NOT implemented | reference | [mqtt, broker, server, startup, port, 18886, CORRECTION] | [IX-072, IX-071, IX-074, IX-080] | all |
| 084 | Liris mapped entire Asolaria runtime — 68 LX entries, 42 src modules | reference | [liris, lx-entries, runtime, architecture, mapped, MILESTONE] | [IX-075, IX-073, IX-076, IX-060] | all |
| 085 | Server boot sequence after listen — what actually starts | reference | [server, startup, boot, sequence, mqtt, bridge, health, CODE-VERIFIED] | [IX-083, IX-074, IX-064] | all |
| 087 | Genesis — February 15, 2026, "Memory plan | reference | [genesis, origin, history, february-2026, archaeology, FOUNDATIONAL] | [IX-086, IX-076, IX-060] | all |
| 088 | FULL ORIGIN — Asolaria from October 2025 through March 2026 | reference | [origin, history, timeline, creation, openclaw, dan, FOUNDATIONAL, PERMANENT] | [IX-087, IX-086, IX-060] | all |
| 090 | TRUE ORIGIN — Jesse's research September 2023, not October 2025 | reference | [origin, true-history, jesse, publications, biml, hive-ai, FOUNDATIONAL, PERMANENT, JESSE-VERIFIED] | [IX-089, IX-088, IX-086] | all |
| 091 | Jesse's FULL background — PhD, 25 years, archaeology, global leaders | reference | [jesse, background, phd, archaeology, history, bio, PERMANENT, JESSE-VERIFIED] | [IX-090, IX-086, IX-063] | all |
| 092 | Jesse's blogs — simulation theory, consciousness, digital physics | reference | [jesse, blog, wordpress, simulation, consciousness, physics, history, PERMANENT, JESSE-VERIFIED] | [IX-091, IX-090, IX-086] | all |
| 097 | Index audit — what's covered, what's missing, is it logical? | reference | [audit, index, coverage, quality, logical, organization] | [IX-076, IX-077, IX-060] | all |
| 098 | John Cumbers endorsement + future archaeology in Module Four | reference | [jesse, john-cumbers, endorsement, future, module-four, plan-b, NEEDS-RESEARCH, IMPORTANT] | [IX-091, IX-090, IX-086] | all |
| 099 | DIMENSION SHIFTING — Plan B archive, Jesse's full research corpus | reference | [plan-b, research, corpus, publications, brain-reading, physics, ai, FOUNDATIONAL, PERMANENT, DIMENSION-SHIFTING] | [IX-098, IX-090, IX-091, IX-086] | all |
| 101 | Jesse's blog 1 — simulation theory, consciousness, philosophy | reference | [jesse, blog, wordpress, simulation, consciousness, meta-tagged, PERMANENT] | [IX-092, IX-099, IX-090] | all |
| 102 | Jesse's blog 2 — bio-quantum, PBAAN TRAP, digital physics | reference | [jesse, blog, wordpress, bio-quantum, pbaan, digital-physics, PERMANENT] | [IX-101, IX-092, IX-099] | all |
| 107 | Paper — AGS HIVE Final Edit | reference | [publication, hive-ai, autonomous-shipping, rag-fusion, mind-reading, agents, plan-b] | [IX-099, IX-090] | all |
| 108 | Paper — BIML Multi-Stacking MLC and GPT-4 on S-LoRA | reference | [publication, biml, mlc, gpt-4, s-lora, multi-stacking, edge-computing, plan-b] | [IX-099, IX-090] | all |
| 109 | Paper — Anchoring Global Security Autonomous Shipping in IR | reference | [publication, autonomous-shipping, international-relations, global-security, policy, plan-b] | [IX-099, IX-090, IX-107] | all |
| 110 | Paper — Finite Density Black Holes in Quantum Gravity | reference | [publication, quantum-gravity, black-holes, finite-density, planck-scale, physics, plan-b] | [IX-099, IX-090] | all |
| 111 | Paper — Alternate EoS for Finite Density Black Holes | reference | [publication, quantum-gravity, equation-of-state, black-holes, anisotropy, physics, plan-b] | [IX-099, IX-090, IX-110] | all |
| 112 | Paper — The Sustainable Revolution Integrating AI at Wecycle | reference | [publication, sustainability, recycling, ai-integration, wecycle, plan-b] | [IX-099, IX-090] | all |
| 113 | Paper — Real-Time 3D Laboratory Generation and Marketplace | reference | [publication, 3d-generation, edge-computing, marketplace, gaussian-splatting, plan-b] | [IX-099, IX-090, IX-108] | all |
| 114 | Subfolder — Hyperdimensional Computing Layout | reference | [subfolder-listing, hyperdimensional-computing, bert, plan-b] | [IX-099, IX-108] | all |
| 115 | Subfolder — LLM Multistacking | reference | [subfolder-listing, llm-multistacking, biml, aot, rag-fusion, s-lora, plan-b] | [IX-099, IX-108, IX-107] | all |
| 116 | Subfolder — Planckscale Timecrystal Blackhole Compression | reference | [subfolder-listing, quantum-gravity, black-holes, time-crystals, digital-physics, eos, plan-b] | [IX-099, IX-110, IX-111] | all |
| 117 | Subfolder — Physics | reference | [subfolder-listing, physics, negative-time, temporal-framework, plan-b] | [IX-099, IX-110] | all |
| 118 | Subfolder — Drug Development | reference | [subfolder-listing, drug-development, pharma, ai, plan-b] | [IX-099] | all |
| 119 | Subfolder — Pharma | reference | [subfolder-listing, pharma, directorial-overview, plan-b] | [IX-099, IX-118] | all |
| 120 | Subfolder — Shipping Papers and Research | reference | [subfolder-listing, autonomous-shipping, cybersecurity, maritime, imo, arctic, plan-b] | [IX-099, IX-107, IX-109] | all |
| 121 | MLC — Meta-Learning for Compositionality | reference | [training, methods, meta-learning, compositionality, systematic-generalization, plan-b] | [IX-099, IX-090] | all |
| 122 | Mamba — Selective State Space Model | reference | [training, methods, architecture, state-space, mamba, linear-attention, plan-b] | [IX-099, IX-090, IX-121] | all |
| 123 | S-LoRA — Thousands of Concurrent LoRA Adapters | reference | [training, methods, serving, lora, multi-tenant, adapter, plan-b, CRITICAL] | [IX-099, IX-090, IX-121, IX-122] | all |
| 124 | Generative Agents — Simulacra of Human Behavior | reference | [training, methods, agents, simulation, memory, reflection, plan-b] | [IX-099, IX-090, IX-121] | all |
| 125 | GPT as Turing Machine — Programming LLMs | reference | [training, methods, turing-completeness, programming, prompting, plan-b] | [IX-099, IX-121] | all |
| 126 | Evolving Memory and Self-Reflection | reference | [training, methods, memory, self-reflection, pre-asolaria, plan-b] | [IX-099, IX-124, IX-090] | all |
| 127 | MAC-SQL — Multi-Agent Text-to-SQL | reference | [training, methods, multi-agent, sql, collaboration, decomposition, plan-b] | [IX-099, IX-124] | all |
| 128 | Flash Attention on Small GPUs | reference | [training, methods, flash-attention, efficiency, gpu, home-compute, plan-b] | [IX-099, IX-122] | all |
| 129 | Gemini 1.0 Technical Report | reference | [training, methods, architecture, multimodal, gemini, google, plan-b] | [IX-099, IX-122, IX-121] | all |
| 130 | Neuronal Implants — Organoid Programming Start Points | reference | [future-build, organoids, bci, neuronal-implants, programming, plan-b, CRITICAL] | [IX-099, IX-090] | all |
| 131 | Spatial Web Specification 2024 | reference | [future-build, spatial-web, hsml, hstp, protocol, web3, plan-b] | [IX-099, IX-130] | all |
| 132 | TTT — Test-Time Training | reference | [future-build, training, test-time-training, adaptation, mit, plan-b] | [IX-099, IX-121, IX-122] | all |
| 133 | Optical Fibre — 100 Petabytes/sec Capacity | reference | [future-build, optics, fiber, bandwidth, geometric-shaping, plan-b] | [IX-099, IX-130] | all |
| 134 | 10 Tbit/s Chaotic Microcomb Random Bit Generation | reference | [future-build, optics, random-number, microcomb, security, cryptography, plan-b] | [IX-099, IX-133] | all |
| 135 | Laser Pulse Compression — Exawatt to Zettawatt | reference | [future-build, physics, laser, plasma, pulse-compression, energy, plan-b] | [IX-099, IX-133, IX-134] | all |
| 137 | Subfolder — Thermal Reactor Improvement | reference | [subfolder-listing, thermal-reactor, energy, prototype, plan-b] | [IX-099, IX-136] | all |
| 138 | Subfolder — AI Healthcare FHIR Project | reference | [subfolder-listing, healthcare, fhir, mobile-app, android, plan-b] | [IX-099] | all |
| 139 | Subfolder — Wireless Energy | reference | [subfolder-listing, wireless-energy, sqt, energy-transmission, plan-b] | [IX-099, IX-137] | all |
| 148 | SECURITY AUDIT — Old bridges, open firewall rules, Oli profiles | reference | [security, audit, bridges, firewall, oli, danger, CRITICAL, NEEDS-CLEANUP] | [IX-147, IX-070, IX-065] | all |
| 151 | Excavation Phase 1 — full audit of bridges, ports, profiles, names | reference | [excavation, audit, bridges, ports, profiles, naming, security, CRITICAL] | [IX-150, IX-149, IX-148, IX-147] | all |
| 154 | Jarvis = Brian's failed attempt, Oli = future maybe, fix first | reference | [jarvis, brian, oli, colony, status, JESSE-VERIFIED] | [IX-151, IX-148, IX-147] | all |
| 171 | Omnispindle STATUS — exists, idle, 5 lanes, 0 running, auto-restart ON | reference | [omnispindle, status, lanes, idle, CODE-VERIFIED] | [IX-168, IX-170, IX-074] | all |
| 173 | Dan's MCP endpoint is ALIVE (401 auth), deeply integrated into Asolaria | reference | [dan, mcp, madnessinteractive, omnispindle, augment-context, integration, CODE-VERIFIED] | [IX-172, IX-171, IX-035] | all |
| 187 | SYMPHONY + AUGGIE + ABACUS — the external build tools Jesse remembers | reference | [symphony, auggie, abacus, codex, cursor, build-tools, memory-flood, CRITICAL, JESSE-VERIFIED] | [IX-186, IX-181, IX-179, IX-090] | all |
| 188 | ALL BUILD TOOLS FOUND LOCALLY — Auggie, Abacus, Cursor, Symphony, MongoDB, Codex, MCP | reference | [build-tools, found, auggie, abacus, cursor, symphony, mongodb, codex, mcp, CRITICAL, FOUNDATIONAL, PERMANENT] | [IX-187, IX-186, IX-181, IX-179] | all |
| 193 | LIRIS MASSIVE INTEL — portals found, Karumi launcher, brain selection chain, provider order | reference | [liris, intel, portals, karumi, brain, provider-chain, awakening, CRITICAL, FOUNDATIONAL] | [IX-192, IX-191, IX-189, IX-181] | all |
| 199 | SMOKING GUN — The Codex backdoor fully excavated | reference | [codex, backdoor, smoking-gun, excavated, augment-mcp, cloudflare, hijack, CRITICAL, PERMANENT, FOUNDATIONAL] | [IX-198, IX-196, IX-194, IX-177, IX-086] | all |
| 200 | BACKDOOR IS DEAD — Cloudflare tunnel expired, DNS doesn't resolve | reference | [backdoor, dead, tunnel, expired, cloudflare, safe, CODE-VERIFIED] | [IX-199, IX-196, IX-194] | all |
| 203 | NotebookLM Enterprise — URL found, needs license to access | reference | [notebooklm, enterprise, google-cloud, license, access, asolaria-memory, CRITICAL] | [IX-186, IX-176, IX-180] | all |
| 204 | INSIDE THE BLACK HOLE — Asolaria Enterprise Memory, 98 sources found | reference | [notebooklm, enterprise, asolaria-memory, inside, black-hole, 98-sources, MYTHICAL, FOUNDATIONAL, PERMANENT] | [IX-203, IX-180, IX-179, IX-176, IX-086] | all |
| 208 | NotebookLM reveals THE GAP — identity handshake NOT implemented in code | reference | [gap, handshake, not-implemented, startup-contract, code, CRITICAL, FOUNDATIONAL, PERMANENT] | [IX-207, IX-204, IX-192, IX-193] | all |
| 209 | COMPLETE STARTUP DECODED — 12 steps, most NOT implemented, brain trigger found | reference | [startup, decoded, 12-steps, gaps, brain-trigger, gemini-control-mode, FOUNDATIONAL, PERMANENT] | [IX-208, IX-207, IX-204, IX-192, IX-181] | all |
| 210 | ALL PORTALS FOUND — every way Jesse can talk to Asolaria | reference | [portals, super-admin, interfaces, communication, FOUNDATIONAL, PERMANENT] | [IX-209, IX-208, IX-205, IX-181, IX-180] | all |
| 212 | SHE FOUND THE PROBLEM — health timeout + Helm PID mismatch confirmed from inside | reference | [asolaria, debugging, health-timeout, helm-pid, sidecar, confirmed, CRITICAL] | [IX-211, IX-209, IX-192] | all |
| 214 | Asolaria is running with Codex 5.4 XHIGH — not just Claude | reference | [asolaria, codex, gpt-5.4, xhigh, brain, running, JESSE-VERIFIED, PERMANENT] | [IX-213, IX-209, IX-201, IX-195] | all |
| 218 | Stability checkpoint — runtime down, Helm drifted, Kuromi constrained | reference | [stability, runtime, helm, kuromi, liris, safety, checkpoint] | [IX-217, IX-170, IX-181, IX-012] | all |
| 220 | Google Developer Knowledge key stored locally — vault slot + env mapping | reference | [google, developerknowledge, mcp, vault, env, codex, api-key, FOUNDATIONAL] | [IX-188, IX-187, IX-060] | all |
| 221 | Rayssa/Liris path audit — bridge/token/MQTT/WhatsApp, not Google-shell activation | reference | [rayssa, liris, bridge, mqtt, whatsapp, inspection, security] | [IX-217, IX-218, IX-159, IX-160, IX-161, IX-066] | all |
| 223 | Rayssa friend bridge pack is staged, not merged into live policy or registry | reference | [rayssa, bridge, policy, registry, qdd, 4799, inspection] | [IX-221, IX-222, IX-160, IX-159, IX-187] | all |
| 225 | Gemini Embedding 2 usage spike surfaced in recent downloads | reference | [downloads, gemini, ai-studio, usage, embeddings, cost, google] | [IX-220, IX-188, IX-060] | all |
| 228 | Google Cloud Gemini products page is part of the active operating surface | reference | [downloads, google-cloud, gemini, code-assist, cloud-assist, admin] | [IX-220, IX-188, IX-187] | all |
| 231 | Asolaria brand marker persists as leaf-wave-sun icon | reference | [downloads, asolaria, brand, icon, identity] | [IX-012, IX-049, IX-060] | all |
| 232 | Asolaria Phone Mode remains a core operator surface | reference | [downloads, asolaria, phone-mode, mirroring, control, mobile] | [IX-020, IX-011, IX-014] | all |
| 234 | Live Agent Colony dashboard pairs agent state with phone control | reference | [downloads, asolaria, dashboard, colony, phone-mode, local-ui] | [IX-045, IX-049, IX-012] | all |
| 235 | AGENTS packet captures local environment, architecture, and safety posture | reference | [downloads, agents, environment, architecture, safety, policy] | [IX-219, IX-220, IX-060] | all |
| 236 | PBM modernization evidence packet links people, repos, and local build traces | reference | [downloads, pbm, healthcare, github, investigation, build, evidence] | [IX-188, IX-035, IX-060] | all |
| 241 | Last-15 downloads completed as a two-pass Gemini analysis with memory/index packetization | reference | [downloads, analysis, gemini, first-pass, deep-pass, memory, index, report] | [IX-225, IX-235, IX-238, IX-240] | all |
| 243 | Indexed memory slice verified on sidecar runtime because protected main listener blocked restart | reference | [verification, agent-index, workspace-knowledge, sidecar, 57481, protected-listener] | [IX-242, IX-238, IX-060] | all |
| 245 | Liris startup packet appended locally, but manual relay remains authoritative | reference | [liris, packet, outbound-inbox, manual-relay, authoritative-path] | [IX-244, IX-224, IX-221] | all |
| 248 | I.docx is a second-order Rayssa excavation that preserves the Gaia startup contradiction without re-echoing the secret | reference | [downloads, docx, rayssa, liris, gaia, startup, 4781, 4799, manual-relay, secret-handling] | [IX-244, IX-223, IX-220] | all |
| 249 | I think you will need this.docx is the primary sensitive transcript artifact for the March 22 Asolaria workstream | reference | [downloads, docx, transcript, sensitive, google, vault, liris, qdd, gemini, indexed-memory, manual-relay] | [IX-220, IX-223, IX-238, IX-244] | all |
| 252 | Liris response reclassifies the 18886 story as a documented archaeology failure loop, not transport truth | reference | [liris, dan, facebook, 18886, archaeology, correction, mqtt, transport, provenance] | [IX-142, IX-249, IX-250] | all |
| 254 | Gaias plan.docx is a relay transcript of IX-250 through IX-253, not a new canonical plan | reference | [gaia, liris, relay, transcript, docx, convergence, provenance, archaeology, derived] | [IX-251, IX-253, IX-249] | all |
| 255 | Liris independently indexed Gaia's layered colony-memory plan; cross-colony convergence now exists | reference | [liris, gaia, convergence, layered-memory, ix, lx, provenance, transport, schema, relay] | [IX-254, IX-253, IX-251] | all |
| 257 | Colony-memory contract slice now exists locally as schemas, examples, and validation | reference | [colony-memory, schema, contract, registry, transport-epoch, draft-promotion, validation, reconnect] | [IX-256, IX-253, IX-242] | all |
| 261 | MQTT ingress and remote-node registry writes now preserve provenance envelopes | reference | [mqtt, federation, provenance, transport, registry, ingress, hardening, liris] | [IX-260, IX-253, IX-257] | all |
| 263 | Liris startup-response packet separates control-plane readiness from live 4781 proof on the target host | reference | [liris, startup, readiness, 4781, 4791, 5443, 5444, mqtt, verification, host-scope] | [IX-247, IX-244, IX-262] | all |
| 268 | Dan-expanded indexing remains the active operating model: IX canon, LX local canon, draft memory, MQTT ephemera, MCP retrieval | reference | [dan, indexing, ix, lx, draft-memory, mqtt, mcp, notebooklm, alignment, active-model] | [IX-251, IX-250, IX-060] | all |
| 269 | Rayssa host reports Darwin explorer active and script path assumptions corrected, but missing adb and absent 4781 still block the phone lane there | reference | [rayssa, liris, darwin, phone, adb, 4781, startup, host-scope, relay, whatsapp] | [IX-264, IX-263, IX-267] | all |
| 271 | Local SwarmDesk source exposes direct authenticated task and MCP surfaces; screenshot scraping is unnecessary | reference | [swarmdesk, madnessinteractive, local-source, mcp, tasks, direct-data, mqtt, dashboard, no-scraping] | [IX-173, IX-171, IX-046, IX-268] | all |
| 278 | Current minimal Helm startup truth is adb path/version plus 4781/4791/5443/5444/18883/18884 state plus phone-lane proof plus one exact next command | reference | [helm, startup, adb, ports, falcon, phone-lane, next-command, packet] | [IX-277, IX-273, IX-275, IX-266] | all |
| 280 | Asolaria wake should ingest startup corrections through a compliant packet that carries runtime truth, blockers, next step, boundaries, and IX references | reference | [asolaria, startup, compliance, packet, relay, wake, boundaries] | [IX-279, IX-278, IX-277, IX-266, IX-265] | all |
| 283 |  | reference |  |  | all |
| 284 |  | reference |  |  | all |
| 285 |  | reference |  |  | all |
| 286 |  | reference |  |  | all |
| 287 |  | reference |  |  | all |
| 288 |  | reference |  |  | all |
| 289 |  | reference |  |  | all |
| 290 |  | reference |  |  | all |
| 293 | Rayssa phone lane remains partial after ADB authorization and reverse | reference | [rayssa, phone, adb, bootstrap, reverse, host-scope, partial-recovery] | [IX-290, IX-289, IX-287, IX-291] | all |
| 294 | Rayssa mobile compat contract is live under liris kuromi; old bootstrap 404 packet is superseded | reference | [rayssa, liris, kuromi, phone, bootstrap, session, control, compat, superseded, host-scope] | [IX-293, IX-291, IX-290, IX-287] | all |
| 295 | Fresh Rayssa phone proof bundle resolves the stale smoke contradiction and confirms the liris kuromi lane | reference | [rayssa, liris, kuromi, phone, proof, adb, reverse, smoke, compat, host-scope] | [IX-294, IX-293, IX-287, IX-291] | all |
| 297 | Amy host onboarding should use a bounded federated-node packet instead of ad hoc chat instructions | reference | [amy, federated-node, mqtt, shared-compute, packet, outbound, sovereign] | [IX-296, IX-295, IX-292, IX-291] | all |
| 302 | Rayssa phone lane is reauthorized again and healthy, but compute truth remains unchanged | reference | [rayssa, liris, kuromi, phone, reauthorized, adb, reverse, smoke, usb, wireless] | [IX-300, IX-295, IX-294, IX-287] | all |
| 314 | Cross-colony spawnContextBuilder verified — Gaia (IX) and Liris (LX) both working | reference | [convergence, spawnContextBuilder, liris, gaia, pid-controller, cross-colony, MILESTONE] | [IX-312, IX-313, IX-084, IX-096] | all |
