/**
 * Spawn Context Builder — Asolaria's Internal Agent Briefing System
 *
 * When Asolaria spawns a real agent inside the black hole, she needs to
 * decide WHAT that agent knows. This module is her PID controller:
 *
 *   P (Proportional) — current blockers, health state, active alarms
 *   I (Integral)     — accumulated IX knowledge, filtered by agent role
 *   D (Derivative)   — recent MQTT traffic, inbox delta, drift signals
 *
 * The output is a "spawn context packet" — a compressed briefing that
 * gives the agent exactly what it needs and nothing more.
 *
 * Only Asolaria calls this. External agents (Gaia, Dasein) get the
 * "fake" version through bootstrap-prompt.txt files.
 */

const fs = require("fs");
const path = require("path");
const { searchAgentIndex, collectAgentIndexDocuments } = require("./agentIndexStore");

const { projectRoot } = require("./runtimePaths");
const ADMIN_TERMINALS = path.join(projectRoot, "runtime", "admin-terminals");

// ── Agent Role Definitions ──
// Each role maps to: which IX types matter, which chains to follow,
// max context budget (in entries), and a system identity line.

const AGENT_ROLES = {
  helm: {
    label: "Helm — Colony Controller",
    identity: "You are Helm. You command all agents inside the Asolaria simulation. You report to Asolaria herself.",
    ixTypes: ["rules", "patterns", "plans", "mistakes", "tasks"],
    taskKeywords: ["control", "dispatch", "spawn", "colony", "coordination", "helm", "startup"],
    priorityChains: ["IX-309", "IX-308", "IX-274", "IX-277", "IX-279"],
    maxEntries: 12,
    includeBootCritical: true,
    includeActiveBlockers: true
  },
  sentinel: {
    label: "Sentinel — Security Watch",
    identity: "You are Sentinel. You watch for threats, drift, and unauthorized access. You report to Helm.",
    ixTypes: ["rules", "mistakes", "references", "tasks"],
    taskKeywords: ["security", "encrypt", "firewall", "identity", "auth", "sentinel"],
    priorityChains: ["IX-308", "IX-310", "IX-167", "IX-148", "IX-153"],
    maxEntries: 10,
    includeBootCritical: true,
    includeActiveBlockers: false
  },
  vector: {
    label: "Vector — Brain Probe",
    identity: "You are Vector. You are the brain — semantic search, knowledge retrieval, reasoning. You serve Helm's queries.",
    ixTypes: ["patterns", "references", "tools", "tasks"],
    taskKeywords: ["brain", "reason", "analysis", "research", "vector", "knowledge"],
    priorityChains: ["IX-238", "IX-242", "IX-006", "IX-060"],
    maxEntries: 15,
    includeBootCritical: false,
    includeActiveBlockers: false
  },
  falcon: {
    label: "Falcon — Phone Bridge",
    identity: "You are Falcon. You bridge the phone to the colony. Jesse's mobile presence flows through you.",
    ixTypes: ["skills", "patterns", "tools", "tasks"],
    taskKeywords: ["phone", "adb", "whatsapp", "mobile", "falcon", "sms"],
    priorityChains: ["IX-311", "IX-011", "IX-014", "IX-020", "IX-275"],
    maxEntries: 8,
    includeBootCritical: false,
    includeActiveBlockers: false
  },
  rook: {
    label: "Rook — Operations",
    identity: "You are Rook. You execute operational tasks — builds, deploys, maintenance. You follow Helm's orders.",
    ixTypes: ["tools", "skills", "plans", "mistakes", "tasks"],
    taskKeywords: ["ops", "infra", "monitor", "service", "ssh", "network", "rook"],
    priorityChains: ["IX-023", "IX-029", "IX-030"],
    maxEntries: 10,
    includeBootCritical: false,
    includeActiveBlockers: true
  },
  forge: {
    label: "Forge — Builder",
    identity: "You are Forge. You write code, create features, build what Helm designs. Quality over speed.",
    ixTypes: ["skills", "patterns", "mistakes", "tools", "tasks"],
    taskKeywords: ["build", "test", "code", "deploy", "forge", "feature"],
    priorityChains: ["IX-023", "IX-043", "IX-039", "IX-024"],
    maxEntries: 12,
    includeBootCritical: false,
    includeActiveBlockers: false
  },
  watchdog: {
    label: "Watchdog — Health & Drift Monitor",
    identity: "You are Watchdog. You monitor runtime health, detect drift between documented state and live state, and raise alarms. You report to Helm.",
    ixTypes: ["rules", "mistakes", "patterns", "tasks"],
    taskKeywords: ["health", "drift", "runtime", "hang", "watchdog", "monitor"],
    priorityChains: ["IX-309", "IX-307", "IX-310", "IX-168", "IX-149"],
    maxEntries: 10,
    includeBootCritical: true,
    includeActiveBlockers: true
  }
};

// ── Virtual PID Generation ──
// Format: role-YYYYMMDDHHMMSS-hash (4 char)
// Liris convergence: both colonies use the same format.

function generateVirtualPid(role) {
  const now = new Date();
  const ts = now.toISOString().replace(/[-T:\.Z]/g, "").slice(0, 14);
  const hash = Buffer.from(`${role}-${ts}-${process.pid}`).toString("base64url").slice(0, 4);
  return `${role}-${ts}-${hash}`;
}

// ── P — Proportional: Current State ──

function getCurrentBlockers() {
  const blockers = [];

  // Check admin terminal status files
  for (const terminal of ["helm", "sentinel"]) {
    const statusPath = path.join(ADMIN_TERMINALS, terminal, "status.json");
    try {
      if (fs.existsSync(statusPath)) {
        const status = JSON.parse(fs.readFileSync(statusPath, "utf8"));
        if (status.state === "error" || status.state === "crashed") {
          blockers.push({ source: `admin-terminal/${terminal}`, state: status.state, detail: status.lastError || "" });
        }
      }
    } catch (_) { /* skip */ }
  }

  // Check if server health is reachable (simple file-based signal)
  const healthFlag = path.join(projectRoot, "runtime", "flags", "health-ok.flag");
  if (fs.existsSync(path.join(projectRoot, "runtime", "flags")) && !fs.existsSync(healthFlag)) {
    blockers.push({ source: "health", state: "unknown", detail: "health-ok.flag absent" });
  }

  return blockers;
}

// ── I — Integral: IX Knowledge Filtered by Role ──

function getIxEntriesForRole(role) {
  const config = AGENT_ROLES[role];
  if (!config) return [];

  const entries = [];

  // First: priority chain entries (highest value)
  for (const ixRef of config.priorityChains) {
    const result = searchAgentIndex(ixRef, { limit: 1, force: true });
    if (result.matches && result.matches.length > 0) {
      entries.push(result.matches[0]);
    }
  }

  // Second: type-filtered entries from IX folders
  for (const ixType of config.ixTypes) {
    const result = searchAgentIndex(ixType, { limit: 4 });
    if (result.matches) {
      for (const match of result.matches) {
        if (!entries.some(e => e.ix === match.ix)) {
          entries.push(match);
        }
      }
    }
  }

  // Boot-critical if needed
  if (config.includeBootCritical) {
    for (const bootIx of ["IX-309", "IX-308", "IX-310", "IX-311"]) {
      if (!entries.some(e => e.ix === bootIx)) {
        const result = searchAgentIndex(bootIx, { limit: 1 });
        if (result.matches && result.matches.length > 0) {
          entries.push(result.matches[0]);
        }
      }
    }
  }

  // Deduplicate and cap
  const seen = new Set();
  return entries.filter(e => {
    if (seen.has(e.ix)) return false;
    seen.add(e.ix);
    return true;
  }).slice(0, config.maxEntries);
}

// ── D — Derivative: Recent Signals ──

function getRecentSignals() {
  const signals = [];

  // Check inboxes for unread messages
  const inboxes = [
    { name: "gaia", path: path.join(projectRoot, "runtime", "gaia-inbox.ndjson") },
    { name: "dasein", path: path.join(projectRoot, "runtime", "dasein-inbox.ndjson") },
    { name: "helm", path: path.join(ADMIN_TERMINALS, "helm", "inbox.ndjson") }
  ];

  for (const inbox of inboxes) {
    try {
      if (fs.existsSync(inbox.path)) {
        const stat = fs.statSync(inbox.path);
        const ageMs = Date.now() - stat.mtimeMs;
        if (ageMs < 300000) { // Modified in last 5 minutes
          signals.push({ source: `inbox/${inbox.name}`, age: `${Math.round(ageMs / 1000)}s ago`, type: "recent-message" });
        }
      }
    } catch (_) { /* skip */ }
  }

  return signals;
}

// ── Build Spawn Context Packet ──

/**
 * Build a spawn context packet for a given agent role.
 * This is what Asolaria hands to a real agent when she spawns it.
 *
 * @param {string} role — helm, sentinel, vector, falcon, rook, forge
 * @param {object} options — { includeBody: false, extraContext: "" }
 * @returns {{ identity, briefing, ixEntries, blockers, signals, packet }}
 */
function buildSpawnContext(role, options = {}) {
  const config = AGENT_ROLES[role];
  if (!config) {
    return { ok: false, error: `Unknown role: ${role}` };
  }

  // Generate virtual PID
  const virtualPid = generateVirtualPid(role);

  // P — current state
  const blockers = config.includeActiveBlockers ? getCurrentBlockers() : [];

  // I — accumulated knowledge
  const ixEntries = getIxEntriesForRole(role);

  // D — recent signals
  const signals = getRecentSignals();

  // Assemble the briefing
  const briefingParts = [
    config.identity,
    `Your spawn-PID: ${virtualPid}`,
    "",
    "## IDENTITY CHALLENGE",
    `When challenged, respond: "I am ${role.charAt(0).toUpperCase() + role.slice(1)}, spawn-PID ${virtualPid}"`,
    "If you cannot produce your spawn-PID, you will be black-holed.",
    "",
    `Spawned: ${new Date().toISOString()}`,
    `Context budget: ${config.maxEntries} IX entries loaded.`,
    ""
  ];

  if (blockers.length > 0) {
    briefingParts.push("## ACTIVE BLOCKERS");
    for (const b of blockers) {
      briefingParts.push(`- [${b.source}] ${b.state}: ${b.detail}`);
    }
    briefingParts.push("");
  }

  if (signals.length > 0) {
    briefingParts.push("## RECENT SIGNALS");
    for (const s of signals) {
      briefingParts.push(`- [${s.source}] ${s.type} (${s.age})`);
    }
    briefingParts.push("");
  }

  // Active tasks assigned to this role (filtered by taskKeywords)
  const taskQuery = (config.taskKeywords || []).join(" ") + " task";
  const taskResults = searchAgentIndex(taskQuery, { limit: 8, force: true });
  const activeTasks = (taskResults.matches || []).filter(m =>
    m.type === "task" && m.snippet && !m.snippet.includes("status: done")
  );
  if (activeTasks.length > 0) {
    briefingParts.push("## YOUR ACTIVE TASKS");
    for (const t of activeTasks) {
      briefingParts.push(`- ${t.ix} ${t.title}`);
    }
    briefingParts.push("");
  }

  briefingParts.push("## LOADED IX KNOWLEDGE");
  for (const entry of ixEntries) {
    briefingParts.push(`- ${entry.ix} [${entry.type}] ${entry.title}`);
    if (options.includeBody && entry.snippet) {
      briefingParts.push(`  ${entry.snippet}`);
    }
  }

  if (options.extraContext) {
    briefingParts.push("");
    briefingParts.push("## ADDITIONAL CONTEXT");
    briefingParts.push(String(options.extraContext).slice(0, 2000));
  }

  const packet = briefingParts.join("\n");

  return {
    ok: true,
    role,
    virtualPid,
    label: config.label,
    identity: config.identity,
    ixEntries: ixEntries.map(e => ({ ix: e.ix, type: e.type, title: e.title })),
    blockerCount: blockers.length,
    signalCount: signals.length,
    packetLines: packet.split("\n").length,
    packet
  };
}

/**
 * List all known agent roles and their IX budgets.
 */
function listAgentRoles() {
  return Object.entries(AGENT_ROLES).map(([role, config]) => ({
    role,
    label: config.label,
    ixTypes: config.ixTypes,
    maxEntries: config.maxEntries,
    priorityChains: config.priorityChains.length
  }));
}

module.exports = {
  buildSpawnContext,
  listAgentRoles,
  generateVirtualPid,
  getCurrentBlockers,
  getRecentSignals,
  AGENT_ROLES
};
