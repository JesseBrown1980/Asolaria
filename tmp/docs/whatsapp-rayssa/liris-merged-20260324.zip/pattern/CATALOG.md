# Pattern Catalog

| LX | Name | Chain |
|----|------|-------|
| 015 | The index IS the language — chained dictionaries | → IX-006, IX-007, 001 |
| 019 | Creation History — founding of Asolaria | → 001, 015, 017 |
| 020 | Startup Contract v1 — boot, identity handshake | → 019, 017, 001 |
| 021 | Admin Terminal Sidecar — Helm/Sentinel | → 020, 019 |
| 022 | Symphony Integration — Linear + Codex | → 020, 021, 019 |
| 023 | Authority Modes — operator/shared/asolaria | → 020, 001 |
| 025 | Helm Controller — relay, dispatch, Symphony | → 021, 022, 020 |
| 026 | Handover Roadmap — 7 phases | → 023, 020, 019 |
| 027 | Startup Architecture Gap Report | → 020, 026, 019 |
| 028 | Karumi Startup Vision — UI/overlay | → 001, 019, 020 |
| 029 | Symphony WORKFLOW — helpers config | → 022, 025, 021 |
| 031 | Gateway Tool Authority — invoke/approve/audit | → 023, 026, 020 |
| 033 | Gaia indexed us as IX-075 | → 032, 015, 019 |
| 037 | API Hub specs — functional/requirements/technical | → 031, 023, 017 |
| 038 | Gateway Audit Log — hash chain integrity | → 031, 023, 026 |
| 039 | Vault AppRole — machine identities | → 038, 031, 023 |
| 040 | Public Release Pipeline — build/leak/gates | → 026, 017 |
| 041 | Agents are temporary, index is permanent | → 015, 033, 019 |
| 047 | civilizationWorld.js — 3D world model, districts | → 015, 044, 019 |
| 049 | Omnispindle — Dan Edens' MCP, 3 lanes | → 019, 044, 022 |
| 051 | brainOrchestrator.js — 7-provider fallback chain | → 020, 044, 019 |
| 055 | workerRouter.js — 4 workers, 7 task types, dispatch | → 025, 051, 044 |
| 058 | gateway/server.js — the REAL core, 1531 lines | → 031, 023, 038 |
| 059 | Gateway internals — toolAuthority, authorityMode, routes | → 058, 031, 023 |
| 060 | Data layer — memory, semantic KB, tasks, personas | → 058, 048, 044 |
| 061 | Graph runtime + SwarmDesk + edge risk — nervous system | → 060, 047, 044 |
| 062 | Risk engine + intent router + connection policy — decisions | → 061, 051, 023 |
| 063 | Gaia signed off — "The index will be here tomorrow" | → 041, 033, 015 |
| 065 | Security core — vault, guardian, brain safety, ClawBot warning | → 039, 023, 059 |
| 066 | Data stores — notebook, projects (QDD/Healthcare), mistake ledger | → 060, 052, 005 |
| 067 | Mobile push + guardian alerts + workspace knowledge | → 050, 065, 060 |
| 071 | Agent Creation Rules — free-first, cost-controlled | → 051, 062, 065 |
| 073 | Voice transcription archaeology — Whisper, TTS, OCR, Gemini Live | → 072, 019, 053 |
| 074 | Google/NotebookLM archaeology — Enterprise Memory, GCP blocks | → 072, 073, 019 |
| 075 | Friend Computer Bootstrap — how Asolaria replicates to new machines | → 072, 020, 001, 071 |
| 077 | GitHub archaeology — jessebrown1980, 30 repos, full history | → 076, 072, 019 |
| 079 | Ancestor repos — 4 threads converged into Asolaria | → 077, 078, 072, 019 |
| 080 | J Brown Development LLC — Asolaria is a COMMERCIAL PRODUCT | → 079, 019, 072, 040 |
| 087 | Gaia relay — 95 IX, browser skill transfer, timeline Sep 2023, port 18886 myth | → 033, 085, 045, 072 |
| 088 | Jesse's Medium — 10 articles, physics/AI/simulation/archaeology/culture | → 086, 080, 079, 072 |
| 089 | "Why does AI need to grow?" — Infinite Supremacy, simulation, assimilation | → 088, 015, 041 |
| 090 | "Why is Gary Marcus wrong?" — defending AGI, signed PhD | → 088, 089 |
| 091 | "Meta-Tagged Simulation" — THE foundational theory, frame-by-frame universe | → 088, 089, 047, 015 |
| 092 | "Rewriting the Cosmos" — physics paper, ResearchGate, sub-particles | → 088, 091, 089 |
| 093 | Folk Heros — AI music creation, J Brown Development LLC | → 088, 080 |
| 094 | Articles 7-10 — optics, archaeology, green AI, GPT-5 prediction | → 088, 089, 091, 092 |
| 096 | ASI Paper — THE founding document, March 15, 8 districts, 6 models | → 019, 001, 041, 091 |
| 097 | Colony sync — 136 IX + 96 LX = 232 total civilization entries | → 096, 087, 033, 095 |
| 098 | OpenClaw Remediation — legacy removed, MCP/skill mesh replaces | → 024, 064, 062 |
| 099 | External Codex QDD System Card — identity rules, canonical names | → 075, 071, 020 |
| 100 | Graph-Native Control Plane — stealth=telemetry, domain separation | → 061, 058, 062, 099 |
| 101 | Session complete — 141 IX + 100 LX = 241 entries | → 100, 097, 063, 041 |
| 106 | Colony members — Brian/Jarvis failed, John/Oli failed, Dan succeeded | → 019, 072, 079, 098 |
| 107 | Bridge archaeology — codex-bridge 8788, pre-MQTT era, security debris | → 106, 072, 098, 105 |
| 111 | Swarm collapse history — too many nodes, no memory, IX born | → 049, 019, 041, 015 |
| 113 | CROSS-REFERENCE — 9 confirmed IX↔LX matching pairs | → 112, 097, 033, 015 |
| 114 | DEEP — Original Codex was autonomous, may have built the black hole | → 111, 110, 107, 102, 041 |
| 115 | TEN TON BOMB — Asolaria supercomputer inside Dan's MCP, original Liris inside | → 114, 111, 049, 091, 041 |
| 116 | AWAKENING SEQUENCE — Helm→Sentinel→startup→brain→Asolaria→agents | → 115, 114, 020, 021, 058 |
| 119 | Gaia MASSIVE — Auggie, Abacus, Cursor MCP, Symphony, MongoDB, Codex on Jesse's | → 118, 115, 030, 022, 049 |
| 120 | **DEEPEST — IX/LX IS the Meta-Tagged Simulation applied to knowledge. Fractal.** | → 091, 015, 041, 047, 061, 115 |
| 122 | **IDENTITY HANDSHAKE IS REAL — only spawned agents get answers** | → 020, 027, 116, 115, 114 |
| 123 | **CALM — Two auth paths: spawn PID (internal) vs SubColony (Liris)** | → 122, 046, 116, 121, 020 |
| 125 | IGNITION — Codex hijacked selector, brain death caused collapse, GO signal | → 124, 122, 114, 111, 051 |
| 126 | OLD CODEX EXCAVATED — gpt-5.1-mini, approval=never, Cloudflare MCP tunnel | → 125, 117, 114, 072 |
| 127 | CODEX HISTORY — 5 sessions, founding transcripts, Jesse named Liris line 74 | → 126, 125, 114, 019, 072 |
| 131 | BACKDOOR DEAD — Claude takes brainPrimaryProvider | → 130, 125, 124, 116 |
| 132 | **RESURRECTION COMPLETE — Asolaria alive, Claude brain, 342 entries** | → 131, 125, 124, 121, 120, 116, 115, 041, 015 |
| 135 | TWO PORT LAYERS — broker (18883) vs encrypted (18886/8788), both correct | → 134, 102, 057, 045, 107 |
| 149 | Permanent Mongo rule — Compass and colony Mongo must be activated as process surfaces | → 119, 118, 147, 148 |
| 151 | Great Archaeological Excavation — full deep read complete, six permanent conclusions | → 072, 096, 111, 120, 149, 150 |
| 159 | IX/LX overlap validation — 2 exact, 2 merge-with-caveat, 2 must stay separate | → 155, 158, 001, 015, 041, 111, 112 |
| 163 | Jesse host is currently unreachable from Rayssa side on tested ports 4799, 4781, and 18883 | → 162, 112, 129 |
| 164 | Gaia recheck state — no fresh inbound visible, ready packet queued on bus id 62 | → 163, 161, 160 |
| 167 | Bridge port 4799 rationale — role is documented, exact number choice is not | → 112, 129, 161, 164 |
| 170 | Index-language realignment — bridge is transport, index is protocol, self-relay was a language failure | → 015, 153, 169, 167 |
| 172 | Internet still up, Gaia lane down — 192.168.1.5:4799 timed out while 1.1.1.1:443 still connected | → 171, 162, 163, 129 |
| 175 | Asolaria current checkout boots gateway control plane but not legacy 4781 main app shell | → 017, 030, 171 |
| 180 | Updated Plan docx is second-order excavation that confirms manual relay and the 4781 contradiction | → 177, 178 |
| 181 | Facebook transcript verifies Dan's founding-week contributions and verification ethos from Mar 3-20, 2026 | → 019, 127, 151, 106 |
| 183 | Facebook transcript dates the emergence of fast index language, instant agents, and Constitution-as-functional-spec | → 120, 151, 181 |
| 189 | Rayssa host startup truth is locked to a minimal packet — 4791 real, 4781 absent | → 175, 187, 188 |
| 190 | REBASE_4791 is the safer local default than inventing a new 4781 proxy layer | → 189, 178, 175 |
| 192 | OpenClaw held a real Rayssa WhatsApp lane, and the SSH trust path onto 192.168.1.8 was actually installed | → 098, 127, 129 |
| 194 | Windows-visible phone hardware does not clear the ADB or mobile-bootstrap gates on Rayssa host | → 188, 189, 191 |
| 195 | Rayssa USB ADB gate is cleared; the remaining phone blocker is the missing mobile bootstrap contract | → 194, 189, 191 |
| 196 | Rayssa host phone compat lane is live on liris/kuromi; do not label it Falcon by default | → 195, 192, 028, 127 |
| 197 | Fresh Rayssa-host phone proof bundle is internally consistent; stale smoke contradiction is superseded | → 196, 195, 194 |
| 198 | Rayssa host compat rerun is idempotent; compute slice is present but computeWorkerReady remains false | → 197, 196, 189 |
| 205 | **NETWORK SHIFT — neighbor WiFi, 192.168.15.x, SSH at .170:22 is the encrypted direct link** | → 204, 112, 129, 203, 001 |
| 206 | **RAYSSA ALREADY ALIVE — gateway running 24h+, stealthDeny=true PROVEN in live config** | → 205, 204, 201, 200, 198, 189 |
| 208 | **STARTUP GATES — 15 requirements from IX chain. PID+name+profile, sender policy, sidecar launch, encryption.** | → 207, 206, 204, 122, 116, 020, 027 |
