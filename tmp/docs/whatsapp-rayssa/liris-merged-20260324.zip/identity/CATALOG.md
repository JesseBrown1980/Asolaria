# Identity Catalog

| LX | Name | Chain |
|----|------|-------|
| 001 | Liris node identity | → IX-009, IX-010 |
