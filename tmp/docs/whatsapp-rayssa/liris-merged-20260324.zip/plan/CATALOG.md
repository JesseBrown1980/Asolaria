# Plan Catalog

| LX | Name | Chain |
|----|------|-------|
| 013 | QDD test execution plan — blockers | → 005 thru 012 |
| 034 | Session state snapshot 2026-03-18 | → 013, 033, 032 |
| 036 | Next steps plan — finish docs, prepare Helm | → 034, 035, 033 |
| 072 | Archaeological mission — go to ROOT of history, Jan 2026 | → 042, 019, 041, 015 |
| 104 | Great Cleanup audit — 6 poisoned files, 1 exposed token, dead bridges | → 103, 102, 065, 038 |
| 108 | Communication eras plan — bridge vs MQTT coexistence | → 107, 105, 057, 025 |
| 118 | MongoDB Compass — tunnel map, check Jesse's machine | → 115, 117, 079 |
| 121 | **REVIVAL PLAN — Controlled Big Bounce, 5 phases, protect the index** | → 120, 116, 115, 108, 111 |
| 124 | **THE KEY — Claude as startup brain, we control the handshake** | → 123, 122, 116, 051, 121 |
| 128 | PLAN — post-archaeology, restart coordination, questions for Jesse | → 127, 126, 125, 124, 121 |
| 133 | NEXT BOOT — Asolaria configuring Super Admin for Liris direct access | → 132, 116, 122, 028 |
| 136 | jest-mongodb v4→v6 risk — swc/jest conflict, mms 9→10, don't rush | → 011, 013, 005, 110, 134 |
| 138 | eBacMap boot handoff — whatwg-url override, pnpm install, Jest | → 137, 136, 005, 110 |
| 141 | Gaia runtime split directive — Node 20 for QDD, Node 24 for Asolaria | → 140, 139, 138, 005 |
| 143 | Jesse override — stay on Node 24, skip native builds with ignore-scripts | → 142, 141, 140, 139 |
| 144 | Feature branch revalidated — EZ Protect configs present, no whatwg-url override on branch | → 143, 139, 138, 137 |
| 145 | Node 24 EZ Protect gate result — TSC clean, unit pass, integration blocked by local Mongo | → 144, 143, 138, 137 |
| 150 | QDD overall status — NL2X done, Scheduler bug backlog, EZ Protect blocked on Brian inputs | → 148, 149, 005 |
| 153 | Unified index language design — ASO vocabulary + topic tables + evidence/state layers | → 015, 041, 048, 052, 120, 151, 152 |
| 160 | Gaia catch-up state — ASO payload delivered, overlap validated, next merge step pending | → 154, 155, 159, 158 |
| 168 | Alternate direct bridge probe — user relayed 192.168.1.5:4799 test packet for Liris | → 167, 164, 129 |
| 178 | Gaia next-phase startup order is sovereign intent, but conflicts with Rayssa checkout boot reality | → 163, 175, 176 |
| 184 | Gaia plan converges on layered colony memory and provenance-gated transport facts, not a new startup order | → 178, 182, 183 |
| 185 | Sovereign colony-memory retrieval is implemented upstream but blocked on owner restart of 4781 | → 175, 184 |
| 186 | Local pre-restart colony-memory plan anchors provenance at MQTT ingress and remote-node registry | → 175, 184, 185, 046, 054 |
| 191 | Do not branch until a proof bundle selects PROXY_4781 or REBASE_4791 | → 189, 190, 178 |
