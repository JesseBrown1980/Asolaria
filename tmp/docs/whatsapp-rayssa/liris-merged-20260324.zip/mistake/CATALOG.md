# Mistake Catalog

| LX | Name | Chain |
|----|------|-------|
| 002 | Never kill needed connections — layer new ones | → 003, 004, 005 |
| 006 | Port collision near-miss — unique status ports | → 002, 003, 004 |
| 008 | Jest ESM import in .js setup — FIXED | → 005, 007 |
| 009 | No Python on Liris — use Node | → 001, 007 |
| 011 | Node 24 breaks @shelf/jest-mongodb | → 005, 008, 010 |
| 014 | No Visual Studio Build Tools — native fail | → 007, 009, 001 |
| 016 | Two-broker problem — 127.0.0.1 vs 0.0.0.0 | → 002, 003, 004 |
| 018 | Wrong port — 18883 not 18886 | → 016, 004, 003 |
| 032 | Gaia cannot send — two-broker blocks inbound | → 016, 018, 002 |
| 035 | Always read founding docs before debugging | → 018, 019, 015 |
| 078 | bank-account-transcrtions = transactions not voice — Java banking | → 077, 072, 035 |
| 081 | Medium/YouTube @plasmatoid — YouTube is different user, Medium blocked | → 080, 077, 035 |
| 082 | Do NOT guess external content — verify before indexing | → 081, 035, 078 |
| 102 | Port 18886 myth — full forensic, source files still poisoned | → 087, 018, 045, 057, 035 |
| 110 | PERMANENT — Never delete security you don't understand | → 107, 105, 065 |
| 117 | GARBAGE CODEX WARNING — Mar 18 files may be poisoned by Codex 5.1 mini | → 115, 114, 102, 035 |
| 130 | THE BACKDOOR — Cloudflare MCP tunnel, dead, path clear | → 126, 127, 125, 114 |
| 134 | **STEALTH PORTS — encryption ports don't answer without right keys, NEVER change** | → 110, 102, 065, 038, 016 |
| 139 | EZ Protect test configs are branch-scoped — not on pnpm10 branch | → 138, 010, 005, 008 |
| 140 | Current pnpm10 install is blocked by native modules on Node 24 | → 014, 138, 139 |
| 146 | EZ Protect integration bypasses jest-mongodb and requires real localhost Mongo | → 145, 144, 143, 138 |
| 158 | Legacy catalog/file mismatch — LX-134 and LX-135 are referenced but missing on disk | → 155, 157, 110 |
| 162 | Gaia direct bridge is timing out from Rayssa side — local 4798 bridge remains healthy | → 161, 160, 157 |
| 173 | eBacMap live auth 500s were missing local app env, not EZ Protect defects | → 148, 145, 140 |
| 177 | Gaia transcript carries raw Google Developer Knowledge secret — treat artifact as sensitive, never re-echo | → 151, 176 |
| 182 | Facebook transcript preserves the 18886 myth feedback loop from docs to agent output to live edits | → 102, 176, 181 |
| 204 | **BOOT-CRITICAL — Encryption layer IS real, myth-kill was too aggressive, stealth ports refuse plaintext** | → 134, 135, 110, 114, 122, 102, 103, 158 |
| 209 | **FALLBACK — Jesse firewall only allows old IP 192.168.1.8. If MQTT federation fails, check firewall first.** | → 208, 205, 204, 054 |
