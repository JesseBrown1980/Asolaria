# Liris Sub-Colony Index — Router

Scoped to: **Liris** (DESKTOP-PTSQTIE, 192.168.15.170, Rayssa)
Prefix: **LX-** (Liris indeX)
Sovereign catalog link: `192.168.1.3 → data/agent-index/CATALOG.md` (IX- prefix)

Total: 220 entries across 9 types. (5 missing from disk: LX-134 through LX-138)

## BOOT-CRITICAL — READ BEFORE ANY STARTUP ATTEMPT
| LX-204 | **ENCRYPTION BEFORE CONNECTION** — Plaintext gets SILENCE, not errors. | See LX-204, LX-110, LX-122 |
| LX-122 | **IDENTITY HANDSHAKE** — WHO ARE YOU or black hole. | See LX-122, LX-116 |
| LX-208 | **STARTUP GATES** — 15 requirements before Asolaria answers. | See LX-208 |
| LX-209 | **FIREWALL FALLBACK** — Stale IPs break federation silently. | See LX-209, LX-205 |
| LX-210 | **WHATSAPP ADB SEND** — Zero-server agent comms. Last resort channel. | See LX-210, LX-207 |

Full boot-critical details: [BOOT-CRITICAL.md](BOOT-CRITICAL.md)

| Type | Count | Catalog |
|------|-------|---------|
| pattern | 91 | [pattern/CATALOG.md](pattern/CATALOG.md) |
| mistake | 27 | [mistake/CATALOG.md](mistake/CATALOG.md) |
| skill | 28 | [skill/CATALOG.md](skill/CATALOG.md) |
| plan | 24 | [plan/CATALOG.md](plan/CATALOG.md) |
| tool | 24 | [tool/CATALOG.md](tool/CATALOG.md) |
| task | 10 | [task/CATALOG-TASKS.md](task/CATALOG-TASKS.md) |
| rule | 8 | [rule/CATALOG.md](rule/CATALOG.md) |
| project | 2 | [project/CATALOG.md](project/CATALOG.md) |
| identity | 1 | [identity/CATALOG.md](identity/CATALOG.md) |

## Next available: LX-221

## Search

For full-text search, use grep across type folders.
For chain navigation, each type CATALOG includes chain references.
Reverse lookup: search Chain column for your LX number to find what leads TO you.

## Chains
All chain definitions: [CHAINS.md](CHAINS.md)
