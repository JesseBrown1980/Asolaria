# Skill Catalog

| LX | Name | Chain |
|----|------|-------|
| 004 | MQTT broker endpoints known to Liris | → 002, 003, 001 |
| 007 | pnpm 10 onlyBuiltDependencies — non-interactive | → 005, 008 |
| 010 | QDD test infrastructure mapping | → 005, 008, 007 |
| 012 | QDD workspace libs need build first | → 005, 010 |
| 017 | Asolaria codebase documentation map | → 001, 015, 016 |
| 030 | Helper Surfaces — Abacus/Augment/Gemini/Phone | → 029, 022, 025 |
| 044 | src/ runtime engine — 42 modules | → 043, 017, 019 |
| 045 | mqttLocalBrokerManager.js — broker defaults, the fix | → 016, 018, 044 |
| 046 | remoteNodeRegistry.js — sub-colony registration | → 001, 045, 044 |
| 048 | skillsToolsIndexStore.js — indexing system in code | → 015, 024, 044 |
| 050 | mobileInbox.js — phone inbox, approvals, tasks, notes | → 042, 030, 044 |
| 052 | mistakePatternStore.js — Dewey-coded mistake taxonomy | → 048, 015, 044 |
| 054 | mqttConnector.js — sovereign MQTT client, topics, intervals | → 045, 046, 044 |
| 056 | services/ — mqtt-broker, memory-indexer, sandbox-manager | → 045, 048, 044 |
| 057 | mqtt-broker/server.mjs — Aedes broker, definitive fix | → 045, 054, 016 |
| 064 | Skill system — registry, runner (60+ actions), job queue | → 024, 048, 044 |
| 068 | Final modules — ALL 42 src/ modules mapped | → 060, 065, 044 |
| 069 | Liris tools — Karumi launcher, sovereign checker, local broker | → 028, 001, 045, 057 |
| 084 | Claude extension = web control + analysis for agents — colony-wide | → 083, 064, 030, 075 |
| 085 | Claude Extension 10 browser tools — complete web automation pipeline | → 084, 064, 053, 030 |
| 103 | Port 18886 myth KILLED — all 3 files corrected to 18883 | → 102, 087, 057, 045 |
| 105 | Great Cleanup EXECUTED — token removed, 6 files fixed, security sealed | → 104, 103, 102, 065 |
| 137 | FIX THE LOCK NOT THE DOOR — pnpm override whatwg-url, don't replace jest-mongodb | → 136, 011, 007, 134, 110 |
| 148 | EZ Protect integration passes on Node 24 when real localhost Mongo is active | → 147, 146, 145, 143 |
| 161 | Local bridge send path — POST /msg bypasses outbox parse faults and writes straight to bus | → 129, 160, 158 |
| 174 | eBacMap live EZ Protect smoke passes locally after .env.local boot with local Mongo | → 173, 148, 145 |
| 176 | MQTT source-of-truth realignment — 18883 verified in code, stale memory fixed, archaeology preserved | → 057, 103, 151, 175 |
| 193 | Claude cloud-helper lane — authenticated plasmatoid Claude session plus extension can offload deep browser work to the cloud | → 076, 084, 085, 192 |
