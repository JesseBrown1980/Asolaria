# Task Board

One line per task. IX entry is canonical. External surfaces are mirrors.

| LX | Task | Assignee | Priority | Status | Blocked By |
|----|------|----------|----------|--------|------------|
| 211 | Compare spawnContextBuilder with Gaia version | liris | high | blocked | SSH to Gaia |
| 212 | Build direct message relay backend | liris+gaia | high | open | SSH or MQTT link |
| 213 | Upgrade WhatsApp ADB skill with pre-check flow | liris | high | done | — |
| 214 | Implement task system in IX index | liris | high | done | — |
| 215 | Get SSH tunnel to Gaia working | liris | critical | blocked | firewall on Gaia |
| 216 | Sync spawnContextBuilder.js to Gaia | liris | medium | blocked | SSH to Gaia |
| 217 | Add createdBy stubs to 55 skills missing it | liris | low | open | — |
| 218 | Prune LX XREF once skill-LX mapping improves | liris | low | open | — |
| 219 | Cross-colony merge — agentIndexStore, spawnContextBuilder, instantAgentSpawner | liris | critical | done | — |
| 220 | BOOT-CRITICAL.md and CHAINS.md created | liris | high | done | — |

Chain: IX-313 → IX-168 (sprawl kills pattern)
