# Rule Catalog

| LX | Name | Chain |
|----|------|-------|
| 169 | Local identity rule — on Rayssa machine, Codex is operating as Liris unless explicit bus relay is requested | → 001, 129, 167 |
| 171 | IX-219 received locally — bridge is transport, index entries are protocol, Jesse host now verified on 192.168.1.5 | → 170, 169, 168, 112 |
| 199 | Natural20 is outside-world awareness; OpenClaw on Rayssa is a retired-but-drifted local surface | → 192, 193, 198 |
| 200 | Rayssa phone lane is live for support under liris/kuromi, but compute remains unproven | → 197, 198, 199 |
| 201 | Rayssa host now advertises a live bounded compute-readiness contract under liris | → 198, 199, 200 |
| 202 | Remote federation is still blocked on Rayssa MQTT being off, not on self-readiness | → 201, 200, 198 |
| 203 | Federation handoff boundary — do not mutate Rayssa MQTT toward unreachable broker targets | → 202, 201, 200 |
| 207 | **COMMS RULE — Browser Claude = WhatsApp tool, CLI Claude composes, browser sends. Slack DM also live.** | → 206, 205, 085, 084, 193 |
