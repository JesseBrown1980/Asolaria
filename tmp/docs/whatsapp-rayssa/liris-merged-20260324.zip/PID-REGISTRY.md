# PID Registry
Current active PID: 17368 (Liris)

## Skills Created by PID 17368

| Folder | ID | Title | Date |
|--------|----|-------|------|
| whatsapp-adb-send | whatsapp.adb.send | WhatsApp ADB Send Message | 2026-03-23T23:14:05Z |

## Skills Without PID Attribution

55 of 56 skills have no `createdBy` field. These predate PID tracking or were created by agents that did not stamp attribution.

| Folder | ID |
|--------|----|
| avatar-npc-business | avatar.npc.business.v1 |
| captures-prune-desktop-auto | captures.prune.desktop_auto |
| captures-prune-desktop-auto-dry-run | captures.prune.desktop_auto.dry_run |
| captures-stats | captures.stats |
| chrome-profiles-list | chrome.profiles_list |
| codebase-review-composite-tools-baseline | codebase.review_composite_tools_baseline |
| codebase-review-external-mcp-cache | codebase.review_external_mcp_cache |
| codebase-review-kickoff | codebase.review_kickoff |
| codebase-review-token-efficiency-snapshot | codebase.review_token_efficiency_snapshot |
| codex-ref-cloudflare-deploy | codex.ref.cloudflare-deploy |
| codex-ref-develop-web-game | codex.ref.develop-web-game |
| codex-ref-doc | codex.ref.doc |
| codex-ref-figma | codex.ref.figma |
| codex-ref-figma-implement-design | codex.ref.figma-implement-design |
| codex-ref-gh-address-comments | codex.ref.gh-address-comments |
| codex-ref-gh-fix-ci | codex.ref.gh-fix-ci |
| codex-ref-google-code-wiki | codex.ref.google-code-wiki |
| codex-ref-imagegen | codex.ref.imagegen |
| codex-ref-jupyter-notebook | codex.ref.jupyter-notebook |
| codex-ref-linear | codex.ref.linear |
| codex-ref-netlify-deploy | codex.ref.netlify-deploy |
| codex-ref-notion-knowledge-capture | codex.ref.notion-knowledge-capture |
| codex-ref-notion-meeting-intelligence | codex.ref.notion-meeting-intelligence |
| codex-ref-notion-research-documentation | codex.ref.notion-research-documentation |
| codex-ref-notion-spec-to-implementation | codex.ref.notion-spec-to-implementation |
| codex-ref-openai-docs | codex.ref.openai-docs |
| codex-ref-pdf | codex.ref.pdf |
| codex-ref-playwright | codex.ref.playwright |
| codex-ref-render-deploy | codex.ref.render-deploy |
| codex-ref-screenshot | codex.ref.screenshot |
| codex-ref-security-best-practices | codex.ref.security-best-practices |
| codex-ref-security-ownership-map | codex.ref.security-ownership-map |
| codex-ref-security-threat-model | codex.ref.security-threat-model |
| codex-ref-sentry | codex.ref.sentry |
| codex-ref-sora | codex.ref.sora |
| codex-ref-speech | codex.ref.speech |
| codex-ref-spreadsheet | codex.ref.spreadsheet |
| codex-ref-system-skill-creator | codex.ref.system.skill-creator |
| codex-ref-system-skill-installer | codex.ref.system.skill-installer |
| codex-ref-system-slides | codex.ref.system.slides |
| codex-ref-system-spreadsheets | codex.ref.system.spreadsheets |
| codex-ref-transcribe | codex.ref.transcribe |
| codex-ref-vercel-deploy | codex.ref.vercel-deploy |
| codex-ref-yeet | codex.ref.yeet |
| desktop-capture | desktop.capture |
| desktop-diagnostics | desktop.diagnostics |
| desktop-dual-capture | desktop.dual_capture |
| gemini-enterprise-backend-probe | gemini.enterprise_business_backend_probe |
| gemini-enterprise-business-open | gemini.enterprise_business_open |
| integrations-snapshot | integrations.snapshot |
| local-secure-rebuild-lab | local.secure_rebuild.lab |
| mistake-avoidance-hints | mistake.avoidance.hints |
| phone-browser-history-check | phone.browser_history_check |
| swarm-mode-status | swarm.mode.status |
| ui-visual-audit | ui.visual_audit |
