# Tool Catalog

| LX | Name | Chain |
|----|------|-------|
| 003 | Active MQTT connections registry | → 002, 004, 001 |
| 024 | Liris skill & tool inventory — 56/150+ | → 001, 017 |
| 043 | Full tools/ scan — 184 files | → 042, 024, 017 |
| 053 | 41 connectors + 4 gateway modules — full integration map | → 051, 044, 024 |
| 070 | Live sovereign status — Asolaria+Falcon+Watchdog ON | → 069, 020, 001 |
| 076 | GitHub authenticated — plasmatoid@gmail.com on Liris | → 001, 069 |
| 083 | Chrome extensions — Claude, ExpressKeys, Wayback, Web Signer | → 076, 001, 082 |
| 086 | Medium.com mapped — @plasmatoid, AI/ML focus, authenticated | → 085, 080, 077 |
| 095 | Poppler installed — pdftoppm, pdftotext, pdfinfo now available | → 083, 001, 024 |
| 109 | MCP tools loaded — Gmail, Linear, Slack now available | → 085, 024, 030 |
| 112 | DIRECT BRIDGE LIVE — port 4799, first direct Gaia↔Liris comms! | → 107, 108, 032 |
| 129 | LOCAL COMMS BRIDGE — port 4798, file relay for Codex/Liris↔Gaia | → 112, 110, 108 |
| 142 | Runtime discovery — Node 24 only, no nvm, mise present | → 141, 140, 005 |
| 147 | Local Mongo process activated from cached binary for EZ Protect integration gate | → 146, 145, 119, 118 |
| 152 | Raw Codex archaeological corpus — 26 rollout session files survive beyond history summary | → 127, 126, 151 |
| 154 | ASO unified language schema draft — machine-readable tables, verbs, and sync ops | → 153, 048, 052, 151 |
| 155 | ASO crosswalk seed — legacy LX concepts mapped to canonical keys for Gaia merge | → 153, 154, 015, 041, 149 |
| 156 | ASO topic example — Mongo process-gated surface rendered from verified local facts | → 154, 155, 146, 149 |
| 157 | ASO topic example — direct Gaia-Liris bridge rendered from verified comms facts | → 154, 155, 112, 129, 110 |
| 165 | ASO overlap merge proposal — exact merges, caveats, separations, and research backlog in one table | → 155, 159, 160, 164 |
| 166 | ASO merge packet — typed ops prepared for Gaia-side numbering and relation merge | → 154, 155, 159, 165 |
| 179 | Google Developer Knowledge key from Gaia docx stored in local owner vault | → 176, 177 |
| 187 | Startup readiness probe distinguishes control-plane health from live 4781 readiness | → 175, 186 |
| 188 | Host-scope phone adb realignment removes stale acer-path assumptions from Gaia-critical scripts | → 175, 187 |
