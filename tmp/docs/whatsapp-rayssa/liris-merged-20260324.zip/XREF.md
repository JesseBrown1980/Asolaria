# LX <-> Skill Cross-Reference

Mapping LX entries of type "skill" to their corresponding skill folders in `Asolaria/skills/`.

| LX | Name | Skill Folder |
|----|------|-------------|
| 004 | MQTT broker endpoints known to Liris | -- |
| 007 | pnpm 10 onlyBuiltDependencies -- non-interactive | -- |
| 010 | QDD test infrastructure mapping | -- |
| 012 | QDD workspace libs need build first | -- |
| 017 | Asolaria codebase documentation map | codebase-review-kickoff |
| 030 | Helper Surfaces -- Abacus/Augment/Gemini/Phone | -- |
| 044 | src/ runtime engine -- 42 modules | -- |
| 045 | mqttLocalBrokerManager.js -- broker defaults, the fix | -- |
| 046 | remoteNodeRegistry.js -- sub-colony registration | -- |
| 048 | skillsToolsIndexStore.js -- indexing system in code | -- |
| 050 | mobileInbox.js -- phone inbox, approvals, tasks, notes | -- |
| 052 | mistakePatternStore.js -- Dewey-coded mistake taxonomy | mistake-avoidance-hints |
| 054 | mqttConnector.js -- sovereign MQTT client, topics, intervals | -- |
| 056 | services/ -- mqtt-broker, memory-indexer, sandbox-manager | -- |
| 057 | mqtt-broker/server.mjs -- Aedes broker, definitive fix | -- |
| 064 | Skill system -- registry, runner (60+ actions), job queue | -- |
| 068 | Final modules -- ALL 42 src/ modules mapped | -- |
| 069 | Liris tools -- Karumi launcher, sovereign checker, local broker | -- |
| 084 | Claude extension = web control + analysis for agents | -- |
| 085 | Claude Extension 10 browser tools -- web automation pipeline | -- |
| 103 | Port 18886 myth KILLED -- all 3 files corrected to 18883 | -- |
| 105 | Great Cleanup EXECUTED -- token removed, 6 files fixed | -- |
| 137 | FIX THE LOCK NOT THE DOOR -- pnpm override whatwg-url | -- |
| 148 | EZ Protect integration passes on Node 24 with localhost Mongo | -- |
| 161 | Local bridge send path -- POST /msg bypasses outbox parse | -- |
| 174 | eBacMap live EZ Protect smoke passes locally | -- |
| 176 | MQTT source-of-truth realignment -- 18883 verified in code | -- |
| 193 | Claude cloud-helper lane -- authenticated plasmatoid session | chrome-profiles-list |
| 210 | WhatsApp ADB Send Skill | whatsapp-adb-send |

## Skill folders without LX entries

These skill folders in `Asolaria/skills/` have no matching LX entry:

- avatar-npc-business
- captures-prune-desktop-auto
- captures-prune-desktop-auto-dry-run
- captures-stats
- chrome-profiles-list (partial match: LX-193)
- codebase-review-composite-tools-baseline
- codebase-review-external-mcp-cache
- codebase-review-kickoff (partial match: LX-017)
- codebase-review-token-efficiency-snapshot
- codex-ref-cloudflare-deploy
- codex-ref-develop-web-game
- codex-ref-doc
- codex-ref-figma
- codex-ref-figma-implement-design
- codex-ref-gh-address-comments
- codex-ref-gh-fix-ci
- codex-ref-google-code-wiki
- codex-ref-imagegen
- codex-ref-jupyter-notebook
- codex-ref-linear
- codex-ref-netlify-deploy
- codex-ref-notion-knowledge-capture
- codex-ref-notion-meeting-intelligence
- codex-ref-notion-research-documentation
- codex-ref-notion-spec-to-implementation
- codex-ref-openai-docs
- codex-ref-pdf
- codex-ref-playwright
- codex-ref-render-deploy
- codex-ref-screenshot
- codex-ref-security-best-practices
- codex-ref-security-ownership-map
- codex-ref-security-threat-model
- codex-ref-sentry
- codex-ref-sora
- codex-ref-speech
- codex-ref-spreadsheet
- codex-ref-system-skill-creator
- codex-ref-system-skill-installer
- codex-ref-system-slides
- codex-ref-system-spreadsheets
- codex-ref-transcribe
- codex-ref-vercel-deploy
- codex-ref-yeet
- desktop-capture
- desktop-diagnostics
- desktop-dual-capture
- gemini-enterprise-backend-probe
- gemini-enterprise-business-open
- integrations-snapshot
- local-secure-rebuild-lab
- mistake-avoidance-hints (partial match: LX-052)
- phone-browser-history-check
- swarm-mode-status
- ui-visual-audit
