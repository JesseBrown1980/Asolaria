# Rayssa Host Compat Rerun + Compute Readiness

Generated: 2026-03-23 16:58:07 -03:00
Scope: Rayssa host only
Node identity default: liris/kuromi

## Verdict

- compat 4781 rerun PID hardening: pass
- compute slice present: yes
- node identity liris: yes
- MQTT federation topics present: yes
- bounded local execution proven: yes
- computeWorkerReady: false
- cross-host compute / phone CPU sharing: not proven

## 1. Compat 4781 Rerun PID Hardening

First launch command:

```powershell
& 'C:\Users\rayss\Asolaria\tools\Start-Asolaria-Compat4781.ps1' -Port 4781 -GatewayPort 4791 -BindHost '127.0.0.1' -ForceRestart
```

First launch result:

- command completed successfully with exit code `0`
- the local shell runner did not emit a structured stdout payload for the force-restart path
- post-launch listener state is captured below and is the authoritative proof

Listening PID on 4781 after first launch:

```text
compat4781.pid
15936

Get-NetTCPConnection -LocalPort 4781 -State Listen
{
  "LocalAddress": "127.0.0.1",
  "LocalPort": 4781,
  "OwningProcess": 15936
}
```

Second launch result:

```json
{
  "ok": true,
  "alreadyRunning": true,
  "pid": 15936,
  "listenerPid": 15936,
  "port": 4781,
  "gatewayPort": 4791,
  "bind": "127.0.0.1",
  "script": "C:\\Users\\rayss\\Asolaria\\src\\gateway\\compat4781.js",
  "stdoutLog": "C:\\Users\\rayss\\Asolaria\\logs\\compat4781.out.log",
  "stderrLog": "C:\\Users\\rayss\\Asolaria\\logs\\compat4781.err.log",
  "pidFile": "C:\\Users\\rayss\\Asolaria\\logs\\compat4781.pid"
}
```

Proof that no duplicate listener was created:

```text
  TCP    127.0.0.1:4781         0.0.0.0:0              LISTENING       15936
  TCP    127.0.0.1:4781         127.0.0.1:50531        TIME_WAIT       0
  TCP    127.0.0.1:4781         127.0.0.1:50557        TIME_WAIT       0
  TCP    127.0.0.1:4781         127.0.0.1:50569        TIME_WAIT       0
  TCP    127.0.0.1:4781         127.0.0.1:50579        TIME_WAIT       0
  TCP    127.0.0.1:4781         127.0.0.1:50601        TIME_WAIT       0
  TCP    127.0.0.1:4781         127.0.0.1:50614        TIME_WAIT       0
  TCP    127.0.0.1:4781         127.0.0.1:50626        ESTABLISHED     15936
```

4781 health after rerun:

```json
{
  "ok": true,
  "service": "asolaria-compat-4781",
  "compatSurface": "proxy_4781",
  "bind": "127.0.0.1",
  "port": 4781,
  "gatewayBaseUrl": "http://127.0.0.1:4791"
}
```

4791 health after rerun:

```json
{
  "ok": true,
  "service": "asolaria-gateway",
  "bind": "0.0.0.0",
  "port": 4791,
  "startedAt": "2026-03-22T18:30:01.714Z"
}
```

## 2. Local Liris Compute Readiness

Node identity explicit as liris:

```text
config/liris-node-identity.json
2:  "nodeId": "liris",
3:  "role": "sub_colony",
6:  "capabilities": [
14:  "mqttTopicPrefix": "asolaria/nodes/liris",
```

Compute slice present:

```text
src/connectors/workerRouter.js
28:const WORKER_IDS = ["local_codex", "claude_max", "abacus", "symphony"];
324:function getWorkerRouterStatus() {
882:async function dispatchWorkerTask(input = {}) {
886:  if (!worker?.dispatchable) {
887:    throw new Error(`Worker ${workerId} is not dispatchable on this machine.`);

config/asolaria.gateway.json
31:      "localops.run"
33:    "requireApproval": [
34:      "localops.run",
35:      "sandbox.execute"
```

MQTT federation topics present:

```text
src/connectors/mqttConnector.js
193:    graphEvents: `${root}/graph/events`,
194:    actionManifests: `${root}/graph/manifests`,
195:    colonyStatus: `${root}/agents/colony/status`,
196:    worldState: `${root}/world/state`,
197:    runtimeHealth: `${root}/runtime/health`,
198:    runtimePresence: `${root}/runtime/presence`,
199:    controlRequest: `${root}/control/request`,
200:    controlAck: `${root}/control/ack`
```

Bounded local execution proof order:

1. `python --version` failed because Python is not installed on this host.
2. `rg --version` succeeded and is the clean bounded proof used for this packet.
3. `git --version` is also available as fallback.

Raw bounded command output:

```text
python --version
Python não foi encontrado; executar sem argumentos para instalar do Microsoft Store ou desabilitar este atalho em Configurações > Aplicativos > Configurações avançadas do aplicativo > Aliases de execução do aplicativo.

rg --version
ripgrep 15.1.0 (rev af60c2de9d)

features:+pcre2
simd(compile):+SSE2,-SSSE3,-AVX2
simd(runtime):+SSE2,+SSSE3,+AVX2

PCRE2 10.45 is available (JIT is available)

git --version
git version 2.53.0.windows.1
```

ComputeWorkerReady decision:

- `computeWorkerReady=false` for this packet.
- Honest reason: the clean bounded proof is shell-local only.
- The Rayssa checkout clearly contains the compute slice and MQTT federation topics, but this pass does not prove a clean advertised worker contract end to end.
- Do not claim cross-host compute or phone CPU/RAM sharing is live from this packet.
