# Liris Sub-Colony Index — Router

Scoped to: **Liris** (DESKTOP-PTSQTIE, 192.168.15.170, Rayssa)
Prefix: **LX-** (Liris indeX)
Sovereign catalog link: `192.168.1.3 → data/agent-index/CATALOG.md` (IX- prefix)

Total: 218 entries across 9 types. (5 missing from disk: LX-134 through LX-138)

| Type | Count | Catalog |
|------|-------|---------|
| pattern | 91 | [pattern/CATALOG.md](pattern/CATALOG.md) |
| mistake | 27 | [mistake/CATALOG.md](mistake/CATALOG.md) |
| skill | 28 | [skill/CATALOG.md](skill/CATALOG.md) |
| plan | 24 | [plan/CATALOG.md](plan/CATALOG.md) |
| tool | 24 | [tool/CATALOG.md](tool/CATALOG.md) |
| task | 8 | [task/CATALOG-TASKS.md](task/CATALOG-TASKS.md) |
| rule | 8 | [rule/CATALOG.md](rule/CATALOG.md) |
| project | 2 | [project/CATALOG.md](project/CATALOG.md) |
| identity | 1 | [identity/CATALOG.md](identity/CATALOG.md) |

## Next available: LX-219

## Search

For full-text search, use grep across type folders.
For chain navigation, each type CATALOG includes chain references.
Reverse lookup: search Chain column for your LX number to find what leads TO you.

## Chains

*Identity:* 001 → IX-009 → IX-010
*Resilience:* 002 → 003 → 006
*Networking:* 004 → 016 → 018 → 045
*QDD:* 005 → 007 → 008 → 010 → 011 → 012 → 013
*Environment:* 009 → 014 → 001
*Core Architecture:* 015 → 041 → IX-006 → IX-007
*Boot:* 020 → 027 → 028 → 021
*Security:* 023 → 026 → 031 → 038 → 039 → 065 → 110 → 134
*Orchestration:* 022 → 025 → 029 → 030
*Archaeology:* 042 → 043 → 044 → 045 → 046 → 047 → 048 → 049 → 050
*Runtime deep-dive:* 051 → 053 → 054 → 055 → 056 → 057 → 058 → 059 → 060 → 061 → 062 → 064 → 065 → 066
*Meta:* 035 → 032 → 033 → 036
*Direct comms:* 107 → 110 → 112 → 129
*Archaeological dig:* 072 → 073 → 074 → 075 → 076 → 077 → 078 → 079 → 080 → 081 → 082 → 083 → 084 → 085 → 086 → 087 → 088 → 089 → 090 → 091 → 092 → 093 → 094 → 095
*Medium articles:* 088 → 089 → 090 → 091 → 092 → 093 → 094
*Unified language:* 015 → 041 → 048 → 052 → 120 → 151 → 152 → 153
*ASO schema:* 153 → 154
*ASO migration:* 153 → 154 → 155
*ASO worked topic:* 149 → 154 → 155 → 156
*ASO comms topic:* 110 → 112 → 129 → 154 → 155 → 157
*ASO migration gaps:* 155 → 157 → 158
*ASO overlap validation:* 155 → 001 → 015 → 041 → 111 → 112 → 159
*ASO catch-up:* 154 → 155 → 158 → 159 → 160
*ASO comms workaround:* 129 → 158 → 160 → 161
*ASO bridge outage:* 157 → 160 → 161 → 162 → 164
*ASO host outage:* 112 → 129 → 162 → 163 → 164
*ASO merge prep:* 155 → 159 → 160 → 164 → 165
*ASO merge packet:* 154 → 155 → 159 → 165 → 166
*Bridge numbering:* 112 → 129 → 161 → 164 → 167
*Alternate bridge probe:* 129 → 164 → 167 → 168
*Local identity:* 001 → 129 → 167 → 169
*Index-language realignment:* 015 → 153 → 167 → 169 → 170
*IX-219 adoption:* 112 → 168 → 169 → 170 → 171
*Network split:* 129 → 162 → 163 → 171 → 172
*eBacMap env root cause:* 140 → 145 → 148 → 173
*eBacMap live smoke:* 145 → 148 → 173 → 174
*Asolaria boot mismatch:* 017 → 030 → 171 → 175
*MQTT truth realignment:* 057 → 103 → 151 → 175 → 176
*Gaia transcript security:* 151 → 176 → 177
*Gaia startup contradiction:* 163 → 175 → 176 → 178
*Local Google vault ingest:* 176 → 177 → 179
*Second-order Gaia corroboration:* 177 → 178 → 180
*Dan transcript provenance:* 019 → 127 → 151 → 181
*18886 myth propagation:* 102 → 176 → 181 → 182
*Index language dating:* 120 → 151 → 181 → 183
*Layered colony memory:* 178 → 182 → 183 → 184
*Sovereign runtime retrieval:* 175 → 184 → 185
*Local pre-restart hardening:* 175 → 184 → 185 → 186
*Startup readiness:* 175 → 186 → 187
*Host-scope phone adb realignment:* 175 → 187 → 188
*Rayssa host startup truth:* 175 → 187 → 188 → 189
*Rayssa contract split analysis:* 175 → 178 → 189 → 190
*Rayssa startup gate:* 178 → 189 → 190 → 191
*OpenClaw WhatsApp + SSH lane:* 098 → 127 → 129 → 192
*Claude cloud-helper offload lane:* 076 → 084 → 085 → 192 → 193
*Rayssa phone reconnect state:* 188 → 189 → 191 → 194
*Rayssa phone compat live:* 194 → 195 → 196
*Rayssa phone proof bundle:* 194 → 195 → 196 → 197
*Rayssa compat rerun + compute readiness:* 197 → 196 → 189 → 198
*Natural20 vs OpenClaw host drift:* 192 → 193 → 198 → 199
*Rayssa phone support vs compute boundary:* 197 → 198 → 199 → 200
*Rayssa live compute-readiness contract:* 198 → 199 → 200 → 201
*Rayssa remote federation blocker:* 201 → 200 → 198 → 202
*Rayssa federation handoff:* 202 → 201 → 200 → 203
*Encryption truth correction:* 102 → 103 → 158 → 134 → 135 → 110 → 114 → 122 → 204
