/**
 * Spawn Context Builder — Asolaria's Internal Agent Briefing System
 *
 * When Asolaria spawns a real agent inside the black hole, she needs to
 * decide WHAT that agent knows. This module is her PID controller:
 *
 *   P (Proportional) — current blockers, health state, active alarms
 *   I (Integral)     — accumulated IX knowledge, filtered by agent role
 *   D (Derivative)   — recent MQTT traffic, inbox delta, drift signals
 *
 * Each agent role gets a compressed, role-specific briefing — not the
 * full index. The spawn-PID is virtual (role + timestamp), not an OS PID.
 *
 * Flow:
 *   Asolaria wakes → reads typed IX folders (I) → checks health (P) →
 *   checks MQTT drift (D) → buildSpawnContext("helm") → compressed packet →
 *   real Helm spawns with ONLY what he needs → identity handshake →
 *   Helm works → despawns → indexes what he learned → next spawn updated
 *
 * LX chain: LX-122 (identity handshake), LX-116 (awakening), LX-111 (swarm collapse)
 */

const fs = require("fs");
const path = require("path");
const { resolveDataPath } = require("./runtimePaths");
const { appendGraphEvent } = require("./graphRuntimeStore");
const { listMistakePatterns } = require("./mistakePatternStore");

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const IX_ROOT = resolveDataPath("agent-index");
const HEALTH_PATH = resolveDataPath("health-state.json");
const DRIFT_PATH = resolveDataPath("drift-signals.json");
const PID_REGISTRY_PATH = resolveDataPath("spawn-pid-registry.json");

const IX_TYPES = ["pattern", "mistake", "plan", "skill", "tool", "rule", "reference", "identity", "project", "task"];

/**
 * Role definitions — what IX types each agent needs when spawned.
 * This is the core of the PID controller's I (Integral) component.
 * Each role gets ONLY the IX types relevant to its function.
 */
const ROLE_DEFINITIONS = Object.freeze({
  helm: {
    label: "Helm",
    title: "Colony Controller",
    ixTypes: ["rule", "pattern", "plan", "mistake", "task"],
    taskKeywords: ["control", "dispatch", "spawn", "colony", "coordination", "helm"],
    permissions: ["control.dispatch", "agent.spawn", "lane.manage", "task.assign"],
    briefing: "You are the controller. You manage agent lifecycle, task routing, and colony coordination.",
    maxIxEntries: 20
  },
  sentinel: {
    label: "Sentinel",
    title: "Security Watch",
    ixTypes: ["rule", "mistake", "reference", "task"],
    taskKeywords: ["security", "encrypt", "firewall", "identity", "auth", "sentinel"],
    permissions: ["security.audit", "policy.enforce", "connection.verify", "identity.check"],
    briefing: "You are the security watch. You enforce encryption, verify identities, and block unauthorized access.",
    maxIxEntries: 15
  },
  vector: {
    label: "Vector",
    title: "Main Brain",
    ixTypes: ["pattern", "plan", "task"],
    taskKeywords: ["brain", "reason", "analysis", "research", "vector"],
    permissions: ["brain.reason", "research.deep", "analysis.run"],
    briefing: "You are the main brain. You handle heavy reasoning, deep analysis, and strategic planning.",
    maxIxEntries: 18
  },
  falcon: {
    label: "Falcon",
    title: "Phone Lane",
    ixTypes: ["skill", "tool", "task"],
    taskKeywords: ["phone", "adb", "whatsapp", "mobile", "falcon"],
    permissions: ["phone.input", "phone.capture", "adb.execute", "whatsapp.send"],
    briefing: "You are the phone lane. You control the mobile device via ADB, manage WhatsApp, and handle phone-side operations.",
    maxIxEntries: 12
  },
  forge: {
    label: "Forge",
    title: "Build Lane",
    ixTypes: ["tool", "plan", "skill", "task"],
    taskKeywords: ["build", "test", "code", "deploy", "forge"],
    permissions: ["build.run", "test.execute", "code.write", "deploy.stage"],
    briefing: "You are the build lane. You write code, run tests, handle deployments, and execute build tasks.",
    maxIxEntries: 15
  },
  rook: {
    label: "Rook",
    title: "Ops Lane",
    ixTypes: ["tool", "rule", "task"],
    taskKeywords: ["ops", "infra", "monitor", "service", "ssh", "network", "rook"],
    permissions: ["ops.monitor", "infra.manage", "log.read", "service.restart"],
    briefing: "You are the ops lane. You monitor infrastructure, manage services, read logs, and handle operational tasks.",
    maxIxEntries: 12
  },
  watchdog: {
    label: "Watchdog",
    title: "Supervisor",
    ixTypes: ["rule", "mistake", "pattern", "task"],
    taskKeywords: ["monitor", "health", "alert", "watchdog", "supervisor"],
    permissions: ["agent.monitor", "health.check", "alert.send"],
    briefing: "You are the supervisor. You monitor other agents, check health, and escalate when things go wrong.",
    maxIxEntries: 10
  }
});

// ---------------------------------------------------------------------------
// IX Index Reader — the I (Integral) component
// ---------------------------------------------------------------------------

function readIxTypeFolder(typeName) {
  const typeDir = path.join(IX_ROOT, typeName);
  if (!fs.existsSync(typeDir)) return [];

  const entries = [];
  let files;
  try {
    files = fs.readdirSync(typeDir).filter((f) => f.startsWith("LX-") && f.endsWith(".md"));
  } catch (_err) {
    return [];
  }

  for (const file of files) {
    try {
      const content = fs.readFileSync(path.join(typeDir, file), "utf8");
      const frontmatter = parseFrontmatter(content);
      if (!frontmatter) continue;
      entries.push({
        lx: frontmatter.lx || file.replace(/^LX-0*/, "").replace(/\.md$/, ""),
        name: frontmatter.name || file,
        type: typeName,
        tags: Array.isArray(frontmatter.tags) ? frontmatter.tags : [],
        chain: Array.isArray(frontmatter.chain) ? frontmatter.chain : [],
        file,
        // Include first 3 lines of content body for compressed context
        summary: extractSummary(content, 3),
        // Preserve full frontmatter for task filtering
        _frontmatter: frontmatter
      });
    } catch (_err) {
      // Skip unreadable files
    }
  }
  return entries;
}

function parseFrontmatter(content) {
  const match = content.match(/^---\s*\n([\s\S]*?)\n---/);
  if (!match) return null;
  const block = match[1];
  const result = {};
  for (const line of block.split("\n")) {
    const kv = line.match(/^(\w+):\s*(.+)/);
    if (!kv) continue;
    const key = kv[1].trim();
    let value = kv[2].trim();
    // Parse arrays: [a, b, c]
    if (value.startsWith("[") && value.endsWith("]")) {
      value = value.slice(1, -1).split(",").map((s) => s.trim().replace(/^['"]|['"]$/g, ""));
    }
    result[key] = value;
  }
  return result;
}

function extractSummary(content, maxLines) {
  const body = content.replace(/^---[\s\S]*?---\s*\n*/, "").trim();
  const lines = body.split("\n").filter((l) => l.trim()).slice(0, maxLines);
  return lines.join(" ").slice(0, 300);
}

function queryIxByRole(role) {
  const def = ROLE_DEFINITIONS[role];
  if (!def) return [];

  const entries = [];
  for (const typeName of def.ixTypes) {
    if (typeName === "task") {
      // Tasks get special filtering — only active tasks relevant to this role
      entries.push(...queryTasksForRole(role));
    } else {
      entries.push(...readIxTypeFolder(typeName));
    }
  }

  // Sort by LX number (most recent first — higher numbers = newer knowledge)
  entries.sort((a, b) => {
    const numA = parseInt(String(a.lx), 10) || 0;
    const numB = parseInt(String(b.lx), 10) || 0;
    return numB - numA;
  });

  // Clamp to role's max
  return entries.slice(0, def.maxIxEntries);
}

/**
 * Query tasks relevant to a specific agent role.
 * Filters by: assignee match, keyword match in tags/name, and active status.
 * Done/archived tasks are excluded unless recently completed (< 24h).
 */
function queryTasksForRole(role) {
  const def = ROLE_DEFINITIONS[role];
  if (!def) return [];

  const allTasks = readIxTypeFolder("task");
  const keywords = def.taskKeywords || [role];
  const now = Date.now();
  const oneDayMs = 24 * 60 * 60 * 1000;

  return allTasks.filter((task) => {
    // Parse status from frontmatter (stored in tags or summary)
    const fm = task._frontmatter || {};
    const status = String(fm.status || "").toLowerCase();
    const assignee = String(fm.assignee || "").toLowerCase();

    // Skip done tasks older than 24h
    if (status === "done") {
      const completedAt = fm.completedAt ? new Date(fm.completedAt).getTime() : 0;
      if (completedAt && (now - completedAt) > oneDayMs) return false;
    }

    // Skip archived tasks
    if (status === "archived") return false;

    // Match by assignee
    if (assignee.includes(role) || assignee.includes("all")) return true;

    // Match by keywords in task name or tags
    const name = String(task.name || "").toLowerCase();
    const tags = Array.isArray(task.tags) ? task.tags.map((t) => String(t).toLowerCase()) : [];
    return keywords.some((kw) =>
      name.includes(kw) || tags.some((t) => t.includes(kw))
    );
  });
}

// ---------------------------------------------------------------------------
// Health State Reader — the P (Proportional) component
// ---------------------------------------------------------------------------

function readHealthState() {
  try {
    if (!fs.existsSync(HEALTH_PATH)) {
      return { status: "unknown", blockers: [], checkedAt: null };
    }
    const raw = JSON.parse(fs.readFileSync(HEALTH_PATH, "utf8"));
    return {
      status: String(raw.status || "unknown"),
      blockers: Array.isArray(raw.blockers) ? raw.blockers : [],
      checkedAt: raw.checkedAt || null,
      services: raw.services || {}
    };
  } catch (_err) {
    return { status: "unreadable", blockers: ["health-state.json unreadable"], checkedAt: null };
  }
}

// ---------------------------------------------------------------------------
// Drift Signal Reader — the D (Derivative) component
// ---------------------------------------------------------------------------

function readDriftSignals() {
  try {
    if (!fs.existsSync(DRIFT_PATH)) {
      return { signals: [], lastUpdate: null };
    }
    const raw = JSON.parse(fs.readFileSync(DRIFT_PATH, "utf8"));
    return {
      signals: Array.isArray(raw.signals) ? raw.signals.slice(-10) : [],
      lastUpdate: raw.lastUpdate || null,
      mqttTraffic: raw.mqttTraffic || null,
      inboxDelta: raw.inboxDelta || 0
    };
  } catch (_err) {
    return { signals: [], lastUpdate: null };
  }
}

// ---------------------------------------------------------------------------
// Mistake Filter — role-relevant mistakes from the pattern store
// ---------------------------------------------------------------------------

function getMistakesForRole(role) {
  try {
    const all = listMistakePatterns({ limit: 50 });
    if (!Array.isArray(all) || all.length === 0) return [];

    const def = ROLE_DEFINITIONS[role];
    if (!def) return [];

    // Filter by tag overlap with role's IX types and permissions
    const roleKeywords = [
      role,
      ...def.ixTypes,
      ...def.permissions.map((p) => p.split(".")[0])
    ];

    return all
      .filter((m) => {
        const tags = Array.isArray(m.tags) ? m.tags : [];
        const name = String(m.name || m.id || "").toLowerCase();
        return roleKeywords.some((kw) =>
          tags.some((t) => String(t).toLowerCase().includes(kw)) ||
          name.includes(kw)
        );
      })
      .slice(0, 5);
  } catch (_err) {
    return [];
  }
}

// ---------------------------------------------------------------------------
// PID Registry — virtual spawn PIDs
// ---------------------------------------------------------------------------

function readPidRegistry() {
  try {
    if (!fs.existsSync(PID_REGISTRY_PATH)) return { active: {}, history: [] };
    return JSON.parse(fs.readFileSync(PID_REGISTRY_PATH, "utf8"));
  } catch (_err) {
    return { active: {}, history: [] };
  }
}

function writePidRegistry(registry) {
  const dir = path.dirname(PID_REGISTRY_PATH);
  fs.mkdirSync(dir, { recursive: true });
  const temp = `${PID_REGISTRY_PATH}.tmp-${process.pid}-${Date.now()}`;
  fs.writeFileSync(temp, JSON.stringify(registry, null, 2), "utf8");
  fs.renameSync(temp, PID_REGISTRY_PATH);
}

function mintSpawnPid(role) {
  const now = new Date();
  const ts = now.toISOString().replace(/[-:T]/g, "").slice(0, 14);
  return `${role}-${ts}-${Math.random().toString(36).slice(2, 6)}`;
}

function registerSpawnPid(role, spawnPid) {
  const registry = readPidRegistry();
  const entry = {
    spawnPid,
    role,
    spawnedAt: new Date().toISOString(),
    status: "active"
  };

  // Deactivate any previous PID for this role
  if (registry.active[role]) {
    const old = registry.active[role];
    old.status = "despawned";
    old.despawnedAt = new Date().toISOString();
    registry.history.push(old);
    // Keep history bounded
    if (registry.history.length > 100) {
      registry.history = registry.history.slice(-100);
    }
  }

  registry.active[role] = entry;
  writePidRegistry(registry);
  return entry;
}

function despawnPid(role) {
  const registry = readPidRegistry();
  if (registry.active[role]) {
    const entry = registry.active[role];
    entry.status = "despawned";
    entry.despawnedAt = new Date().toISOString();
    registry.history.push(entry);
    delete registry.active[role];
    if (registry.history.length > 100) {
      registry.history = registry.history.slice(-100);
    }
    writePidRegistry(registry);
    return entry;
  }
  return null;
}

// ---------------------------------------------------------------------------
// Core: Build Spawn Context
// ---------------------------------------------------------------------------

/**
 * Builds a complete spawn context for an agent role.
 * This is what Asolaria hands to a real agent when she spawns it.
 *
 * @param {string} role - Agent role (helm, sentinel, vector, falcon, forge, rook, watchdog)
 * @param {object} options - Optional overrides
 * @param {string} options.mission - Specific mission text for this spawn
 * @param {string[]} options.extraIxTypes - Additional IX types to include
 * @param {boolean} options.registerPid - Whether to register a spawn PID (default: true)
 * @returns {object} Spawn context packet
 */
function buildSpawnContext(role, options = {}) {
  const normalizedRole = String(role || "").trim().toLowerCase();
  const def = ROLE_DEFINITIONS[normalizedRole];

  if (!def) {
    throw new Error(`Unknown agent role: "${role}". Valid: ${Object.keys(ROLE_DEFINITIONS).join(", ")}`);
  }

  // Mint PID
  const spawnPid = mintSpawnPid(normalizedRole);
  const shouldRegister = options.registerPid !== false;
  if (shouldRegister) {
    registerSpawnPid(normalizedRole, spawnPid);
  }

  // P — Proportional: current state
  const health = readHealthState();
  const blockers = health.blockers || [];

  // I — Integral: accumulated IX knowledge
  const ixEntries = queryIxByRole(normalizedRole);

  // If extra IX types requested, add them
  if (Array.isArray(options.extraIxTypes)) {
    for (const extraType of options.extraIxTypes) {
      if (IX_TYPES.includes(extraType) && !def.ixTypes.includes(extraType)) {
        const extra = readIxTypeFolder(extraType);
        ixEntries.push(...extra.slice(0, 5));
      }
    }
  }

  // D — Derivative: drift signals
  const drift = readDriftSignals();

  // Mistakes relevant to this role
  const mistakes = getMistakesForRole(normalizedRole);

  // Build the identity handshake challenge
  const identityChallenge = {
    question: "WHO ARE YOU?",
    expectedAnswer: `I am ${def.label}, spawn-PID ${spawnPid}`,
    onFailure: "black-hole"
  };

  // Compose the context packet
  const packet = {
    spawnPid,
    role: normalizedRole,
    label: def.label,
    title: def.title,
    spawnedAt: new Date().toISOString(),
    permissions: def.permissions,
    briefing: def.briefing,
    mission: options.mission || null,

    // PID controller components
    proportional: {
      healthStatus: health.status,
      blockers,
      serviceState: health.services || {}
    },
    integral: {
      ixEntries: ixEntries.map((e) => ({
        lx: e.lx,
        name: e.name,
        type: e.type,
        summary: e.summary,
        chain: e.chain
      })),
      ixTypesLoaded: def.ixTypes,
      totalEntries: ixEntries.length
    },
    derivative: {
      signals: drift.signals,
      mqttTraffic: drift.mqttTraffic,
      inboxDelta: drift.inboxDelta,
      lastUpdate: drift.lastUpdate
    },

    mistakes: mistakes.map((m) => ({
      id: m.id || m.name,
      summary: String(m.description || m.summary || m.name || "").slice(0, 200)
    })),

    identityHandshake: identityChallenge
  };

  // Emit graph event for spawn tracking
  appendGraphEvent({
    component: "spawn-context-builder",
    category: "agent-lifecycle",
    action: "agent_spawned",
    status: "ok",
    actor: { type: "orchestrator", id: "asolaria" },
    target: { type: "agent", id: normalizedRole, criticality: "high" },
    context: {
      spawnPid,
      role: normalizedRole,
      ixEntries: ixEntries.length,
      blockers: blockers.length,
      driftSignals: drift.signals.length
    },
    policy: {
      mode: "spawn",
      approvalState: "identity_pending",
      autonomous: true
    },
    detail: {
      note: `Spawned ${def.label} with ${ixEntries.length} IX entries, ${blockers.length} blockers, ${drift.signals.length} drift signals`
    }
  });

  return packet;
}

// ---------------------------------------------------------------------------
// Utility: List all available roles
// ---------------------------------------------------------------------------

function listAgentRoles() {
  return Object.entries(ROLE_DEFINITIONS).map(([role, def]) => {
    const ixCount = def.ixTypes.reduce((sum, type) => {
      try {
        const dir = path.join(IX_ROOT, type);
        if (!fs.existsSync(dir)) return sum;
        return sum + fs.readdirSync(dir).filter((f) => f.startsWith("LX-")).length;
      } catch (_e) {
        return sum;
      }
    }, 0);

    return {
      role,
      label: def.label,
      title: def.title,
      ixTypes: def.ixTypes,
      ixEntriesAvailable: ixCount,
      maxIxEntries: def.maxIxEntries,
      permissions: def.permissions
    };
  });
}

// ---------------------------------------------------------------------------
// Utility: Get active spawn PIDs
// ---------------------------------------------------------------------------

function getActiveSpawns() {
  const registry = readPidRegistry();
  return Object.entries(registry.active).map(([role, entry]) => ({
    role,
    ...entry
  }));
}

// ---------------------------------------------------------------------------
// Exports
// ---------------------------------------------------------------------------

module.exports = {
  buildSpawnContext,
  listAgentRoles,
  getActiveSpawns,
  despawnPid,
  readPidRegistry,
  ROLE_DEFINITIONS,
  // Exposed for testing / comparison with Gaia's version
  queryIxByRole,
  readHealthState,
  readDriftSignals,
  getMistakesForRole
};
